// Asset with no client ID
