# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.sportz')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

YOUTUBE_CHANNEL_ID_3000 = "ussoccerdotcom"           #US Soccer Channel
YOUTUBE_CHANNEL_ID_3001 = "" #
YOUTUBE_CHANNEL_ID_3002 = ""
YOUTUBE_CHANNEL_ID_3003 = "NFL"                      #National Footbal League
YOUTUBE_CHANNEL_ID_3004 = "UCl1AI3a9tgswsd8CQPgGPDA" #Big Mind Sports Channel
YOUTUBE_CHANNEL_ID_3005 = "MLBNetworkClips"          #MLB Network Channel
YOUTUBE_CHANNEL_ID_3006 = "WBSCo"                    #World Baseball Softball Conference
YOUTUBE_CHANNEL_ID_3007 = "UC3Z4iXO64pY5rVX6_YVypaQ" #Baseball Insider Channel
YOUTUBE_CHANNEL_ID_3008 = "UCKLFMlGQ3aEzteuHBRgBFSg" #National Hockey League
YOUTUBE_CHANNEL_ID_3009 = "UC3YjaeMWQqjue2MZhRvemBw" #The Best Of The NHL
YOUTUBE_CHANNEL_ID_3010 = "UCJdl3Paao2f3ha5JXMYUCIA" #NFL Throwback Channel
YOUTUBE_CHANNEL_ID_3011 = "UC6tQilchlFnjTiKHz7PEr_A" #The NFL Today Channel
YOUTUBE_CHANNEL_ID_3012 = "PLnaYFo37eXKUvS-SkkgHbMiKxFky4J7IX" #Full Soccer Matches
YOUTUBE_CHANNEL_ID_3013 = "PL3FphI1kGdVosOgQBqpABWjm_Ad5y6gcG" #Soccer-Football Stories
YOUTUBE_CHANNEL_ID_3014 = "PL3EF2E639B8C8B383"                 #NFL Cheerleaders Playlist
YOUTUBE_CHANNEL_ID_3015 = "PL88CEDDB0EA0D2B7F"                 #Cheerleader Playlist
YOUTUBE_CHANNEL_ID_3016 = "" #
YOUTUBE_CHANNEL_ID_3017 = "PLFIO-aq0MK9FH9RfLfhzWJDXJxovM8Gci" #Basketball Playlist
YOUTUBE_CHANNEL_ID_3018 = "MLB"                      #Major League Baseball
YOUTUBE_CHANNEL_ID_3019 = ""
YOUTUBE_CHANNEL_ID_3020 = "UCL6DlB1OXHCasORoQ3c4G9g" #Sexiest Female Fitness Video
YOUTUBE_CHANNEL_ID_3021 = "UC0yNI4_pTF1zZ5x7PxCWSaQ" #US Womens Soccer Channel
YOUTUBE_CHANNEL_ID_3022 = "WorldOfWomensBoxing"      #World Of Womens Boxing Channel
YOUTUBE_CHANNEL_ID_3023 = ""         #
YOUTUBE_CHANNEL_ID_3024 = "WNBA"                     #WNBA Womens Basketball Channel
YOUTUBE_CHANNEL_ID_3025 = "ProWrestlingEVE"          #EVE Womens Wrestling Channel
YOUTUBE_CHANNEL_ID_3026 = "LingerieFootball"         #LFL Womens Football Channel
YOUTUBE_CHANNEL_ID_3027 = "UCSZCjJhBPSuhe7RBMqBLDww" #Sports Girl Montana Channel
YOUTUBE_CHANNEL_ID_3028 = "" #
YOUTUBE_CHANNEL_ID_3029 = "NBA"                      #National Basketball Association
YOUTUBE_CHANNEL_ID_3030 = "UCHec55JASbesAuUEtqRvY2A" #Scottish Womens Football
YOUTUBE_CHANNEL_ID_3031 = "UCyr0EWTSb-yauUp155iTOig" #Womens Professional Lacrosse
YOUTUBE_CHANNEL_ID_3032 = "NHLVideo"                 #National Hockey League
YOUTUBE_CHANNEL_ID_3033 = "" #
YOUTUBE_CHANNEL_ID_3034 = "EnglandNetball"           #England Netball Channel
YOUTUBE_CHANNEL_ID_3035 = "UC_Ep7vU5txy02-rMSCfQYEw" #Womens Volleyball Channel
YOUTUBE_CHANNEL_ID_3036 = "UCqpnwOdD2j26eNjRtdfzu1Q" #Excelle Womens Sports Channel
YOUTUBE_CHANNEL_ID_3037 = "lpwainc"                  #All Women Wrestling Channel
YOUTUBE_CHANNEL_ID_3038 = "UCEO-XUL-udZs-HDEFH-AcGg" #Netball Europe TV Channel
YOUTUBE_CHANNEL_ID_3039 = "UCpYawpeS6vUgtiLdZCi8QRQ" #Womens Australian Football League

YOUTUBE_CHANNEL_ID_3040 = "ProWrestlingEVE"                    #EVE Womens Wrestling Channel
YOUTUBE_CHANNEL_ID_3041 = "" #
YOUTUBE_CHANNEL_ID_3042 = "" #
YOUTUBE_CHANNEL_ID_3043 = "PLSWpYv_bOhw7SNLUrtddXcdEZ3OcuKwuc" #Indie Womens Matches
YOUTUBE_CHANNEL_ID_3044 = "lpwainc"                            #All Women Wrestling Channel
YOUTUBE_CHANNEL_ID_3045 = "PLtAN6pxdpW4Ofrjpp0PwQE1KzHCN-W8iZ" #WWE Womens Matches
YOUTUBE_CHANNEL_ID_3046 = "" #
YOUTUBE_CHANNEL_ID_3047 = "" #
YOUTUBE_CHANNEL_ID_3048 = ""
YOUTUBE_CHANNEL_ID_3049 = "PLeEVBrTMHdSNbr4vtSc5eafH1dyw331Ba" #Best Womens Matches
YOUTUBE_CHANNEL_ID_3050 = "" #
YOUTUBE_CHANNEL_ID_3051 = "PL4PYdqna41zcUh4EYhru8WLLd-I1REr46" #More: Womens Wrestling Matches
YOUTUBE_CHANNEL_ID_3052 = "PL9clXsLdIvqm7n-eu5aEHelm_NvaxVfBv" #Independent Womens Wrestling
YOUTUBE_CHANNEL_ID_3053 = "" #
YOUTUBE_CHANNEL_ID_3054 = "PL26nK03MuWcD-uO2jzqIfllDsjVIHo3se" #Women Of TNA
YOUTUBE_CHANNEL_ID_3055 = "PLFBE78201C74B5A0E"                 #UK Womens Matches
YOUTUBE_CHANNEL_ID_3056 = "PLmdPopYzmrplKAA8O7j27pBe_-okGrafQ" #WWE Bra And Panties Matches
YOUTUBE_CHANNEL_ID_3057 = "UC30Ia39JmGJASWQSyQOQYAQ"           #Shimmer Wrestling Channel
YOUTUBE_CHANNEL_ID_3058 = "UC4_HNKg_uDiGlVBnVbJTdYQ"           #Womans Wrestling Revolution
YOUTUBE_CHANNEL_ID_3059 = "UCV2IP5RtH316GVHwuJB4l2Q"           #WCW Womens Wrestling Classics
YOUTUBE_CHANNEL_ID_3060 = ""           #
YOUTUBE_CHANNEL_ID_3061 = "SHINEWrestling"                     #Shine Womans Wrestling Channel

YOUTUBE_CHANNEL_ID_3062 = "PLQOJdrIdqhW3hB8EuTofununVfX0pBDPa" #WWE Matches, Moments, Segments
YOUTUBE_CHANNEL_ID_3063 = "PLRrCpwYbdXe_Q506LWw6zw1RWQk9fjqR0" #WWE: Championship Matches
YOUTUBE_CHANNEL_ID_3064 = "PLx3e32FQNG9YdX7mYbtcLi_tH_JWBnIj-" #Full WWE Wrestling Matches
YOUTUBE_CHANNEL_ID_3065 = "" #
YOUTUBE_CHANNEL_ID_3066 = "PLAfgWszLXPKKZ0llsIhm3Z9YdSvNq4-Jy" #More WWE Wrestling Matches
YOUTUBE_CHANNEL_ID_3067 = "" #
YOUTUBE_CHANNEL_ID_3068 = ""
YOUTUBE_CHANNEL_ID_3069 = "PLYbcy5TOg9YoIsidjHrrSjDNi2oBRxYDf" #More Full WWE Matches
YOUTUBE_CHANNEL_ID_3070 = "" #
YOUTUBE_CHANNEL_ID_3071 = "" #
YOUTUBE_CHANNEL_ID_3072 = "PLdSb6YVhXagMNl2Spt4MTp7BYyu5TDvqM" #Full Matches WWE Wrestling
YOUTUBE_CHANNEL_ID_3073 = "PLKLX1_yw8ReXLhs5ODFJrul8wBx95MJl3" #WWE: More Wrestling Matches 
YOUTUBE_CHANNEL_ID_3074 = "" #
YOUTUBE_CHANNEL_ID_3075 = "PL3XNTf2rB1vdiT4mdT63RULzfZ96T5YSw" #WWE Full Matches
YOUTUBE_CHANNEL_ID_3076 = "" #
YOUTUBE_CHANNEL_ID_3077 = "" #
YOUTUBE_CHANNEL_ID_3078 = "" #
YOUTUBE_CHANNEL_ID_3079 = "" #
YOUTUBE_CHANNEL_ID_3080 = "" #
YOUTUBE_CHANNEL_ID_3081 = "" #
YOUTUBE_CHANNEL_ID_3082 = "" #
YOUTUBE_CHANNEL_ID_3083 = "" #
YOUTUBE_CHANNEL_ID_3084 = "" #
YOUTUBE_CHANNEL_ID_3085 = "" #
YOUTUBE_CHANNEL_ID_3086 = "" #
YOUTUBE_CHANNEL_ID_3087 = "" #
YOUTUBE_CHANNEL_ID_3088 = "" #
YOUTUBE_CHANNEL_ID_3089 = "" #
YOUTUBE_CHANNEL_ID_3090 = "" #
YOUTUBE_CHANNEL_ID_3091 = "" #
YOUTUBE_CHANNEL_ID_3092 = "" #
YOUTUBE_CHANNEL_ID_3093 = "" #
YOUTUBE_CHANNEL_ID_3094 = "" #
YOUTUBE_CHANNEL_ID_3095 = "" #
YOUTUBE_CHANNEL_ID_3096 = "" #
YOUTUBE_CHANNEL_ID_3097 = "" #
YOUTUBE_CHANNEL_ID_3098 = "" #
YOUTUBE_CHANNEL_ID_3099 = "" #
YOUTUBE_CHANNEL_ID_3100 = "" #
YOUTUBE_CHANNEL_ID_3101 = "" #
YOUTUBE_CHANNEL_ID_3102 = "" #
YOUTUBE_CHANNEL_ID_3103 = "" #
YOUTUBE_CHANNEL_ID_3104 = "PL4HqUCfKObKgtyEGWZnASaCH0qVG5vyZd" #Hardcore: Wrestling Extreme
YOUTUBE_CHANNEL_ID_3105 = "PLF6JtbjTHfLKPGjJoTzNVSbbXLUrxvq3g" #I Quit, No DQ, Cage Match
YOUTUBE_CHANNEL_ID_3106 = "PL1ga3FvCwBgr1XPJLWWs8eaflNmAPqpg-" #Most Violent Matches
YOUTUBE_CHANNEL_ID_3107 = "PLUaUJIgR4uwVydcuBHgVMmib84wU8IGww" #Extreme Rules Matches
YOUTUBE_CHANNEL_ID_3108 = "PLAuDLTEMClpH8OxK_gGCTpq1ZH0eAhifz" #WWE Hardcore Street Fights
YOUTUBE_CHANNEL_ID_3109 = "" #
YOUTUBE_CHANNEL_ID_3110 = "PLSDDUhzpikTk4GZdMOIOSa7ghxahV-rqJ" #Steel Cage Matches
YOUTUBE_CHANNEL_ID_3111 = "PLeN0LMcySIpumCR_E-q9KB8mG3mQQ9Y9N" #Best Of Cage Matches Ever
YOUTUBE_CHANNEL_ID_3112 = "PLeN0LMcySIpt-0P1hRGb55iL3Us6SgVDh" #More Steel Cage Matches
YOUTUBE_CHANNEL_ID_3113 = "" #
YOUTUBE_CHANNEL_ID_3114 = "" #
YOUTUBE_CHANNEL_ID_3115 = "" #
YOUTUBE_CHANNEL_ID_3116 = ""
YOUTUBE_CHANNEL_ID_3117 = "" #
YOUTUBE_CHANNEL_ID_3118 = "" #
YOUTUBE_CHANNEL_ID_3119 = "" #
YOUTUBE_CHANNEL_ID_3120 = "" #
YOUTUBE_CHANNEL_ID_3121 = "" #
YOUTUBE_CHANNEL_ID_3122 = "" #
YOUTUBE_CHANNEL_ID_3123 = "" #
YOUTUBE_CHANNEL_ID_3124 = "" #
YOUTUBE_CHANNEL_ID_3125 = "" #
YOUTUBE_CHANNEL_ID_3126 = "" #
YOUTUBE_CHANNEL_ID_3127 = "PL53kKJBMWATdIPkA-8x6JXUhr8sE5zC9l" #ROH Throwback Thursday
YOUTUBE_CHANNEL_ID_3128 = "PL53kKJBMWATcFGQFDJeUHiV_hWzHb6TJw" #ROH Women Of Honor
YOUTUBE_CHANNEL_ID_3129 = "PL53kKJBMWATc3B9l7g65tXusV3F5nC1LK" #ROH Future Of Honor
YOUTUBE_CHANNEL_ID_3130 = "PLVJTeNTGVLAS6AfQr-P3AFlvqcPMogTf3" #ROH Full Matches
YOUTUBE_CHANNEL_ID_3131 = "PL-ZV3jb0LhLJZjygvojD04l0pEbSL_oOq" #Full ROH Matches
YOUTUBE_CHANNEL_ID_3132 = "PLeN0LMcySIpthoJv2hs7Sif5Td-3PHzDj" #Best ROH PPV Matches
YOUTUBE_CHANNEL_ID_3133 = "PL8cVQv887SU8IcYrsp8kyTGAPuOvLmfPp" #ROH Wrestling Matches
YOUTUBE_CHANNEL_ID_3134 = "" #
YOUTUBE_CHANNEL_ID_3135 = ""
YOUTUBE_CHANNEL_ID_3136 = "" #
YOUTUBE_CHANNEL_ID_3137 = "PLDTodg3Ir4nkV4vruDIJ8oTcwUCkg6tVp" #ROH Old School Matches
YOUTUBE_CHANNEL_ID_3138 = "" #
YOUTUBE_CHANNEL_ID_3139 = "" #
YOUTUBE_CHANNEL_ID_3140 = "" #
YOUTUBE_CHANNEL_ID_3141 = "" #
YOUTUBE_CHANNEL_ID_3142 = "PLQOJdrIdqhW3bSbk9hzLLxGcPCyqsQQtP" #TNA Impact Full Matches
YOUTUBE_CHANNEL_ID_3143 = "PLcovtt7Bdo9OvxEgoKSbHIIdnlXmPCHi4" #TNA Impact Wrestling
YOUTUBE_CHANNEL_ID_3144 = "PLfMyxLDt3AL3RDf_BXUccO2BbT2BZXSdx" #TNA: More Impact Matches
YOUTUBE_CHANNEL_ID_3145 = "PLqUuiw4Ti8ejAKENB6rv-Xlph311UQDOd" #More TNA Impact Wrestling
YOUTUBE_CHANNEL_ID_3146 = "" #
YOUTUBE_CHANNEL_ID_3147 = "" #
YOUTUBE_CHANNEL_ID_3148 = "PL__aOPh91sYQaWhJtieAwve0mh16Igz4J" #More TNA Wrestling Matches
YOUTUBE_CHANNEL_ID_3149 = "" #
YOUTUBE_CHANNEL_ID_3150 = "" #
YOUTUBE_CHANNEL_ID_3151 = "" #
YOUTUBE_CHANNEL_ID_3152 = "" #
YOUTUBE_CHANNEL_ID_3153 = "" #
YOUTUBE_CHANNEL_ID_3154 = "" #
YOUTUBE_CHANNEL_ID_3155 = "" #
YOUTUBE_CHANNEL_ID_3156 = "" #
YOUTUBE_CHANNEL_ID_3157 = "" #
YOUTUBE_CHANNEL_ID_3158 = "" #
YOUTUBE_CHANNEL_ID_3159 = "PLeEVBrTMHdSNwTZGkyD81rkKhucIkAWev" #Best Pro Wrestling Docs
YOUTUBE_CHANNEL_ID_3160 = ""
YOUTUBE_CHANNEL_ID_3161 = "PLNTRH86YJ3X4muXoM_l1z0EpAnexp38U7" #Wrestling Documentaries
YOUTUBE_CHANNEL_ID_3162 = "PLJvhNArd_uPTj1IIde7DbxjjXN40K9PyX" #Pro Wrestling Documentaries
YOUTUBE_CHANNEL_ID_3163 = "" #
YOUTUBE_CHANNEL_ID_3164 = "PLmR1K1XZbpMfcjo8ryf_nu1E8IOHFocs7" #Wrestling Docs
YOUTUBE_CHANNEL_ID_3165 = "" #
YOUTUBE_CHANNEL_ID_3166 = "" #
YOUTUBE_CHANNEL_ID_3167 = "" #
YOUTUBE_CHANNEL_ID_3168 = "" #
YOUTUBE_CHANNEL_ID_3169 = "" #
YOUTUBE_CHANNEL_ID_3170 = "PL394E56A0B632C016"                 #Rugby Sports
YOUTUBE_CHANNEL_ID_3171 = "PLItvZTYiHnTaVEjKYLB5BLuLnamqQx2W-" #ESPN-Sports Docs
YOUTUBE_CHANNEL_ID_3172 = "" #
YOUTUBE_CHANNEL_ID_3173 = "PLq-isVVF3foenhVLcdsGj1ww63hXKrso8" #Baseball docs
YOUTUBE_CHANNEL_ID_3174 = "PLCkP5LViwv1hpdmDR0WzOcCvOzMmAerUL" #Wrestling Docs
YOUTUBE_CHANNEL_ID_3175 = "" #
YOUTUBE_CHANNEL_ID_3176 = "" #
YOUTUBE_CHANNEL_ID_3177 = "PLEvvOXV5cPRK0g0-0shgK0WRtUTry-FeZ" #Docs Sports
YOUTUBE_CHANNEL_ID_3178 = "PL838C8D33F6CEB552"                 #Mountaineering Docs
YOUTUBE_CHANNEL_ID_3179 = "" #UK Football Docs
YOUTUBE_CHANNEL_ID_3180 = "" #
YOUTUBE_CHANNEL_ID_3181 = "" #
YOUTUBE_CHANNEL_ID_3182 = "" #
YOUTUBE_CHANNEL_ID_3183 = "" #
YOUTUBE_CHANNEL_ID_3184 = "" #
YOUTUBE_CHANNEL_ID_3185 = "" #
YOUTUBE_CHANNEL_ID_3186 = "" #
YOUTUBE_CHANNEL_ID_3187 = "" #

YOUTUBE_CHANNEL_ID_3200 = "BritishJudo"                        #British Judo Channel
YOUTUBE_CHANNEL_ID_3201 = "heywhatism"                         #Cage Amateurs UK Channel
YOUTUBE_CHANNEL_ID_3202 = "UCftoEcnuRiSXle5lkeZlj8A"           #This Is Boxing UK Channel
YOUTUBE_CHANNEL_ID_3203 = "TheABAE"                            #England Boxing Channel
YOUTUBE_CHANNEL_ID_3204 = "UCsh3KEdqa-8eBj5Noh3iU5Q"           #UK Fighting Championships
YOUTUBE_CHANNEL_ID_3205 = "" #
YOUTUBE_CHANNEL_ID_3206 = "gawjusboy"                          #Classic Boxing Matches
YOUTUBE_CHANNEL_ID_3207 = "johnnysmack7"                       #Boxing Now Channel
YOUTUBE_CHANNEL_ID_3208 = "WorldSeriesBoxing"                  #World Series Of Boxing
YOUTUBE_CHANNEL_ID_3209 = "UC_JQGBtA7P0RwkRxd7xpJcA"           #Sky Sports Boxing Channel
YOUTUBE_CHANNEL_ID_3210 = "PLEVC1_PrCuxsKg-X8C_ldNLzUktnlnDDL" #Best UFC Match Playlist
YOUTUBE_CHANNEL_ID_3211 = "" #
YOUTUBE_CHANNEL_ID_3212 = "PLPVKuYK1J1SVtSjdj9DZVwjxn27WMvsmb" #MMA Matches Playlist



YOUTUBE_CHANNEL_ID_3213 = "BellatorMMA"                        #Bellator-MMA Channel
YOUTUBE_CHANNEL_ID_3214 = "HBOsports"                          #HBO Sports Boxing
YOUTUBE_CHANNEL_ID_3215 = "PLn3nHXu50t5zQbI4levwfsjVhEb6_YNw0" #Boxing on ESPN
YOUTUBE_CHANNEL_ID_3216 = "UFC"                                #UFC 243 Channel
YOUTUBE_CHANNEL_ID_3217 = "UCO4AcsPKEkIqDmbeiZLfd1A"           #ESPN MMA Channel
YOUTUBE_CHANNEL_ID_3218 = "UCEeMsInLdrUbIkbEcNm7g-A"           #Bare Knuckles Fighting
YOUTUBE_CHANNEL_ID_3219 = "UCevutfii4WMg6-rdJ30nV3Q"           #Bare Knuckles Boxing
YOUTUBE_CHANNEL_ID_3220 = "" #
YOUTUBE_CHANNEL_ID_3221 = "judo"                               #The Judo Channel
YOUTUBE_CHANNEL_ID_3222 = "WKFKarateWorldChamps"               #World Karate Federation
YOUTUBE_CHANNEL_ID_3223 = ""                          #
YOUTUBE_CHANNEL_ID_3224 = "" #
YOUTUBE_CHANNEL_ID_3225 = "" #
YOUTUBE_CHANNEL_ID_3226 = "" #
YOUTUBE_CHANNEL_ID_3227 = "" #
YOUTUBE_CHANNEL_ID_3228 = "" #
YOUTUBE_CHANNEL_ID_3229 = "" #
YOUTUBE_CHANNEL_ID_3230 = "" #
YOUTUBE_CHANNEL_ID_3231 = "" #
YOUTUBE_CHANNEL_ID_3232 = "" #
YOUTUBE_CHANNEL_ID_3233 = "" #
YOUTUBE_CHANNEL_ID_3234 = "" #
YOUTUBE_CHANNEL_ID_3235 = "" #
YOUTUBE_CHANNEL_ID_3236 = "" #
YOUTUBE_CHANNEL_ID_3237 = "" #
YOUTUBE_CHANNEL_ID_3238 = "" #
YOUTUBE_CHANNEL_ID_3239 = "" #
YOUTUBE_CHANNEL_ID_3240 = "" #
YOUTUBE_CHANNEL_ID_3241 = "" #
YOUTUBE_CHANNEL_ID_3242 = "" #
YOUTUBE_CHANNEL_ID_3243 = "" #
YOUTUBE_CHANNEL_ID_3244 = "" #
YOUTUBE_CHANNEL_ID_3245 = "" #
YOUTUBE_CHANNEL_ID_3246 = "" #
YOUTUBE_CHANNEL_ID_3247 = "UC92zCMeQJdH8ChEamXZxSeQ" #British Darts Organisation
YOUTUBE_CHANNEL_ID_3248 = "UEFA"                     #UEFA Football Channel
YOUTUBE_CHANNEL_ID_3249 = "Racingukcom"              #Racing TV International
YOUTUBE_CHANNEL_ID_3250 = "ESPNUK"                   #ESPN UK Sports Channel
YOUTUBE_CHANNEL_ID_3251 = "UCIDpVCpsD0ovG3ZEwyTHN7Q" #Total Football Channel
YOUTUBE_CHANNEL_ID_3252 = "UC6c1z7bA__85CIWZ_jpCK-Q" #ESPN FC Sports Channel
YOUTUBE_CHANNEL_ID_3253 = "OfficialSUFC"             #Southend United Football
YOUTUBE_CHANNEL_ID_3254 = "UCdbLkEAqBERZ2jnVeBbNgdw" #Premier League Scorenga
YOUTUBE_CHANNEL_ID_3255 = "PLZSoccer"                #PLZ: The Football Show
YOUTUBE_CHANNEL_ID_3256 = "Channel4Racing"           #Channel 4 Sport Channel
YOUTUBE_CHANNEL_ID_3257 = "irb"                      #World Rugby Channel
YOUTUBE_CHANNEL_ID_3258 = "UCf7dFu8DUrga7ZtmD1P6_Yg" #Lacrosse Live UK Channel
YOUTUBE_CHANNEL_ID_3259 = "ecbcricket"               #England And Wales Cricket
YOUTUBE_CHANNEL_ID_3260 = "IHUKTV"                   #IIHF UK Ice Hockey Channel
YOUTUBE_CHANNEL_ID_3261 = "UCqusq25VkDvkqDFhmE9MsOA" #British Universities Hockey
YOUTUBE_CHANNEL_ID_3262 = "TWSfeatures"              #Trans World Sport Channel
YOUTUBE_CHANNEL_ID_3263 = "ESquashandRacketball"     #British Squash & Racketball
YOUTUBE_CHANNEL_ID_3264 = "UC-cGWaqo-1BYRlzJa5Aet3A" #UK Motorsports Channel
YOUTUBE_CHANNEL_ID_3265 = "UCh_m0ZxqqFIr_B6xoBbVJYQ" #Petrol Heads GTR Channel
YOUTUBE_CHANNEL_ID_3266 = "PurePerformanceCars"      #Pure Performance Cars
YOUTUBE_CHANNEL_ID_3267 = "" #
YOUTUBE_CHANNEL_ID_3268 = "" #
YOUTUBE_CHANNEL_ID_3269 = "" #
YOUTUBE_CHANNEL_ID_3270 = "" #
YOUTUBE_CHANNEL_ID_3271 = "" #
YOUTUBE_CHANNEL_ID_3272 = "" #
YOUTUBE_CHANNEL_ID_3273 = "" #
YOUTUBE_CHANNEL_ID_3274 = "" #
YOUTUBE_CHANNEL_ID_3275 = "UCbecoXjmR4qHMug6TXAKvIg" #Ultimate Hunting Channel
YOUTUBE_CHANNEL_ID_3276 = "DDHONLINE"                #Deer & Deer Hunting Channel
YOUTUBE_CHANNEL_ID_3277 = "HUNTERSlinkdotcom"        #Hunt The Break Channel
YOUTUBE_CHANNEL_ID_3278 = "YourHuntingBuddy"         #Your Hunting Buddy Channel
YOUTUBE_CHANNEL_ID_3279 = "OutdoorAdventures"        #Keith Warren Hunting
YOUTUBE_CHANNEL_ID_3280 = "UCOexTpEq5Sr_X_isjniKiRA" #Craig Boddington Hunter
YOUTUBE_CHANNEL_ID_3281 = "UCVSdvmmU6bSZaw5L98pPHpg" #Hunt Appalachia Channel
YOUTUBE_CHANNEL_ID_3282 = "PaulKorn1031"             #Paul Korn Bow Hunting Channel
YOUTUBE_CHANNEL_ID_3283 = "FowledReality"            #Fowled Reality Duck & Goose
YOUTUBE_CHANNEL_ID_3284 = "UCmlzr40EP1RQEel4Jt-4SgA" #Animals, Nature, Hunting
YOUTUBE_CHANNEL_ID_3285 = "" #
YOUTUBE_CHANNEL_ID_3286 = "" #
YOUTUBE_CHANNEL_ID_3287 = "" #
YOUTUBE_CHANNEL_ID_3288 = "" #
YOUTUBE_CHANNEL_ID_3289 = "" #
YOUTUBE_CHANNEL_ID_3290 = "" #
YOUTUBE_CHANNEL_ID_3291 = "" #
YOUTUBE_CHANNEL_ID_3292 = "" #
YOUTUBE_CHANNEL_ID_3293 = "" #
YOUTUBE_CHANNEL_ID_3294 = "" #
YOUTUBE_CHANNEL_ID_3295 = "" #
YOUTUBE_CHANNEL_ID_3296 = "" #
YOUTUBE_CHANNEL_ID_3297 = "" #
YOUTUBE_CHANNEL_ID_3298 = "" #
YOUTUBE_CHANNEL_ID_3299 = "" #
YOUTUBE_CHANNEL_ID_3300 = "jsaxsm"                   #Motocross,MX, Rally
YOUTUBE_CHANNEL_ID_3301 = "UC-cGWaqo-1BYRlzJa5Aet3A" #UK Motorsports Channel
YOUTUBE_CHANNEL_ID_3302 = "UCh_m0ZxqqFIr_B6xoBbVJYQ" #Petrol Heads GTR Channel
YOUTUBE_CHANNEL_ID_3303 = "PurePerformanceCars"      #Pure Performance Cars
YOUTUBE_CHANNEL_ID_3304 = "UC1QQAUSQX4DF9XXne54oCgQ" #Motorsports On NBC Channel
YOUTUBE_CHANNEL_ID_3305 = "MotorRacingNetwork"       #Motor Racing Network Channel
YOUTUBE_CHANNEL_ID_3306 = "BobamaticZero"            #Monster Truck Madness Too
YOUTUBE_CHANNEL_ID_3307 = "UCkj7Gb4RBmu5fJToq70c3MQ" #Monster Truck Madness
YOUTUBE_CHANNEL_ID_3308 = "FLkj7Gb4RBmu5fJToq70c3MQ" #Monster Truck Playlist
YOUTUBE_CHANNEL_ID_3309 = "NascarFullRaces"          #Nascar Full Races Channel
YOUTUBE_CHANNEL_ID_3310 = "euroracecar"              #Nascar Whelen Euro Series
YOUTUBE_CHANNEL_ID_3311 = "Formula1"                 #Formula 1 Channel
YOUTUBE_CHANNEL_ID_3312 = "TheOfficialNASCAR"        #Nascar Official Channel
YOUTUBE_CHANNEL_ID_3313 = "nhra"                     #National Hot Rod Association
YOUTUBE_CHANNEL_ID_3314 = "" #
YOUTUBE_CHANNEL_ID_3315 = "" #
YOUTUBE_CHANNEL_ID_3316 = "" #
YOUTUBE_CHANNEL_ID_3317 = "" #
YOUTUBE_CHANNEL_ID_3318 = "" #
YOUTUBE_CHANNEL_ID_3319 = "" #
YOUTUBE_CHANNEL_ID_3320 = "" #

YOUTUBE_CHANNEL_ID_3373 = "" #

YOUTUBE_CHANNEL_ID_3400 = "UC_7yB-Q_5XVLGX-PbORB50Q" #Sport Fishing Television
YOUTUBE_CHANNEL_ID_3401 = "UCqBQ3N3rskMwzgQMRkgPCXA" #Local Knowledge Fishing
YOUTUBE_CHANNEL_ID_3402 = "UCVBRCVBWvWjU0dTV7O40F1g" #Fishing Grubbz Channel
YOUTUBE_CHANNEL_ID_3403 = "UCvY4YIZ5QTgZwxb9fIYGfvA" #Jetti Rock Fishing Channel
YOUTUBE_CHANNEL_ID_3404 = "UC-FwYp4I-TppMxGHEmCQWbw" #Rad Reeling Fishing Channel
YOUTUBE_CHANNEL_ID_3405 = "UCus_QaigGsWXmbkAh1tL0gA" #Fishing With Nordbye Channel
YOUTUBE_CHANNEL_ID_3406 = "FishingwithJohnny"        #Fishing With Johnny Johnson
YOUTUBE_CHANNEL_ID_3407 = "dansportfishing"          #Sport Fishing Dan Hernandez
YOUTUBE_CHANNEL_ID_3408 = "UCxGQMCT70DALylKj9CQl2sw" #Orvis Guide To Fly Fishing
YOUTUBE_CHANNEL_ID_3409 = "UCvP0q4WZLtgmfh107XV2MCw" #Creek Fishing Adventures
YOUTUBE_CHANNEL_ID_3410 = "UCulRvpVNS-pu7W1jPM8SSoA" #Reel Fishing Noob Channel
YOUTUBE_CHANNEL_ID_3411 = "fishingaddiction100"      #Southern Fishing Addiction
YOUTUBE_CHANNEL_ID_3412 = "UCDMsGkccxUkO_iXz4SKp9pQ" #The Catch Fishing Channel
YOUTUBE_CHANNEL_ID_3413 = "UCSOw0bd5cGM3RXuALoKSfUA" #Prestige Worldwide Fishing
YOUTUBE_CHANNEL_ID_3414 = "PL0PTdhK8s-5QxWhL4o9cK5xZDzdfoZx6c" #Robson Green Fishing
YOUTUBE_CHANNEL_ID_3415 = "PLKhPstAakbEdzU-e3UwOglKg7w-Bjvj2C" #Bassmaster Fishing


YOUTUBE_CHANNEL_ID_3538 = "UCv6q14mfd6K-kYCzqUFMcEA" #Lucha Underground Channel
YOUTUBE_CHANNEL_ID_3539 = "UCaN1vfY2wREOeV-oUB4KQ4g" #Pro Wrestling Guerrilla
YOUTUBE_CHANNEL_ID_3540 = "luchalibreaaatv"          #Lucha Libre AAA Channel
YOUTUBE_CHANNEL_ID_3541 = "UCZaS14idYb591IbxLqcyNQA" #Progress Wrestling Channel
YOUTUBE_CHANNEL_ID_3542 = "" #
YOUTUBE_CHANNEL_ID_3543 = "UCTNT9N8pIx1Q4vgVwZHObkQ" #Rockstar Pro Wrestling
YOUTUBE_CHANNEL_ID_3544 = "ringofhonor"              #Ring Of Honor Wrestling Channel
YOUTUBE_CHANNEL_ID_3545 = "WWEFanNation"             #WWE Official Channel
YOUTUBE_CHANNEL_ID_3546 = "BeyondWrestling"          #Beyond Wrestling Channel
YOUTUBE_CHANNEL_ID_3547 = "TNAwrestling"             #Impact Wrestling Channel
YOUTUBE_CHANNEL_ID_3548 = "CZWNews"                  #Combat Zone Wrestling
YOUTUBE_CHANNEL_ID_3549 = "majorleaguewrestling"     #Major League Wrestling Channel
YOUTUBE_CHANNEL_ID_3550 = "UC1lgJkpCx_0SMzsvrTCdxPw" #New Japan Pro Wrestling
YOUTUBE_CHANNEL_ID_3551 = ""
YOUTUBE_CHANNEL_ID_3552 = "TheBookerTROW"            #Reality Of Wrestling
YOUTUBE_CHANNEL_ID_3553 = "luchalibreaaatv"          #Lucha Libre AAA TV Channel
YOUTUBE_CHANNEL_ID_3554 = "UCFN4JkGP_bVhAdBsoV9xftA" #All Elite Wrestling Channel
YOUTUBE_CHANNEL_ID_3555 = "UCFAA7NmLmwcL9bbX_gXEV0g" #Evolve Wrestling Channel
YOUTUBE_CHANNEL_ID_3556 = "UCSHCTJS2P4Hvu_reLKtiT6g" #NWA: National Wrestling Alliance
YOUTUBE_CHANNEL_ID_3557 = "" #
YOUTUBE_CHANNEL_ID_3558 = "" #
YOUTUBE_CHANNEL_ID_3559 = "" #
YOUTUBE_CHANNEL_ID_3560 = "" #
YOUTUBE_CHANNEL_ID_3561 = "" #
YOUTUBE_CHANNEL_ID_3562 = "" #
YOUTUBE_CHANNEL_ID_3563 = "" #
YOUTUBE_CHANNEL_ID_3564 = "" #
YOUTUBE_CHANNEL_ID_3565 = "" #
YOUTUBE_CHANNEL_ID_3566 = "" #
YOUTUBE_CHANNEL_ID_3567 = "" #
YOUTUBE_CHANNEL_ID_3568 = "" #
YOUTUBE_CHANNEL_ID_3569 = "" #
YOUTUBE_CHANNEL_ID_3570 = "" #
YOUTUBE_CHANNEL_ID_3571 = "" #
YOUTUBE_CHANNEL_ID_3572 = "" #
YOUTUBE_CHANNEL_ID_3573 = "PL8fVUTBmJhHKq0MhIplzljtGhHN2E_jk0" #Live Youtube Sports

YOUTUBE_CHANNEL_ID_3600 = "UCdwEl3-QFixMQW2IzWjdhpw" #Total Womans Wrestling
YOUTUBE_CHANNEL_ID_3601 = "BritishBombshells"        #British Bombshells Channel
YOUTUBE_CHANNEL_ID_3602 = "WrestlingDivaz"           #Wrestling Divaz Channel

#@route(mode='womenssports')
def WomensSports():

	add_link_info('[B][COLORorange]== Womens Sports ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Sexiest Female Fitness Video[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3020+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]US Womens Soccer Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3021+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World Of Womens Boxing Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3022+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WNBA Womens Basketball Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3024+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]EVE Womens Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3025+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]LFL Womens Football Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3026+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sports Girl Montana Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3027+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Scottish Womens Football[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3030+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womens Professional Lacrosse[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3031+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]England Netball Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3034+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womens Volleyball Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3035+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Excelle Womens Sports Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3036+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Women Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3037+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Netball Europe TV Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3038+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womens Australian Football League[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3039+"/", folder=True,
		icon=mediapath+"WomensSports.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='gamesports')
def GameSports():

	add_link_info('[B][COLORorange]== Game Sports ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]National Football League[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3003+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Major League Baseball[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3018+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Basketball Assoc.[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3029+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Hockey League[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3032+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]US Soccer Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3000+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Big Mind Sports Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3004+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]MLB Network Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3005+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World Baseball Softball Conference[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3006+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Baseball Insider Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3007+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Hockey League[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3008+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Best Of The NHL[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3009+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NFL Throwback Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3010+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The NFL Today Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3011+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Soccer Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3012+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Soccer-Football Stories[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3013+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NFL Cheerleaders Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3014+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cheerleader Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3015+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Basketball Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3017+"/", folder=True,
		icon=mediapath+"GameSports.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='combat')
def Combat():

	add_link_info('[B][COLORorange]== Combat Sports ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]HBO Sports Boxing[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3214+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Boxing On ESPN[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3215+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UFC 243 Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3216+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ESPN MMA Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3217+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Best UFC Match Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3210+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Bellator MMA Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3213+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]MMA Matches Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3212+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cage Amateurs UK Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3201+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]This Is Boxing UK Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3202+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]England Boxing Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3203+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Fighting Championships[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3204+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Classic Boxing Matches[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3206+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Boxing Now Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3207+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]World Series Of Boxing[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3208+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Sky Sports Boxing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3209+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Bare Knuckles Fighting[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3218+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Bare Knuckles Boxing[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3219+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]World Karate Federation[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3222+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Judo Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3200+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The Judo Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3221+"/", folder=True,
		icon=mediapath+"combat.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='docs_sports')
def Docs_sports():

	add_link_info('[B][COLORorange]== Sports Docs ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Best Pro Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3159+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rugby Sports Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3170+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ESPN-Sports Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3171+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3161+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Baseball Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3173+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3162+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3164+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sports Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3177+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mountaineering Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3178+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Documentaries: Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3174+"/", folder=True,
		icon=mediapath+"DocsSports.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='fishing')
def Fishing():

	add_link_info('[B][COLORorange]== Fishing ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Sport Fishing Television[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3400+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Local Knowledge Fishing[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3401+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fishing Grubbz Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3402+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jetti Rock Fishing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3403+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rad Reeling Fishing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3404+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fishing With Nordbye Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3405+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fishing With Johnny Johnson[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3406+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sport Fishing Dan Hernandez[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3407+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Orvis Guide To Fly Fishing[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3408+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Creek Fishing Adventures[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3409+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reel Fishing Noob Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3410+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Southern Fishing Addiction[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3411+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Catch Fishing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3412+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Prestige Worldwide Fishing[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3413+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Robson Green Fishing[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3414+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bassmaster Fishing[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3415+"/", folder=True,
		icon=mediapath+"fishing.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='womenswrestling')
def WomensWrestling():

	add_link_info('[B][COLORorange]== Womens Wrestling ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]WCW Womens Wrestling Classics[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3059+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shine Womans Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3061+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shimmer Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3057+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womans Wrestling Revolution[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3058+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]EVE Womens Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3040+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Women Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3044+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Bombshells Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3601+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Total Womans Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3600+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Divaz Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3602+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Women Of Honor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3128+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Indie Womens Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3043+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3045+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Best Womens Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3049+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More: Womens Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3051+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Independent Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3052+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Women Of TNA Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3054+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3055+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Bra And Panties Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3056+"/", folder=True,
		icon=mediapath+"WomansWrestling.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='sportswrestling')
def SportsWrestling():

	add_link_info('[B][COLORorange]== Wrestling ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3545+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Impact Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3547+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ring Of Honor Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3544+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Elite Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3554+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lucha Underground Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3538+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Japan Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3550+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Major League Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3549+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Evolve Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3555+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reality Of Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3552+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Lucha Libre AAA Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3540+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Wrestling Alliance[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3556+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Guerrilla[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3539+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Progress Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3541+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rockstar Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3543+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Beyond Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3546+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Combat Zone Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3548+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Matches, Moments, Segments[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3062+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE: Championship Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3063+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full WWE Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3064+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More WWE Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3066+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Full WWE Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3069+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Matches WWE Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3072+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE: More Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3073+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Throwback Thursday[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3127+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]ROH Women Of Honor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3128+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Future Of Honor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3129+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3130+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full ROH Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3131+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best ROH PPV Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3132+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3133+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Old School Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3137+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TNA Impact Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3142+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]TNA Impact Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3143+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TNA: More Impact Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3144+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More TNA Impact Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3145+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More TNA Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3148+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Hardcore: Wrestling Extreme[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3104+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]I Quit, No DQ, Cage Match[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3105+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Most Violent Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3106+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Extreme Rules Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3107+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Hardcore Street Fights[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3108+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Steel Cage Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3110+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Of Cage Matches Ever[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3111+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]More Steel Cage Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3112+"/", folder=True,
		icon=mediapath+"SportsWrestling.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='eurosports')
def Eurosports():

	add_link_info('[B][COLORorange]== Euro Sports ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]UK Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3055+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UEFA Football Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3248+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]England Netball Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3034+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Rugby Sports Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3170+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Judo Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3200+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cage Amateurs UK Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3201+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]This Is Boxing UK Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3202+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]England Boxing Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3203+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Fighting Championships[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3204+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sky Sports Boxing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3209+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Racing TV International[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3249+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ESPN UK Sports Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3250+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Total Football Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3251+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ESPN FC Sports Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3252+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Southend United Football[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3253+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Premier League Scorenga[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3254+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PLZ: The Football Show[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3255+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel 4 Sport Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3256+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lacrosse Live UK Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3258+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World Rugby Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3257+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]England And Wales Cricket[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3259+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IIHF UK Ice Hockey Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3260+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Universities Hockey[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3261+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Trans World Sport Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3262+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Squash & Racketball[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3263+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Darts Organisation[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3247+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Motorsports Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3264+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Petrol Heads GTR Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3265+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pure Performance Cars[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3266+"/", folder=True,
		icon=mediapath+"eurosports.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='motorsports')
def Motorsports():

	add_link_info('[B][COLORorange]== Motor Sports ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Formula 1 Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3311+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nascar Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3312+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Hot Rod Association[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3313+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pure Performance Cars[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3303+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Petrol Heads GTR Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3302+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Motorsports Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3301+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Motocross,MX, Rally[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3300+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Motorsports On NBC Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3304+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Motor Racing Network Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3305+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Truck Madness Too[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3306+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Truck Madness[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3307+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Truck Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3308+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nascar Full Races Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3309+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nascar Whelen Euro Series[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3310+"/", folder=True,
		icon=mediapath+"motorsports.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#@route(mode='hunting')
def Hunting():

	add_link_info('[B][COLORorange]== Hunting ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Ultimate Hunting Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3275+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Deer & Deer Hunting Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3276+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hunt The Break Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3277+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Your Hunting Buddy Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3278+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Keith Warren Hunting[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3279+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Craig Boddington Hunter[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3280+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hunt Appalachia Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3281+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paul Korn Bow Hunting Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3282+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fowled Reality Duck & Goose[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_3283+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animals, Nature, Hunting[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_3284+"/", folder=True,
		icon=mediapath+"hunting.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
