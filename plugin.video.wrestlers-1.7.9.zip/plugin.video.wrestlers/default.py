
import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
#import urllib2

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

import wrestlingGenres
import wrestleArchives
import wrestleMatches
import wrestleEvents
import wrestleNews
import wrestleDocs

from resources.lib.modules.scraper import *
from resources.lib.modules.indyMOD import *
from resources.lib.modules.showVID import *
from resources.lib.modules.wrestlers import *
from resources.lib.modules.common import *
		
params = get_params()
mode = None

#===============================================================================

addon_id = xbmcaddon.Addon().getAddonInfo('id') 
selfAddon = xbmcaddon.Addon(id=addon_id)

try:
    datapath= xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
except:
    datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.wrestlers')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

try:
    fanart = xbmcvfs.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmcvfs.translatePath(os.path.join(home, 'icon.png'))
except:
    fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmc.translatePath(os.path.join(home, 'icon.png'))

art = 'special://home/addons/script.j1.artwork/lib/resources/art/'
mediapath = 'http://j1wizard.net/media/'

#===============================================================================

#@route(mode='main')
def Main():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', icon, fanart)
	addDirMain('[COLOR white][B]Premiers & Live Shows[/B][/COLOR]','url',405,mediapath+'events.png', fanart)
	addDirMain('[COLOR white][B]Episodes & Kickoffs[/B][/COLOR]','url',81,mediapath+'episodes.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Archives[/B][/COLOR]','url',82,mediapath+'archive.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Matches[/B][/COLOR]','url',83,mediapath+'match.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Documentary[/B][/COLOR]',BASE,404,mediapath+'wrestlersdocs.png', fanart)
	addDirMain('[COLOR white][B]News, Rumors, Updates[/B][/COLOR]','url',400,mediapath+'news.png', fanart)
	addDirMain('[COLOR white][B]Wrestling Channels[/B][/COLOR]',BASE,700,mediapath+'wchannels.png', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling[/B][/COLOR]',BASE,70,mediapath+'wwe.png', fanart)
	addDirMain('[COLOR white][B]AEW Wrestling[/B][/COLOR]',BASE,701,mediapath+'aew.png', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling[/B][/COLOR]',BASE,72,mediapath+'roh.png', fanart)
	addDirMain('[COLOR white][B]Impact Wrestling[/B][/COLOR]',BASE,73,mediapath+'impact.png', fanart)
	addDirMain('[COLOR white][B]Indy Playlists[/B][/COLOR]','url',406,mediapath+'playlist.png', fanart)
	addDirMain('[COLOR white][B]Womens Wrestling[/B][/COLOR]',BASE,74,mediapath+'women.png', fanart)
	addDirMain('[COLOR white][B]Legends Of Wrestling[/B][/COLOR]',BASE,75,mediapath+'legends.png', fanart)
	addDirMain('[COLOR white][B]Classic ECW Wrestling[/B][/COLOR]',BASE,76,mediapath+'ecw.png', fanart)
	addDirMain('[COLOR white][B]Classic WCW Wrestling[/B][/COLOR]',BASE,77,mediapath+'wcw.png', fanart)
	addDirMain('[COLOR white][B]Documentary Playlists[/B][/COLOR]',BASE,78,mediapath+'wrestlersdocP.jpg', fanart)
	addDirMain('[COLOR white][B]Other Indie Promotions[/B][/COLOR]',BASE,79,mediapath+'indie.png', fanart)
	addDirMain('[COLOR white][B]Tables, Ladders, And Steel[/B][/COLOR]',BASE,80,mediapath+'steel.png', fanart)
	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

#@route(mode='genrelist')
def genreList():

	add_link_info('[B][COLORorange]Choose Episode Genre[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Wrestling Shows[/B][/COLOR]',BASE,402,art+'episodes.jpg', fanart)
	addDirMain('[COLOR white][B]AEW Wrestling Shows[/B][/COLOR]',BASE,410,art+'aew.jpg', fanart)
	addDirMain('[COLOR white][B]MLW Wrestling Shows[/B][/COLOR]',BASE,412,art+'mlw.jpg', fanart)
	addDirMain('[COLOR white][B]NWA Wrestling Shows[/B][/COLOR]',BASE,415,art+'nwa.jpg', fanart)
	addDirMain('[COLOR white][B]OVW Wrestling Shows[/B][/COLOR]',BASE,426,art+'ovw.jpg', fanart)
	addDirMain('[COLOR white][B]ROW Wrestling Shows[/B][/COLOR]',BASE,414,art+'row.jpg', fanart)
	addDirMain('[COLOR white][B]WLW Wrestling Shows[/B][/COLOR]',BASE,424,art+'wlw.jpg', fanart)
	addDirMain('[COLOR white][B]Championship Wrestling[/B][/COLOR]',BASE,418,art+'champ.jpg', fanart)
	addDirMain('[COLOR white][B]Appalachian Mountain[/B][/COLOR]',BASE,433,art+'amw.jpg', fanart)
	addDirMain('[COLOR white][B]Rocky Mountain Pro[/B][/COLOR]',BASE,425,art+'rmp.jpg', fanart)
	addDirMain('[COLOR white][B]GCW Wrestling Shows[/B][/COLOR]',BASE,420,art+'gcw.jpg', fanart)
	addDirMain('[COLOR white][B]Deadlock Pro Shows[/B][/COLOR]',BASE,450,art+'dpw.jpg', fanart)
	addDirMain('[COLOR white][B]WWA Wrestling Shows[/B][/COLOR]',BASE,443,art+'wwa.jpg', fanart)
	addDirMain('[COLOR white][B]IWRG Wrestling[Shows[/B][/COLOR]',BASE,429,art+'iwrg.jpg', fanart)
	addDirMain('[COLOR white][B]Mas Lucha Wrestling[/B][/COLOR]',BASE,446,art+'maslucha.jpg', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling Shows[/B][/COLOR]',BASE,417,art+'roh.jpg', fanart)
	addDirMain('[COLOR white][B]Riot City Wrestling[/B][/COLOR]',BASE,439,art+'riot.jpg', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling Kickoffs[/B][/COLOR]',BASE,416,art+'wwe6.jpg', fanart)
	addDirMain('[COLOR white][B]CCW Wrestling Shows[/B][/COLOR]',BASE,432,art+'ccw.jpg', fanart)
	addDirMain('[COLOR white][B]Pure Power Wrestling[/B][/COLOR]',BASE,445,art+'purepower.jpg', fanart)
	addDirMain('[COLOR white][B]PWA Ohio Wrestling[/B][/COLOR]',BASE,430,art+'pwa.jpg', fanart)
	addDirMain('[COLOR white][B]Rubber City Wrestling[/B][/COLOR]',BASE,441,art+'rubber.jpg', fanart)
	addDirMain('[COLOR white][B]ProSouth Wrestling[/B][/COLOR]',BASE,444,art+'prosouth.jpg', fanart)
	addDirMain('[COLOR white][B]PCW Wrestling Shows[/B][/COLOR]',BASE,413,art+'pcw.jpg', fanart)
	addDirMain('[COLOR white][B]Southwest Wrestling[/B][/COLOR]',BASE,449,art+'swe.jpg', fanart)
	addDirMain('[COLOR white][B]Title Match Network[/B][/COLOR]',BASE,448,art+'tmn.jpg', fanart)
	addDirMain('[COLOR white][B]House Of Pain Wrestling[/B][/COLOR]',BASE,447,art+'hop.jpg', fanart)
	addDirMain('[COLOR white][B]IHW Unstoppable Shows[/B][/COLOR]',BASE,438,art+'ihw.jpg', fanart)
	addDirMain('[COLOR white][B]UK Wrestling Mayhem[/B][/COLOR]',BASE,434,art+'ukw.jpg', fanart)
	addDirMain('[COLOR white][B]RPW Rampage TV Shows[/B][/COLOR]',BASE,436,art+'real.jpg', fanart)
	addDirMain('[COLOR white][B]NEW Wrestling Shows[/B][/COLOR]',BASE,435,art+'new.jpg', fanart)
	addDirMain('[COLOR white][B]Warriors of Wrestling[/B][/COLOR]',BASE,440,art+'warrior.jpg', fanart)
	addDirMain('[COLOR white][B]USACW Wrestling Shows[/B][/COLOR]',BASE,419,art+'usacw.jpg', fanart)
	addDirMain('[COLOR white][B]WWN Live Wrestling[/B][/COLOR]',BASE,442,art+'wwn.jpg', fanart)
	addDirMain('[COLOR white][B]Misc. Wrestling Shows[/B][/COLOR]',BASE,431,art+'misc.jpg', fanart)
	addDirMain('[COLOR white][B]Smash Wrestling Shows[/B][/COLOR]',BASE,422,art+'smash.jpg', fanart)
	addDirMain('[COLOR white][B]OWE Wrestling Shows[/B][/COLOR]',BASE,428,art+'owe.jpg', fanart)
	addDirMain('[COLOR white][B]FWA Wrestling Shows[/B][/COLOR]',BASE,421,art+'fwa.jpg', fanart)
	addDirMain('[COLOR white][B]Britannia Wrestling[/B][/COLOR]',BASE,423,art+'brit.jpg', fanart)
	addDirMain('[COLOR white][B]Respect Womens Wrestling[/B][/COLOR]',BASE,427,art+'respect.jpg', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

#@route(mode='archivelist')
def archiveList():

	add_link_info('[B][COLORorange]Choose Archive Genre[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Wrestling Events[/B][/COLOR]',BASE,401,art+'archive.jpg', fanart)
	addDirMain('[COLOR white][B]WWA Wrestling Events[/B][/COLOR]',BASE,510,art+'wwa.jpg', fanart)
	addDirMain('[COLOR white][B]MLW Wrestling Events[/B][/COLOR]',BASE,512,art+'mlw.jpg', fanart)
	addDirMain('[COLOR white][B]Womens Wrestling Events[/B][/COLOR]',BASE,535,art+'wow.jpg', fanart)
	addDirMain('[COLOR white][B]WAW Wrestling Events[/B][/COLOR]',BASE,539,art+'waw.jpg', fanart)
	addDirMain('[COLOR white][B]IPW Wrestling Events[/B][/COLOR]',BASE,513,art+'ipw.jpg', fanart)
	addDirMain('[COLOR white][B]ROW Wrestling Events[/B][/COLOR]',BASE,514,art+'row.jpg', fanart)
	addDirMain('[COLOR white][B]AAW Wrestling Events[/B][/COLOR]',BASE,533,art+'aaw.jpg', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling Events[/B][/COLOR]',BASE,517,art+'roh.jpg', fanart)
	addDirMain('[COLOR white][B]EWF Wrestling Events[/B][/COLOR]',BASE,519,art+'ewf.jpg', fanart)
	addDirMain('[COLOR white][B]Rise Underground Events[/B][/COLOR]',BASE,527,art+'rise.jpg', fanart)
	addDirMain('[COLOR white][B]Micro Wrestling Events[/B][/COLOR]',BASE,540,art+'midget.jpg', fanart)
	addDirMain('[COLOR white][B]Smash Wrestling Events[/B][/COLOR]',BASE,522,art+'smash.jpg', fanart)
	addDirMain('[COLOR white][B]Defiant Wrestling Events[/B][/COLOR]',BASE,534,art+'defiant.jpg', fanart)
	addDirMain('[COLOR white][B]Championship Wrestling[/B][/COLOR]',BASE,518,art+'champ.jpg', fanart)
	addDirMain('[COLOR white][B]Misc. Wrestling Events[/B][/COLOR]',BASE,531,art+'misc.jpg', fanart)
	addDirMain('[COLOR white][B]Progress Wrestling Events[/B][/COLOR]',BASE,516,art+'progress.jpg', fanart)
	addDirMain('[COLOR white][B]Britannia Wrestling[/B][/COLOR]',BASE,523,art+'brit.jpg', fanart)
	addDirMain('[COLOR white][B]BWF Wrestling Events[/B][/COLOR]',BASE,537,art+'bwf.jpg', fanart)
	addDirMain('[COLOR white][B]FWA Wrestling Events[/B][/COLOR]',BASE,521,art+'fwa.jpg', fanart)
	addDirMain('[COLOR white][B]PWL Wrestling Events[/B][/COLOR]',BASE,520,art+'pwl.jpg', fanart)
	addDirMain('[COLOR white][B]House of Glory Events[/B][/COLOR]',BASE,525,art+'hog.jpg', fanart)
	addDirMain('[COLOR white][B]IMPACT Wrestling Events[/B][/COLOR]',BASE,528,art+'impact.jpg', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling Events[/B][/COLOR]',BASE,529,art+'wwe.jpg', fanart)
	addDirMain('[COLOR white][B]One Pro Wrestling Events[/B][/COLOR]',BASE,536,art+'1pw.jpg', fanart)
	addDirMain('[COLOR white][B]CCW Wrestling Events[/B][/COLOR]',BASE,532,art+'cascade.jpg', fanart)
	addDirMain('[COLOR white][B]HOB Wrestling Events[/B][/COLOR]',BASE,515,art+'hob.jpg', fanart)
	addDirMain('[COLOR white][B]Capitol Wrestling Shows[/B][/COLOR]',BASE,541,art+'capitol.jpg', fanart)
	#addDirMain('[COLOR white][B]Ohio Valley Wrestling[/B][/COLOR]',BASE,526,art+'ovw.jpg', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

#@route(mode='matchlist')
def matchList():

	add_link_info('[B][COLORorange]Choose Match Genre[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Wrestling Matches[/B][/COLOR]',BASE,403,art+'match.jpg', fanart)
	addDirMain('[COLOR white][B]WWE Wrestling Matches[/B][/COLOR]',BASE,610,art+'wwe.jpg', fanart)
	addDirMain('[COLOR white][B]AEW Wrestling Matches[/B][/COLOR]',BASE,619,art+'aew.jpg', fanart)
	addDirMain('[COLOR white][B]ROH Wrestling Matches[/B][/COLOR]',BASE,611,art+'roh.jpg', fanart)
	addDirMain('[COLOR white][B]IMPACT Wrestling Matches[/B][/COLOR]',BASE,612,art+'impact.jpg', fanart)
	addDirMain('[COLOR white][B]MLW Wrestling Matches[/B][/COLOR]',BASE,613,art+'mlw.jpg', fanart)
	addDirMain('[COLOR white][B]Womens Wrestling Matches[/B][/COLOR]',BASE,615,art+'wow.jpg', fanart)
	addDirMain('[COLOR white][B]ROW Wrestling Matches[/B][/COLOR]',BASE,616,art+'row.jpg', fanart)
	addDirMain('[COLOR white][B]TMN Wrestling Matches[/B][/COLOR]',BASE,618,art+'tmn.jpg', fanart)
	addDirMain('[COLOR white][B]Misc. Wrestling Matches[/B][/COLOR]',BASE,617,art+'misc.jpg', fanart)

	#addDirMain('[COLOR white][B]PWA Ohio Wrestling[/B][/COLOR]',BASE,630,art+'pwa.jpg', fanart)
	#addDirMain('[COLOR white][B]Ohio Valley Wrestling[/B][/COLOR]',BASE,626,art+'ovw.jpg', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

#==========================================================================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#=========================================
		
#errorMsg="%s" % (mode)
#xbmcgui.Dialog().ok("mode", errorMsg)
 
#=============WRESTLERS===================

if mode == 70:
	WWE()
		
elif mode == 71:
	NXT()		
		
elif mode == 72:
	ROH()

elif mode == 73:
	Impact()
	
elif mode == 74:
	Womens()

elif mode == 75:
	Legends()

elif mode == 76:
	ECW()

elif mode == 77:
	WCW()
	
elif mode == 78:
	Wrestlers_Docs()

elif mode == 79:
	Indie()

elif mode == 80:
	Tables()
	
elif mode == 81:
    genreList()
	
elif mode == 82:
    archiveList()
	
elif mode == 83:
    matchList()

elif mode == 700:
	W_channels()

elif mode == 701:
	AEW()

#=========================================

elif mode == 400:
    Listing.Genres("All","News")
		
elif mode == 401:
    Listing.Genres("All","Archives")
		
elif mode == 402:
    Listing.Genres("All","Genre")

elif mode == 403:
    Listing.Genres("All","Matches")
	
elif mode == 404:
    Listing.Genres("All","Docs")

elif mode == 405:
    Listing.Genres("All","Events")
	
elif mode == 406:
    indyMOD.Genres("All")

#=========================================

elif mode == 410:
    Listing.Genres("aew","Genre")

elif mode == 411:
    Listing.Genres("nwa","Genre")

elif mode == 412:
    Listing.Genres("mlw","Genre")

elif mode == 413:
    Listing.Genres("pcw","Genre")

elif mode == 414:
    Listing.Genres("row","Genre")

elif mode == 415:
    Listing.Genres("nwa","Genre")

elif mode == 416:
    Listing.Genres("wwe","Genre")

elif mode == 417:
    Listing.Genres("roh","Genre")

elif mode == 418:
    Listing.Genres("champ","Genre")

elif mode == 419:
    Listing.Genres("usacw","Genre")

elif mode == 420:
    Listing.Genres("gcw","Genre")

elif mode == 421:
    Listing.Genres("fwa","Genre")

elif mode == 422:
    Listing.Genres("smash","Genre")

elif mode == 423:
    Listing.Genres("brit","Genre")

elif mode == 424:
    Listing.Genres("wlw","Genre")

elif mode == 425:
    Listing.Genres("rmp","Genre")

elif mode == 426:
    Listing.Genres("ovw","Genre")

elif mode == 427:
    Listing.Genres("respect","Genre")

elif mode == 428:
    Listing.Genres("owetv","Genre")

elif mode == 429:
    Listing.Genres("iwrg","Genre")

elif mode == 430:
    Listing.Genres("pwa","Genre")

elif mode == 431:
    Listing.Genres("misc","Genre")

elif mode == 432:
    Listing.Genres("ccw","Genre")

elif mode == 433:
    Listing.Genres("amw","Genre")

elif mode == 434:
    Listing.Genres("ukw","Genre")

elif mode == 435:
    Listing.Genres("new","Genre")

elif mode == 436:
    Listing.Genres("real","Genre")

#elif mode == 437:
    #Listing.Genres("victory","Genre")

elif mode == 438:
    Listing.Genres("ihw","Genre")

elif mode == 439:
    Listing.Genres("riot","Genre")

elif mode == 440:
    Listing.Genres("warrior","Genre")

elif mode == 441:
    Listing.Genres("rubber","Genre")

elif mode == 442:
    Listing.Genres("wwn","Genre")

elif mode == 443:
    Listing.Genres("wwa","Genre")

elif mode == 444:
    Listing.Genres("prosouth","Genre")

elif mode == 445:
    Listing.Genres("purepower","Genre")

elif mode == 446:
    Listing.Genres("maslucha","Genre")

elif mode == 447:
    Listing.Genres("hop","Genre")

elif mode == 448:
    Listing.Genres("tmn","Genre")

elif mode == 449:
    Listing.Genres("swe","Genre")

elif mode == 450:
    Listing.Genres("dpw","Genre")

#=========================================

elif mode == 510:
    Listing.Genres("wwa","Archives")

elif mode == 511:
    Listing.Genres("nwa","Archives")

elif mode == 512:
    Listing.Genres("mlw","Archives")

elif mode == 513:
    Listing.Genres("ipw","Archives")

elif mode == 514:
    Listing.Genres("row","Archives")

elif mode == 515:
    Listing.Genres("hob","Archives")

elif mode == 516:
    Listing.Genres("progress","Archives")

elif mode == 517:
    Listing.Genres("roh","Archives")

elif mode == 518:
    Listing.Genres("champ","Archives")

elif mode == 519:
    Listing.Genres("ewf","Archives")

elif mode == 520:
    Listing.Genres("awl","Archives")

elif mode == 521:
    Listing.Genres("fwa","Archives")

elif mode == 522:
    Listing.Genres("smash","Archives")

elif mode == 523:
    Listing.Genres("brit","Archives")

elif mode == 524:
    Listing.Genres("wlw","Archives")

elif mode == 525:
    Listing.Genres("hog","Archives")

elif mode == 526:
    Listing.Genres("ovw","Archives")

elif mode == 527:
    Listing.Genres("rise","Archives")

elif mode == 528:
    Listing.Genres("tna","Archives")

elif mode == 529:
    Listing.Genres("wwe","Archives")

elif mode == 530:
    Listing.Genres("pwl","Archives")

elif mode == 531:
    Listing.Genres("misc","Archives")

elif mode == 532:
    Listing.Genres("ccw","Archives")

elif mode == 533:
    Listing.Genres("aaw","Archives")

elif mode == 534:
    Listing.Genres("defiant","Archives")

elif mode == 535:
    Listing.Genres("women","Archives")

elif mode == 536:
    Listing.Genres("1pw","Archives")

elif mode == 537:
    Listing.Genres("bwf","Archives")

elif mode == 538:
    Listing.Genres("lucha","Archives")

elif mode == 539:
    Listing.Genres("waw","Archives")

elif mode == 540:
    Listing.Genres("midget","Archives")

elif mode == 541:
    Listing.Genres("capitol","Archives")

#=========================================

elif mode == 610:
    Listing.Genres("wwe","Matches")

elif mode == 611:
    Listing.Genres("roh","Matches")

elif mode == 612:
    Listing.Genres("tna","Matches")

elif mode == 613:
    Listing.Genres("mlw","Matches")

elif mode == 614:
    Listing.Genres("nwa","Matches")

elif mode == 615:
    Listing.Genres("women","Matches")

elif mode == 616:
    Listing.Genres("row","Matches")

elif mode == 617:
    Listing.Genres("misc","Matches")

elif mode == 618:
    Listing.Genres("tmn","Matches")

elif mode == 619:
    Listing.Genres("aew","Matches")

elif mode == 620:
    Listing.Genres("lucha","Matches")

#=========================================
		
elif mode == 801:
		
	#errorMsg="%s" % (url)
	#xbmcgui.Dialog().ok("url", errorMsg)

	Common.getVID(url)
		
elif mode == 802:
	from resources.lib.modules.yt_playlists import *        
		
elif mode == 803:
	from resources.lib.modules.yt_channels import *        
		
elif mode == 804:
	import resources.lib.modules.yt_video

#=========================================		

elif mode is None:
	Main()

#=========================================		
		
xbmcplugin.endOfDirectory(plugin_handle)

#=========================================		
