"""
    Free Live TV Add-on
    Developed by mhancoc7

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from common import *

import kidzclublib

class Channels:

    @staticmethod
    def section_list():
        #Generate Section List
        for section in sorted(kidzclublib.Common.get_sections(), reverse=False):
            kidzclublib.Common.add_section(section, kidzclublib.Common.get_logo(section, "section"), fanart)

    @staticmethod
    def genres_list():
        # Generate Genre List
        for genre in sorted(kidzclublib.Common.get_genres(), reverse=False):
            kidzclublib.Common.add_section(genre, kidzclublib.Common.get_logo(genre, "genre"), fanart)

    @staticmethod
    def genre_list(genre):
        # Generate Channel List within given genre
        for channel in sorted(kidzclublib.Common.get_channels(), reverse=False):
            if genre in channel["type"]:
                kidzclublib.Common.add_channel(channel["name"], kidzclublib.Common.get_logo(channel["name"]), fanart)

    @staticmethod
    def channel_list():
        # Generate Channel List
        for channel in sorted(kidzclublib.Common.get_channels(), reverse=False):
            kidzclublib.Common.add_channel(channel["name"], kidzclublib.Common.get_logo(channel["name"]), fanart)

    @staticmethod
    def get_channel(mode):
        kidzclublib.Common.get_stream_and_play(mode)

