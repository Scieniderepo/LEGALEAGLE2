# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
#import urllib2

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

#===============================================================================

selfAddon = xbmcaddon.Addon(id=addon_id)

try:
    datapath= xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
except:
    datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.channels')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

try:
    fanart = xbmcvfs.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmcvfs.translatePath(os.path.join(home, 'icon.png'))
except:
    fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmc.translatePath(os.path.join(home, 'channels.png'))

mediapath = 'http://j1wizard.net/media/'

#===============================================================================

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
c2BASE = "plugin://plugin.video.youtube/c/"
uBASE = "plugin://plugin.video.youtube/user/"
pBASE = "plugin://plugin.video.youtube/play/?video_id="
ppBASE = "plugin://plugin.video.youtube/play/?playlist_id="

YOUTUBE_CHANNEL_ID_7001 = "UCEgdi0XIXXZ-qJOFPf4JSKw" #Youtube Sports
YOUTUBE_CHANNEL_ID_7002 = "jsaxsm"                   #Motocross,MX, Rally Channel
YOUTUBE_CHANNEL_ID_7003 = "" #
YOUTUBE_CHANNEL_ID_7004 = "UCSZCjJhBPSuhe7RBMqBLDww" #Sports Girl Montana Channel
YOUTUBE_CHANNEL_ID_7005 = "UCke1RK4MOxsaPMGyw19e7sQ" #Sports Legends Channel
YOUTUBE_CHANNEL_ID_7006 = "UCl1AI3a9tgswsd8CQPgGPDA" #Big Mind Sports Channel
YOUTUBE_CHANNEL_ID_7007 = "" #
YOUTUBE_CHANNEL_ID_7008 = "" #
YOUTUBE_CHANNEL_ID_7009 = "UC-hWvVvE-crFl5vg5G8QbqA" #BT Sport Boxing Channel
YOUTUBE_CHANNEL_ID_7010 = "UC_7yB-Q_5XVLGX-PbORB50Q" #Sport Fishing Television
YOUTUBE_CHANNEL_ID_7011 = "dansportfishing"          #Sport Fishing Dan Hernandez
YOUTUBE_CHANNEL_ID_7012 = "LingerieFootball"         #LFL Womens Football Channel
YOUTUBE_CHANNEL_ID_7013 = "OneFCMMA"                 #ONE Championship

YOUTUBE_CHANNEL_ID_7014 = "" #
YOUTUBE_CHANNEL_ID_7015 = "" #
YOUTUBE_CHANNEL_ID_7016 = "" #
YOUTUBE_CHANNEL_ID_7017 = "" #
YOUTUBE_CHANNEL_ID_7018 = "" #
YOUTUBE_CHANNEL_ID_7019 = "" #
YOUTUBE_CHANNEL_ID_7020 = "" #
YOUTUBE_CHANNEL_ID_7021 = "" #
YOUTUBE_CHANNEL_ID_7022 = "" #
YOUTUBE_CHANNEL_ID_7023 = "" #
YOUTUBE_CHANNEL_ID_7024 = "" #
YOUTUBE_CHANNEL_ID_7025 = "" #
YOUTUBE_CHANNEL_ID_7026 = "UCf8eeJIxklNmYLK_Zi_eCCQ" #The Vintage Movies Channel
YOUTUBE_CHANNEL_ID_7027 = "JaggedReliefCartoons"     #Jagged Relief Channel
YOUTUBE_CHANNEL_ID_7028 = "UCGBzBkV-MinlBvHBzZawfLQ" #Classic Movies Channel
YOUTUBE_CHANNEL_ID_7029 = "" #
YOUTUBE_CHANNEL_ID_7030 = "" #
YOUTUBE_CHANNEL_ID_7031 = "Classixflix"              #Classix Flix Channel
YOUTUBE_CHANNEL_ID_7032 = "UCYHHgSLnAvhpGszOpZZwnbg" #RBM Pictures Channel
YOUTUBE_CHANNEL_ID_7033 = "" #
YOUTUBE_CHANNEL_ID_7034 = "UCmXQRtLSFJC4v_pYXaM3DGQ" #Classic Westerns Channel
YOUTUBE_CHANNEL_ID_7035 = "UCycDFnpMeWzaITQSD1dWsOA" #Classic Cinema Channel
YOUTUBE_CHANNEL_ID_7036 = "UCibOdW_Yj0-pj5SQGZxZIgA" #Retrospective Channel
YOUTUBE_CHANNEL_ID_7037 = "" #
YOUTUBE_CHANNEL_ID_7038 = "" #
YOUTUBE_CHANNEL_ID_7039 = "" #
YOUTUBE_CHANNEL_ID_7040 = "UC1rkmtrlGWHODSX7di3DLjA" #Spuds Classic Video Channel
YOUTUBE_CHANNEL_ID_7041 = "UCOTeh4TQ6MrFF4Agq_pYXJQ" #Movie Navigator Classics
YOUTUBE_CHANNEL_ID_7042 = "manicmoviesdotcom"        #Manic Movie Classics
YOUTUBE_CHANNEL_ID_7043 = "UClNYP19GgDfR8GZpZ87ewoQ" #Amazingly Classic Movies
YOUTUBE_CHANNEL_ID_7044 = "" #
YOUTUBE_CHANNEL_ID_7045 = "" #
YOUTUBE_CHANNEL_ID_7046 = "" #
YOUTUBE_CHANNEL_ID_7047 = "" #
YOUTUBE_CHANNEL_ID_7048 = "" #
YOUTUBE_CHANNEL_ID_7049 = "" #
YOUTUBE_CHANNEL_ID_7050 = "UCNcUc5v0Kt5afE_jcbbZUBQ" #Artflix Movies Channel
YOUTUBE_CHANNEL_ID_7051 = "UCBWJEa2VHKB3PXHYMpgOj1Q" #Flixdome Movies Channel
YOUTUBE_CHANNEL_ID_7052 = "" #
YOUTUBE_CHANNEL_ID_7053 = "UCQ7W-F1-p28MZnYGPmLQ7bw" #One Night At The Drive-in
YOUTUBE_CHANNEL_ID_7054 = "UC_kZkohCJURAQLwzzOUtBhA" #Biscoot Hollywood Movies
YOUTUBE_CHANNEL_ID_7055 = "papadoc73" #Channel 3 Youtube
YOUTUBE_CHANNEL_ID_7056 = "PizzaFlix" #The Pizza Flix Channel
YOUTUBE_CHANNEL_ID_7057 = "UCY_UWuzZvNZNsqEuM1FQ5zg" #FamBrand TV Channel
YOUTUBE_CHANNEL_ID_7058 = "UCd9YvBd1JIwYdQHsMU8byAQ" #Broken Trout Channel
YOUTUBE_CHANNEL_ID_7059 = "drelbcom" #drelbcom Channel
YOUTUBE_CHANNEL_ID_7060 = "ampopfilms" #Ampop Films Channels
YOUTUBE_CHANNEL_ID_7061 = "TimelessClassicFilms" #Timeless Classic Films

YOUTUBE_CHANNEL_ID_7062 = "" #
YOUTUBE_CHANNEL_ID_7063 = "ScreenMediaPictures"      #The PopcornFlix Channel
YOUTUBE_CHANNEL_ID_7064 = "UCeuA6RU1Ua3Mstr2gcnAYCQ" #Film Zone Channel
YOUTUBE_CHANNEL_ID_7065 = "" #
YOUTUBE_CHANNEL_ID_7066 = "UCE_0zvmu1pMYZAgqyjW6qsQ" #Bigtime Movies Channel
YOUTUBE_CHANNEL_ID_7067 = "UC8IHAQMuiJdY6ALuhG7iU8Q" #Filmrise Movies Channel
YOUTUBE_CHANNEL_ID_7068 = "ViewsterTV"               #Viewster Movies Channel
YOUTUBE_CHANNEL_ID_7069 = "maverickent"              #Maverick Movie Channel
YOUTUBE_CHANNEL_ID_7070 = "UCRHcpjAIeJpAVhnSaa_I2hQ" #The Movieholic Channel
YOUTUBE_CHANNEL_ID_7071 = "UCDhey18N756Hi0IB8Tudr1g" #Superhits Movie Channel

YOUTUBE_CHANNEL_ID_7072 = "" #
YOUTUBE_CHANNEL_ID_7073 = "" #
YOUTUBE_CHANNEL_ID_7074 = "" #
YOUTUBE_CHANNEL_ID_7075 = "UCCYhvWD88Mbd2M14GqpPM9A" #Cloud 5 Family Channel
YOUTUBE_CHANNEL_ID_7076 = "" #
YOUTUBE_CHANNEL_ID_7077 = "UCNLdqhBwGzscezZwsdcm0SA" #Superhero Kids Channel
YOUTUBE_CHANNEL_ID_7078 = "multfilm" #Kedoo ToonsTV Channel
YOUTUBE_CHANNEL_ID_7079 = "westernsontheweb" #Westerns On The Web
YOUTUBE_CHANNEL_ID_7080 = "wildwesttoys1" #Wild West Toys Channel
YOUTUBE_CHANNEL_ID_7081 = "vids4kidstv" #Vids 4 Kids Channel
YOUTUBE_CHANNEL_ID_7082 = "UC9trsD1jCTXXtN3xIOIU8gg" #WB Kids Channel
YOUTUBE_CHANNEL_ID_7083 = "UC4qDWzHgug7clf4-HeGpkpA" #Club Baboo Channel
YOUTUBE_CHANNEL_ID_7084 = "TheVoiceKidsAU" #The Voice Kids Au
YOUTUBE_CHANNEL_ID_7085 = "UCkOxf5c1enax60y6wfB-Y6g" #Fun Science For Kids
YOUTUBE_CHANNEL_ID_7086 = "UCknQp_ATYj_o4_uPS3hDcTw" #Little Kids Channel
YOUTUBE_CHANNEL_ID_7087 = "UCZ6jURNr1WQZCNHF0ao-c0g" #Universal Kids Channel
YOUTUBE_CHANNEL_ID_7088 = "UCyJYCQ6WaEMhdZAuPo799bA" #Grjngo Westerns Channel
YOUTUBE_CHANNEL_ID_7089 = "westernmaniadotcom"       #Western Mania Channel
YOUTUBE_CHANNEL_ID_7090 = "" #
YOUTUBE_CHANNEL_ID_7091 = "" #
YOUTUBE_CHANNEL_ID_7092 = "" #
YOUTUBE_CHANNEL_ID_7093 = "" #
YOUTUBE_CHANNEL_ID_7094 = "" #
YOUTUBE_CHANNEL_ID_7095 = "" #
YOUTUBE_CHANNEL_ID_7096 = "" #
YOUTUBE_CHANNEL_ID_7097 = "" #
YOUTUBE_CHANNEL_ID_7098 = "" #
YOUTUBE_CHANNEL_ID_7099 = "" #
YOUTUBE_CHANNEL_ID_7100 = "UCnk71WleNch-LckZvidkTYA" #Future Zone Movie Channel
YOUTUBE_CHANNEL_ID_7101 = "UCHuG1lSWjlTbeGJpfQgFWfg" #The Sci-fi TV Channel
YOUTUBE_CHANNEL_ID_7102 = "" #
YOUTUBE_CHANNEL_ID_7103 = "UCOpzwVUNsep7FpN5687XYEA" #Sci-fi Central Channel 
YOUTUBE_CHANNEL_ID_7104 = "mst3kofficial" #Mystery Science Theater 3000
YOUTUBE_CHANNEL_ID_7105 = "UC7sDT8jZ76VLV1u__krUutA" #Dust Sci-fi Shorts Channel
YOUTUBE_CHANNEL_ID_7106 = "UCZUkQij64MCMH-3b1ycUGjg" #Barbarella X Sci-fi Channel
YOUTUBE_CHANNEL_ID_7107 = "" #
YOUTUBE_CHANNEL_ID_7108 = "" #
YOUTUBE_CHANNEL_ID_7109 = "" #
YOUTUBE_CHANNEL_ID_7110 = "" #
YOUTUBE_CHANNEL_ID_7111 = "" #
YOUTUBE_CHANNEL_ID_7112 = "" #
YOUTUBE_CHANNEL_ID_7113 = "" #
YOUTUBE_CHANNEL_ID_7114 = "" #
YOUTUBE_CHANNEL_ID_7115 = "" #
YOUTUBE_CHANNEL_ID_7116 = "" #
YOUTUBE_CHANNEL_ID_7117 = "" #
YOUTUBE_CHANNEL_ID_7118 = "" #
YOUTUBE_CHANNEL_ID_7119 = "" #
YOUTUBE_CHANNEL_ID_7120 = "" #
YOUTUBE_CHANNEL_ID_7200 = "TheKingsofHorror" #TheKingsofHorror
YOUTUBE_CHANNEL_ID_7201 = "" #
YOUTUBE_CHANNEL_ID_7202 = "" #
YOUTUBE_CHANNEL_ID_7203 = "UCIbCd95HIkwZx6DqlWSeDcA" #The Viewster Horror Channel
YOUTUBE_CHANNEL_ID_7204 = "" #
YOUTUBE_CHANNEL_ID_7205 = "UCqoWfNP5nYndE47qJ6KSYYg" #Terror Films Horror Channel
YOUTUBE_CHANNEL_ID_7206 = "UC951AqujycbBI083GmKRY3A" #New Castle After Dark Channel
YOUTUBE_CHANNEL_ID_7207 = "" #
YOUTUBE_CHANNEL_ID_7208 = "UCHgm6IUmnTV2aAMMCSPq8zA" #A Touch Of Evil Channel
YOUTUBE_CHANNEL_ID_7209 = "UC_MyK1SmeN2Sji4uBEckYaA" #Horror Movie Channel
YOUTUBE_CHANNEL_ID_7210 = "cinenethorror" #Cinenet Horror Movie Channel
YOUTUBE_CHANNEL_ID_7211 = "" #
YOUTUBE_CHANNEL_ID_7212 = "" #
YOUTUBE_CHANNEL_ID_7213 = "" #
YOUTUBE_CHANNEL_ID_7214 = "" #
YOUTUBE_CHANNEL_ID_7215 = "" #
YOUTUBE_CHANNEL_ID_7216 = "" #
YOUTUBE_CHANNEL_ID_7217 = "" #
YOUTUBE_CHANNEL_ID_7218 = "" #
YOUTUBE_CHANNEL_ID_7219 = "" #
YOUTUBE_CHANNEL_ID_7220 = "" #
YOUTUBE_CHANNEL_ID_7221 = "" #
YOUTUBE_CHANNEL_ID_7222 = "" #
YOUTUBE_CHANNEL_ID_7223 = "" #
YOUTUBE_CHANNEL_ID_7224 = "" #
YOUTUBE_CHANNEL_ID_7225 = "UC9pYOJPB5UYlMlGKKZWo-Bw" #Space And The Universe
YOUTUBE_CHANNEL_ID_7226 = "" #
YOUTUBE_CHANNEL_ID_7227 = "AwesomeDocumentary"       #Awesome Documentary Channel
YOUTUBE_CHANNEL_ID_7228 = "" #
YOUTUBE_CHANNEL_ID_7229 = "" #
YOUTUBE_CHANNEL_ID_7230 = "UCp4wHZCrDhITkiUILOd4gRw" #The Documentary Channel
YOUTUBE_CHANNEL_ID_7231 = "" #
YOUTUBE_CHANNEL_ID_7232 = "UCa-bX3gZC3YnCThlGM5d38Q" #The Fifth Estate - Canada
YOUTUBE_CHANNEL_ID_7233 = "UCfCO1oX5zmrZmWGgB6VyTBg" #BBC Dinosaur Documentaries
YOUTUBE_CHANNEL_ID_7234 = "UCrjFKLCqZnx5XuvWt00y4Jg" #The Simply Space
YOUTUBE_CHANNEL_ID_7235 = "" #
YOUTUBE_CHANNEL_ID_7236 = "UCParRQKYTA8Yh7_lo4DvGQA" #Music Documentary & Concerts
YOUTUBE_CHANNEL_ID_7237 = "FilmRiseDocumentary"      #Filmrise Documentary Channel
YOUTUBE_CHANNEL_ID_7238 = "" #
YOUTUBE_CHANNEL_ID_7239 = "Wober"                    #Truth Documentaries Channel
YOUTUBE_CHANNEL_ID_7240 = "UC_0r3EheCnp-wVvndYDGviQ" #Reel Truth Crime Channel
YOUTUBE_CHANNEL_ID_7241 = "" #
YOUTUBE_CHANNEL_ID_7242 = "" #
YOUTUBE_CHANNEL_ID_7243 = "" #
YOUTUBE_CHANNEL_ID_7244 = "" #
YOUTUBE_CHANNEL_ID_7245 = "" #
YOUTUBE_CHANNEL_ID_7246 = "" #
YOUTUBE_CHANNEL_ID_7247 = "" #
YOUTUBE_CHANNEL_ID_7248 = "" #
YOUTUBE_CHANNEL_ID_7249 = "" #
YOUTUBE_CHANNEL_ID_7250 = "UC-5rsPghrWb_ZNs99mAH58A" #Star Trek Fan Made: Star Trek
YOUTUBE_CHANNEL_ID_7251 = "spiritsoftheforce"        #Spirit Of The Force: Star Wars
YOUTUBE_CHANNEL_ID_7252 = "ThrowbackStudioz"         #Throwback Studioz: Superheros
YOUTUBE_CHANNEL_ID_7253 = "UC7OA3Eg8c5uPpUXdMpu2JTg" #The Lonely Spider: Spider-Man
YOUTUBE_CHANNEL_ID_7254 = "UCXCI-yvduow_uNwsMGK0kwg" #Craftsmanship: Marvel & More
YOUTUBE_CHANNEL_ID_7255 = "madeLEGITmedia"           #Story 1st Films: Marvel Knights
YOUTUBE_CHANNEL_ID_7256 = "NoMercyFanFilm"           #No Mersy Fan Film: Punisher
YOUTUBE_CHANNEL_ID_7257 = "DiGiTiLhEaRt"             #Joey Lever: Spider-Man Fan Films
YOUTUBE_CHANNEL_ID_7258 = "AmphibianTeam"            #Six Side Studio: Spider-Man
YOUTUBE_CHANNEL_ID_7259 = "PLAZSCGTToIqB76Juv23NBBq6VSCQENr1N" #Batman Fan Film
YOUTUBE_CHANNEL_ID_7260 = "NathShieldz"              #Shields Productions Justice League
YOUTUBE_CHANNEL_ID_7261 = "UCFbVHaxO2XZYnWl9Yu7BuYA" #Spider-Man, Batman, Superman, Star Wars
YOUTUBE_CHANNEL_ID_7262 = "UCPfY5Z09z7RbFpF9HaqQm8w" #Superheroine Fan Films
YOUTUBE_CHANNEL_ID_7263 = "SupermanCelebration"      #Superman Celebration Films
YOUTUBE_CHANNEL_ID_7264 = "The1stCapedCrusaders"     #The 1st Caped Crusaders Films
YOUTUBE_CHANNEL_ID_7265 = "dwffdb"                   #Doctor Who Fan Film Database
YOUTUBE_CHANNEL_ID_7266 = "UCyOOePOWI-LHPRIsNGIWqKw" #Doctor Who: Infinite Films
YOUTUBE_CHANNEL_ID_7267 = "" #
YOUTUBE_CHANNEL_ID_7268 = "" #
YOUTUBE_CHANNEL_ID_7269 = "" #
YOUTUBE_CHANNEL_ID_7270 = "" #
YOUTUBE_CHANNEL_ID_7271 = "" #
YOUTUBE_CHANNEL_ID_7272 = "" #
YOUTUBE_CHANNEL_ID_7273 = "" #
YOUTUBE_CHANNEL_ID_7274 = "" #
YOUTUBE_CHANNEL_ID_7275 = "" #
YOUTUBE_CHANNEL_ID_7276 = "PLBHqHeFZPW9Hs_AyvGkYFqRiyGEID7qqe" #1930s Film Classics
YOUTUBE_CHANNEL_ID_7277 = "PLk0JVm_FsEBFOS6GQzU6OPGCDyVdr9FPX" #1940s Film Classics
YOUTUBE_CHANNEL_ID_7278 = "PLHCfKqP2kHUjfU0FuP4069ueXitcXaqL0" #1940s Horror Movies
YOUTUBE_CHANNEL_ID_7279 = "" #
YOUTUBE_CHANNEL_ID_7280 = "" #
YOUTUBE_CHANNEL_ID_7281 = "PLwygboCFkeeDCVhsPydRRgn7_pYo0_Ni_" #More 1950s Movies
YOUTUBE_CHANNEL_ID_7282 = "PLGFUJPQvStUl8SLGRQZmJV2888yCbaZyl" #1950s Sci-fi Movies
YOUTUBE_CHANNEL_ID_7283 = "PLhDmoH4Bxhxyp8v3Lq-V0EoFMxlm2nefR" #Cheesy 1950s Sci-fi
YOUTUBE_CHANNEL_ID_7284 = "PLHCfKqP2kHUi_WgUsakf7xK0Lj4o-SqlQ" #1950s Horror Movies
YOUTUBE_CHANNEL_ID_7285 = "PLjygzGIObj88pLTHJUmUD8hUnhqVYJ25Y" #Movies Of The 1960s
YOUTUBE_CHANNEL_ID_7286 = "PL1Lpcnsvs3JH9VYW5FAVIMVMCGpzwk3Rk" #1960s Sci-fi Movies
YOUTUBE_CHANNEL_ID_7287 = "PLqAeW2ChBiNPKXoTykZZGDYHc4CYgt_1_" #1960s Horror Movies
YOUTUBE_CHANNEL_ID_7288 = "PL54qFWNk70fQxVBKl792TYM6ZjNjw0ehZ" #Movies Of The 1970s
YOUTUBE_CHANNEL_ID_7289 = "" #
YOUTUBE_CHANNEL_ID_7290 = "PLBD55FC56A8CE49B4"                 #1970s Horror Movies
YOUTUBE_CHANNEL_ID_7291 = "PLSeZ6qt37vqzA1UF-Jt-umIh5rPdnL3B1" #More 1970s Horror
YOUTUBE_CHANNEL_ID_7292 = "" #
YOUTUBE_CHANNEL_ID_7293 = "PL9G-CZo8LnsMFzi9lbjZRbTBRO584nYYL" #1970s Made For TV
YOUTUBE_CHANNEL_ID_7294 = "PL9-JlwYEj37W_Mx6OMVrGb4TOBCeCQ9de" #Movies Of The 1980s
YOUTUBE_CHANNEL_ID_7295 = "PLGoD7-IRaE5UxNGFJ92YZIfBVglzvmntV" #1980s Sci-fi Movies
YOUTUBE_CHANNEL_ID_7296 = "PLjygzGIObj89_G0e8w6yHDGFfGSrTs9so" #Movies: More 1980s
YOUTUBE_CHANNEL_ID_7297 = "PLaKd4X9vJ__zkjUwwMt-Szr_2lTZB-B6z" #More 1980s Movies
YOUTUBE_CHANNEL_ID_7298 = "" #
YOUTUBE_CHANNEL_ID_7299 = "PL7AzNmZEtiHWTI6VdOHOYwSaELMWC78yO" #Movies Of The 1990s
YOUTUBE_CHANNEL_ID_7300 = "PLKxdKKLx3iRTyfWK8SQghHUGHfOTGhRl2" #More 1990s Movies
YOUTUBE_CHANNEL_ID_7301 = "PLSSECiTJe_BWtMaN1ATjxZE1aSYUTnter" #1990s Horror Movies
YOUTUBE_CHANNEL_ID_7302 = "" #
YOUTUBE_CHANNEL_ID_7303 = "PLVyxJvG53fqAsscxnskG9MQUlWucbAJaO" #1990s Sci-fi Horror
YOUTUBE_CHANNEL_ID_7304 = "PLjygzGIObj89nvIY6-wj3Ed40_zXGf89D" #Movies Of The 2000s
YOUTUBE_CHANNEL_ID_7305 = "PLGrVBhFJEP2OPAbjW_HVkIpgpHxiNUGFX" #More Movies In 2000s
YOUTUBE_CHANNEL_ID_7306 = "" #
YOUTUBE_CHANNEL_ID_7307 = "" #
YOUTUBE_CHANNEL_ID_7308 = "" #
YOUTUBE_CHANNEL_ID_7309 = "UCEDX9BOXTGUAAsOXosCBqOQ" #Cartoon Movies Collectors
YOUTUBE_CHANNEL_ID_7310 = "UCtVyXpb7vzWYcZytGXOuM2Q" #Pop Teen Toons Channel
YOUTUBE_CHANNEL_ID_7311 = "UCr22Oyd2WENz0LiDphyIkJA" #Popcorn Toonz Kids Channel
YOUTUBE_CHANNEL_ID_7312 = "MonsterHigh"              #Monster High Channel
YOUTUBE_CHANNEL_ID_7313 = "WEP"                      #Voltron Animated Channel
YOUTUBE_CHANNEL_ID_7314 = "" #
YOUTUBE_CHANNEL_ID_7315 = "thekydstv"                #Kids Channel: Video For Kids
YOUTUBE_CHANNEL_ID_7316 = "bobthebuilderchannel"     #Bob The Builder Channel
YOUTUBE_CHANNEL_ID_7317 = "HooplaKidzTv"             #The Hoopla Kidz TV Channel
YOUTUBE_CHANNEL_ID_7318 = "POCOYOUSA"                #Pocoyo English Kids Channel
YOUTUBE_CHANNEL_ID_7319 = "firemansamchannel"        #Fireman Sam Kids Channel
YOUTUBE_CHANNEL_ID_7320 = "CaRt0oNz"                 #Not Necessarily For Kids
YOUTUBE_CHANNEL_ID_7321 = "" #
YOUTUBE_CHANNEL_ID_7322 = "UCcVhzF_9HZdZpYkrQQKhtyQ" #VHS Museum Of Cartoons Channel
YOUTUBE_CHANNEL_ID_7323 = "MagicPetsSongs4Kids"      #Morphle TV Kids Channel
YOUTUBE_CHANNEL_ID_7324 = "UCKe-7-MbrHXAUB3hYTa6pkw" #Olivia The Pig Channel
YOUTUBE_CHANNEL_ID_7325 = "UCqvXAiNyn8pd9SVPclWfJTg" #Popeye & Friends Channel
YOUTUBE_CHANNEL_ID_7326 = "UCQeaaygt1I71F15PMa4QTZA" #Sonic The Hedgehog Channel
YOUTUBE_CHANNEL_ID_7327 = "" #
YOUTUBE_CHANNEL_ID_7328 = "UCe_nAv6UfY5nn53UQHqm6Dg" #Super Mario Bros Super Show
YOUTUBE_CHANNEL_ID_7329 = "PLL4Rkv1GmvjparUCXNY7nZPn_KH-s6_vS" #SheRa Princess Of Power
YOUTUBE_CHANNEL_ID_7330 = "mrbeancartoonworld"       #Mr. Bean Cartoon World
YOUTUBE_CHANNEL_ID_7331 = "" #
YOUTUBE_CHANNEL_ID_7332 = "" #
YOUTUBE_CHANNEL_ID_7333 = "" #
YOUTUBE_CHANNEL_ID_7334 = "" #
YOUTUBE_CHANNEL_ID_7335 = "" #
YOUTUBE_CHANNEL_ID_7336 = "" #
YOUTUBE_CHANNEL_ID_7337 = "" #
YOUTUBE_CHANNEL_ID_7338 = "" #
YOUTUBE_CHANNEL_ID_7339 = "" #
YOUTUBE_CHANNEL_ID_7340 = "" #
YOUTUBE_CHANNEL_ID_7341 = "" #
YOUTUBE_CHANNEL_ID_7342 = "AquarionDubbed"                     #Aquarion Dub Channel
YOUTUBE_CHANNEL_ID_7343 = "UC1N-PKEIJBLy-jL49d3QG7A"           #Dragon Ball Channel
YOUTUBE_CHANNEL_ID_7344 = ""           #
YOUTUBE_CHANNEL_ID_7345 = "UCRepcWts1FjVheTSQN-OohQ"           #Anime For Life Channel
YOUTUBE_CHANNEL_ID_7346 = ""                  #
YOUTUBE_CHANNEL_ID_7347 = ""           #
YOUTUBE_CHANNEL_ID_7348 = "UCJ2gftbil8-wwYQqKScLfSA"           #Boku wa Tomodachi Ga Sukunai
YOUTUBE_CHANNEL_ID_7349 = ""           #
YOUTUBE_CHANNEL_ID_7350 = ""                  #
YOUTUBE_CHANNEL_ID_7351 = ""           #
YOUTUBE_CHANNEL_ID_7352 = "UCU-UVjRY9MpJXMt6DFrlJPg"           #Hunter X Hunter
YOUTUBE_CHANNEL_ID_7353 = "UCV2rp8vEBVysQcSDzqh_Btg"           #Naruto Channel	


YOUTUBE_CHANNEL_ID_7500 = "UCfVpWzrE8B95_y3HupRyrkA" #AAW Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7501 = "UC4_HNKg_uDiGlVBnVbJTdYQ" #Womans Wrestling Revolution
YOUTUBE_CHANNEL_ID_7502 = "UCaN1vfY2wREOeV-oUB4KQ4g" #Pro Wrestling Guerrilla
YOUTUBE_CHANNEL_ID_7503 = "UCSafF4n61XE0JfyjS0TSv0Q" #Anarchy Championship Wrestling
YOUTUBE_CHANNEL_ID_7504 = "UCGab5jWe6gD8WyKWe9Q_TgA" #Attack Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7505 = "UCV2IP5RtH316GVHwuJB4l2Q" #WCW Womens Wrestling Classics
YOUTUBE_CHANNEL_ID_7506 = "UCFwWvXF6zia68-wy2ke7QeA" #Chaotic Wrestling Channel
YOUTUBE_CHANNEL_ID_7507 = "UCsSTZ3VyKsJeOXNjfz5bnuQ" #Innovate Wrestling Channel
YOUTUBE_CHANNEL_ID_7508 = "UCVZLUHBlQDfwbJunu050xDg" #New Wave Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7509 = "UCmimqM7Mo-FGbqsZULfsj6g" #CZW Wrestling Channel
YOUTUBE_CHANNEL_ID_7510 = "UCK7dW1mtFn9sx6ebFhCBdBw" #CZW Dojowars Channel
YOUTUBE_CHANNEL_ID_7511 = "UCOe-yFWWtWMC9YHoJAK0X1g" #Dragon Gate Pro Channel
YOUTUBE_CHANNEL_ID_7512 = "UCY4kveQR3srBEO6tp3xrHtQ" #Empire Wrestling Federation
YOUTUBE_CHANNEL_ID_7513 = "lpwainc"                  #All Women Wrestling Channel
YOUTUBE_CHANNEL_ID_7514 = "UCqcgTn7iAQs7gizmmxyVCYQ" #Freelance Wrestling Channel
YOUTUBE_CHANNEL_ID_7515 = "UCPRLQXM3ScRHllwExnbji8g" #House Of Bricks Pro Wrestling
YOUTUBE_CHANNEL_ID_7516 = "UCdqKACboxLhx0k5ZQFruG_A" #Future Stars Of Wrestling
YOUTUBE_CHANNEL_ID_7517 = "UCqXUtnXG62ReZZwxzIyu1yw" #Gold Rush Pro Wrestling
YOUTUBE_CHANNEL_ID_7518 = "UCBYGxShzjL_L7wbmzl1gfxQ" #World League Wrestling Channel
YOUTUBE_CHANNEL_ID_7519 = "UC9oHZXq6XVLvYZgc9SnzglQ" #House Of Hardcore Channel
YOUTUBE_CHANNEL_ID_7520 = "UCNS9QyhI7mlJr7Bs7e96H-A" #World Association Of Wrestling
YOUTUBE_CHANNEL_ID_7521 = "UCN6bAK93VslDZWVzjmXrLzw" #International Pro Wrestling
YOUTUBE_CHANNEL_ID_7522 = "UC3lOpKjW4_j4PGXWLNTt4iQ" #CMLL Wrestling Channel
YOUTUBE_CHANNEL_ID_7523 = "UCpOxiFW6ZxJ1-eD2q-WOBEg" #IWF Wrestling Channel
YOUTUBE_CHANNEL_ID_7524 = "UCTOMMSa2WpM1pOkXptsFJCg" #Premiere Wrestling Xperience
YOUTUBE_CHANNEL_ID_7525 = "UCHmdlxdFuumrHfLTp76TnWQ" #Keystone State Wrestling Alliance
YOUTUBE_CHANNEL_ID_7526 = "SHINEWrestling"           #Shine Womans Wrestling Channel
YOUTUBE_CHANNEL_ID_7527 = "UCCriLuKqcuYiEYEFR26nqig" #All Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7528 = "UCPHMctj7gnb5zA5iuzUshAA" #MCW Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7529 = "UCxPLqL8MxuAUveJZ1r3QRdQ" #National Wrestling League
YOUTUBE_CHANNEL_ID_7530 = "UCHXBm9pnQ89R1dYNf0MIAKA" #Preston City Wresling Channel
YOUTUBE_CHANNEL_ID_7531 = "UCb3vOGBxTJxIwFyBkdOiksA" #New European Championship Wrestling
YOUTUBE_CHANNEL_ID_7532 = "UCVb8PPxFpFnFGLdtGRUDKqQ" #New Generation Wrestling Channel
YOUTUBE_CHANNEL_ID_7533 = "UC3dvdVY1LHZuMP03GTvBeUg" #United Wrestling Coalition
YOUTUBE_CHANNEL_ID_7534 = "UCYOQrveFEmmRnFzIPlFnJFQ" #WWE Classic HD Wrestling Channel
YOUTUBE_CHANNEL_ID_7535 = "UCWt0mXTlQpQwJV-ZzHE6c2Q" #Paragon Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7536 = "UCq--5BijW932u7PN4WNfHRA" #Westside Xtreme Wrestling
YOUTUBE_CHANNEL_ID_7537 = "UCL-IRQy9_2vcorvGsDqpt0w" #Ultra Championship Wrestling Zero
YOUTUBE_CHANNEL_ID_7538 = "" #
YOUTUBE_CHANNEL_ID_7539 = "UCVYYso8bd96TXBeFglh1XYw" #New England Championship Wrestling
YOUTUBE_CHANNEL_ID_7540 = "ProWrestlingEVE"          #EVE Womens Wrestling Channel
YOUTUBE_CHANNEL_ID_7541 = "UCZaS14idYb591IbxLqcyNQA" #Progress Wrestling Channel
YOUTUBE_CHANNEL_ID_7542 = "UCsI_f3U8cLIvzDNKsI0FXRw" #Jersey All Pro Wrestling
YOUTUBE_CHANNEL_ID_7543 = "UCTNT9N8pIx1Q4vgVwZHObkQ" #Rockstar Pro Wrestling
YOUTUBE_CHANNEL_ID_7544 = "UC4F0NNPiR-inhW8oMp0dujQ" #Rocky Mountain Pro Wrestling
YOUTUBE_CHANNEL_ID_7545 = "UC30Ia39JmGJASWQSyQOQYAQ" #Shimmer Wrestling Channel
YOUTUBE_CHANNEL_ID_7546 = "UCzE_STJfNMe3KKQLTrP3rYg" #Full Impact Pro Channel
YOUTUBE_CHANNEL_ID_7547 = "UC_3yt61rzKZgjhyrLi-lU8A" #Southern States Wrestling
YOUTUBE_CHANNEL_ID_7548 = "UCqjt59YsM4JlcnMjxwSbNSw" #IWA Mid South Wrestling
YOUTUBE_CHANNEL_ID_7549 = "UCLm7jUPKpOw-dz2LvGtV3rA" #Top Rope Promotions Channel
YOUTUBE_CHANNEL_ID_7550 = "BritishBombshells"        #British Bombshells Wrestling
YOUTUBE_CHANNEL_ID_7551 = "UCdwEl3-QFixMQW2IzWjdhpw" #Total Womens Wrestling Channel
YOUTUBE_CHANNEL_ID_7552 = "WrestlingDivaz"           #Wrestling Divaz Channel
YOUTUBE_CHANNEL_ID_7553 = "vipguide"                 #United Wrestling Network
YOUTUBE_CHANNEL_ID_7554 = "chrisidolrocks"           #WCF Wrestling Channel
YOUTUBE_CHANNEL_ID_7555 = "jstep009"                 #Vanguard Championship Wrestling
YOUTUBE_CHANNEL_ID_7556 = "doaprowrestling"          #DOA Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7557 = "UCSHCTJS2P4Hvu_reLKtiT6g" #NWA: National Wrestling Alliance
YOUTUBE_CHANNEL_ID_7558 = "ringofhonor"              #Ring Of Honor Wrestling Channel
YOUTUBE_CHANNEL_ID_7559 = "majorleaguewrestling"     #Major League Wrestling Channel
YOUTUBE_CHANNEL_ID_7560 = "WWEFanNation"             #WWE Official Channel
YOUTUBE_CHANNEL_ID_7561 = "UCFN4JkGP_bVhAdBsoV9xftA" #All Elite Wrestling Channel
YOUTUBE_CHANNEL_ID_7562 = "TNAwrestling"             #Impact Wrestling Channel
YOUTUBE_CHANNEL_ID_7563 = "UCFAA7NmLmwcL9bbX_gXEV0g" #Evolve Wrestling Channel
YOUTUBE_CHANNEL_ID_7564 = "UCzaW5OsUJKVrofaK0303Yqg" #Revolution Pro Wrestling
YOUTUBE_CHANNEL_ID_7565 = "UC1lgJkpCx_0SMzsvrTCdxPw" #New Japan Pro Wrestling
YOUTUBE_CHANNEL_ID_7566 = "GFWWrestling"             #Global Force Wrestling
YOUTUBE_CHANNEL_ID_7567 = "EmpireStateWrestling"     #Empire State Wrestling
YOUTUBE_CHANNEL_ID_7568 = "UC4FgPd4vwU69mqZuBYst0NQ" #Premier Pro Wrestling
YOUTUBE_CHANNEL_ID_7569 = "NWASmokyMtn"              #NWA Smokey Mountain
YOUTUBE_CHANNEL_ID_7570 = "TheBookerTROW"            #Reality Of Wrestling
YOUTUBE_CHANNEL_ID_7571 = "luchalibreaaatv"          #Lucha Libre AAA TV Channel
YOUTUBE_CHANNEL_ID_7572 = "UCy91SdPgEDZnCHHm5ag32yQ" #Beyond Wrestling Channel
YOUTUBE_CHANNEL_ID_7573 = "UCnoxa_lxzuctg5MvZPNvU4Q" #Lucha Britannia Channel
YOUTUBE_CHANNEL_ID_7574 = "" #
YOUTUBE_CHANNEL_ID_7575 = "UCHqemBGAZ5j5DVVdkj2KvvQ" #Over The Top Wrestling Channel
YOUTUBE_CHANNEL_ID_7576 = "UCCbMQBiZovHmssEUu_OZjrg" #Chikara Wrestling Channel
YOUTUBE_CHANNEL_ID_7577 = "" #
YOUTUBE_CHANNEL_ID_7578 = "UCbP2Y0iw314ShQVfgklJF_A" #Dominating Backyard Wrestling
YOUTUBE_CHANNEL_ID_7579 = "discoverywrestling"       #Discovery Wrestling Channel
YOUTUBE_CHANNEL_ID_7580 = "UCw8fAQ659cF3pgNUeY5kJLw" #Primos Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_7581 = "UC2nbUh4nD_ozXOmeLgMRicw" #Best Of The West Wrestling
YOUTUBE_CHANNEL_ID_7582 = "StLouisWrestling"         #Saint Louis Wrestling
YOUTUBE_CHANNEL_ID_7583 = "UCBZ2Hl4YPU0Dzxuj3a3qSQw" #Defy Wrestling Channel
YOUTUBE_CHANNEL_ID_7584 = "OfficialPPW"              #Pure Power Wrestling
YOUTUBE_CHANNEL_ID_7585 = "melbcitywrestling"        #Melbourne City Wrestling
YOUTUBE_CHANNEL_ID_7586 = "IHWE2009"                 #IHWE Professional Wrestling
YOUTUBE_CHANNEL_ID_7587 = "UC8ghcJUjZfy2M6Pqb7gQ0Dg" #UK Wrestling Media TV
YOUTUBE_CHANNEL_ID_7588 = "Houseofglory1"            #House Of Glory Wrestling
YOUTUBE_CHANNEL_ID_7589 = "EvoProWrestling1"         #Evolution Pro Wrestling
YOUTUBE_CHANNEL_ID_7590 = "THERISEONLINE"            #Rise Underground Pro
YOUTUBE_CHANNEL_ID_7591 = "SmashWrestling1"          #Smash Wrestling Channel
YOUTUBE_CHANNEL_ID_7592 = "pwaaustralia"             #Pro Wrestling Australia
YOUTUBE_CHANNEL_ID_7593 = "UC5AJlsjiUQSgeuWpjssfilw" #Appalachian Mountain Wrestling
YOUTUBE_CHANNEL_ID_7594 = "" #
YOUTUBE_CHANNEL_ID_7595 = "" #
YOUTUBE_CHANNEL_ID_7596 = "" #
YOUTUBE_CHANNEL_ID_7597 = "" #
YOUTUBE_CHANNEL_ID_7598 = "" #
YOUTUBE_CHANNEL_ID_7599 = "" #
YOUTUBE_CHANNEL_ID_7600 = "" #


YOUTUBE_CHANNEL_ID_7739 = "FIFATV"                             #The FIFA TV Channel
YOUTUBE_CHANNEL_ID_7740 = "UFC"                                #Ultimate Fighting Championship
YOUTUBE_CHANNEL_ID_7741 = "UCxvz6hylB7hsKKK38FE5vXg"           #Football Live Gameplay
YOUTUBE_CHANNEL_ID_7742 = "2012NBCOlympics"                    #NBC Sports Channel
YOUTUBE_CHANNEL_ID_7743 = "UC1QQAUSQX4DF9XXne54oCgQ"           #Motorsports on NBC
YOUTUBE_CHANNEL_ID_7744 = "NFL"                                #NFL Official Channel
YOUTUBE_CHANNEL_ID_7745 = "UCJdl3Paao2f3ha5JXMYUCIA"           #NFL Throwback Channel
YOUTUBE_CHANNEL_ID_7746 = "ACCDigitalNetwork"                  #Atlantic Coast Conference
YOUTUBE_CHANNEL_ID_7747 = "" #
YOUTUBE_CHANNEL_ID_7748 = "" #
YOUTUBE_CHANNEL_ID_7749 = "NBA"                                #NBA Official Channel
YOUTUBE_CHANNEL_ID_7750 = "WNBA"                               #WNBA Official Channel
YOUTUBE_CHANNEL_ID_7751 = "shosports"                          #Showtime Sports Channel
YOUTUBE_CHANNEL_ID_7752 = "Wimbledon"                          #The Wimbledon Channel
YOUTUBE_CHANNEL_ID_7753 = "BTSportOfficial"                    #BT Sport Official Channel
YOUTUBE_CHANNEL_ID_7754 = "UC_JQGBtA7P0RwkRxd7xpJcA"           #Sky Sports Boxing Channel
YOUTUBE_CHANNEL_ID_7755 = "FoxSports"                          #The Fox Sports Channel
YOUTUBE_CHANNEL_ID_7756 = "UCNAf1k0yIjyGu3k9BwAg3lg"           #Sky Sports Football Channel
YOUTUBE_CHANNEL_ID_7757 = "ESPN"                               #The ESPN Sports Channel
YOUTUBE_CHANNEL_ID_7758 = "MLB"                                #Major League Baseball
YOUTUBE_CHANNEL_ID_7759 = "Formula1"                           #The Formula 1 Channel
YOUTUBE_CHANNEL_ID_7760 = "videoFIVB"                          #Volleyball World Channel
YOUTUBE_CHANNEL_ID_7761 = "BeINsportUSA"                       #The BEIN Sports Channel
YOUTUBE_CHANNEL_ID_7762 = "judo"                               #The IJF World Judo Tour
YOUTUBE_CHANNEL_ID_7763 = "SPORTSNETCANADA"                    #Sportsnet Canada Channel
YOUTUBE_CHANNEL_ID_7764 = "TheOfficialNASCAR"                  #Nascar Official Channel
YOUTUBE_CHANNEL_ID_7765 = "NHLVideo"                           #The NHL Video Channel
YOUTUBE_CHANNEL_ID_7766 = "isafchannel"                        #World Sailing TV Channel
YOUTUBE_CHANNEL_ID_7767 = "" #
YOUTUBE_CHANNEL_ID_7768 = "" #
YOUTUBE_CHANNEL_ID_7769 = "" #
YOUTUBE_CHANNEL_ID_7770 = "" #
YOUTUBE_CHANNEL_ID_7771 = "" #

YOUTUBE_CHANNEL_ID_7901 = "PLU12uITxBEPHOJO1FU8qll6gQmKcXp5S7" # Live Now
YOUTUBE_CHANNEL_ID_7902 = "PL3ZQ5CpNulQmA2Tegc98c0XXJTzuKb0wS" # Live Now News
YOUTUBE_CHANNEL_ID_7903 = "PL8fVUTBmJhHKq0MhIplzljtGhHN2E_jk0" # Live Now Sports
YOUTUBE_CHANNEL_ID_7904 = "UC9pYOJPB5UYlMlGKKZWo-Bw/live" # Live Now Space
YOUTUBE_CHANNEL_ID_7905 = "UC-2KSeUU5SMCX6XLRD-AEvw/live" # Live Now Animals
YOUTUBE_CHANNEL_ID_7906 = "PLiCvVJzBupKmEehQ3hnNbbfBjLUyvGlqx" # Live Now Gaming
YOUTUBE_CHANNEL_ID_7907 = "PLU12uITxBEPGCFuLT2sLanij7AVCbtl57" # Live Now Mobile
YOUTUBE_CHANNEL_ID_7908 = "PLU12uITxBEPFteq84ODnPRJjskBgVQC2M" # Recent Live Stream
YOUTUBE_CHANNEL_ID_7909 = "PLU12uITxBEPF8XZZj4LudutrjxKqh_gtQ" # Live Now Featured
YOUTUBE_CHANNEL_ID_7910 = "PLU12uITxBEPHHlOIWGAIezbshH82rGpKp" # Upcoming Live Events

YOUTUBE_CHANNEL_ID_7911 = "PL6KcpeEiGPpwkH-CcX2w_9IWBUK0MzNJN" #Live Music Radio
YOUTUBE_CHANNEL_ID_7912 = "PLGK7w43pdbIjBctumie9-6yfhKCm2Daqf" #24-7 Music Streams
YOUTUBE_CHANNEL_ID_7913 = "PLc1GvsnG150s1Lgmi9_EHWiBYfq8uvNV_" #Music Streams 24-7
YOUTUBE_CHANNEL_ID_7914 = "PLjFvCZN-Ya42nCcX3hEhxwOOu8lwt9IFS" #Metal Music Streams
YOUTUBE_CHANNEL_ID_7915 = "PLu7dSuJ1-Ld4XF9_I8rJv489sSlT6Ui9P" #24-7 Rap, R&B, Hip-Hop
YOUTUBE_CHANNEL_ID_7916 = "PLT_RM8D-GkOkl5BHyHUI5SKBoDaGE3k1p" #More 24-7 Music Streams
YOUTUBE_CHANNEL_ID_7917 = "PL1Z8ruLu54CKO1Mw2GiBUCjhE-QjcrWXY" #Relax, Jazz, Piano, 24-7
YOUTUBE_CHANNEL_ID_7918 = "UC4R8DWoMoI7CAwX8_LjQHig"           #
YOUTUBE_CHANNEL_ID_7919 = "gc1YUY5jUm0&list=PLrIt3uECvxkpS93yaj85AFd4Vy4b0bRur" # Timboo N Tuskar
YOUTUBE_CHANNEL_ID_7920 = "xmVPxjaFUBM&list=PLsXbcWIxYGOF6iBM2BxkAHZlUWz_90olH" # spongebob
YOUTUBE_CHANNEL_ID_7921 = "" #
YOUTUBE_CHANNEL_ID_7922 = "" #
YOUTUBE_CHANNEL_ID_7923 = "" #
YOUTUBE_CHANNEL_ID_7924 = "" #

YOUTUBE_CHANNEL_ID_7925 = ""           #
YOUTUBE_CHANNEL_ID_7926 = "smokeybarz"                         #SBTV Music Channel
YOUTUBE_CHANNEL_ID_7927 = "UCv7Bgr5Mq-dPYu-Ol4AocEA"           #Shinedown Channel
YOUTUBE_CHANNEL_ID_7928 = "UCOJZ1tna8yj8mAEITPkHNCQ"           #Slipknot Channel
YOUTUBE_CHANNEL_ID_7929 = "UCqC_GY2ZiENFz2pwL0cSfAw"           #Green Day Channel
YOUTUBE_CHANNEL_ID_7930 = "UCX2_tsfS1lWaNg26UUuWrxA"           #Greta Van Fleet
YOUTUBE_CHANNEL_ID_7931 = "UCM-CWGUijAC-8idv6k6Fygw"           #Depeche Mode Channel
YOUTUBE_CHANNEL_ID_7932 = "UCocfdCiKujljqcGC-STMsCQ"           #Stone Temple Pilots
YOUTUBE_CHANNEL_ID_7933 = "UCE8NoMFnai3tTuwdiQJ-78A"           #Skillet Channel
YOUTUBE_CHANNEL_ID_7934 = "HDPinkFloyd"                        #Pink Floyd Channel
YOUTUBE_CHANNEL_ID_7935 = "acdc"                               #AC/DC Channel
YOUTUBE_CHANNEL_ID_7936 = "DefLeppardOfficial"                 #Def Leppard Channel
YOUTUBE_CHANNEL_ID_7937 = "deeppurpleos"                       #Deep Purple Channel
YOUTUBE_CHANNEL_ID_7938 = "UC4gPNusMDwx2Xm-YI35AkCA"           #Music: U2 Channel
YOUTUBE_CHANNEL_ID_7939 = "UCw28dvU7NbdZPF9kEPrT7aA"           #Rival Sons Channel
YOUTUBE_CHANNEL_ID_7940 = "UC2dZ0a6uJJHWMoF7oah6zew"           #The Band Camino
YOUTUBE_CHANNEL_ID_7941 = "UCsxtEOcwpVO9Rnw93Fuv2pQ"           #Dirty Honey Channel
YOUTUBE_CHANNEL_ID_7942 = "UCt_naO54DunfncZ0UO1rHbw"           #The Crobot Channel
YOUTUBE_CHANNEL_ID_7943 = "UCr79-QZv1_VGlxVWLc28xrQ"           #Foreigner Channel
YOUTUBE_CHANNEL_ID_7944 = "alyankovic"                         #Weird Al Yankovic
YOUTUBE_CHANNEL_ID_7945 = "UCipLjr-h2iaEBWMJVfK2e2A"           #Lynyrd Skynyrd Channel
YOUTUBE_CHANNEL_ID_7946 = "UCNL1ZadSjHpjm4q9j2sVtOA"           #Lady Gaga Channel
YOUTUBE_CHANNEL_ID_7947 = "UCcgqSM4YEo5vVQpqwN-MaNw"           #Rihanna Channel
YOUTUBE_CHANNEL_ID_7948 = "UCbulh9WdLtEXiooRcYK7SWw"           #Metallica Channel
YOUTUBE_CHANNEL_ID_7949 = "UCgffc95YDBlkGrBAJUHUmXQ"           #Britney Spears Channel
YOUTUBE_CHANNEL_ID_7950 = "UCb0vzLwvr7xbJgdqMzejDhw"           #Cranberries Channel
YOUTUBE_CHANNEL_ID_7951 = "UCEuOwB9vSL1oPKGNdONB4ig"           #Red Hot Chili Peppers
YOUTUBE_CHANNEL_ID_7952 = "UCiMhD4jzUqG-IgPzUmmytRQ"           #Queen Official Channel
YOUTUBE_CHANNEL_ID_7953 = "UCZU9T1ceaOgwfLRq7OKFU4Q"           #Linkin Park Channel
YOUTUBE_CHANNEL_ID_7954 = "UCFMZHIQMgBXTSxsr86Caazw"           #Nirvana Channel
YOUTUBE_CHANNEL_ID_7955 = "UCdIs5dRqgZ1IWOdLZimHL_w"           #Lenny Kravitz Channel
YOUTUBE_CHANNEL_ID_7956 = "UCIak6JLVOjqhStxrL1Lcytw"           #Gun N Roses Channel
YOUTUBE_CHANNEL_ID_7957 = "UCjwhEPNX5rsU6gl_8qZMQZg"           #Kid Rock Channel
YOUTUBE_CHANNEL_ID_7958 = "UCi2KNss4Yx73NG0JARSFe0A"           #Foo Fighters Channel
YOUTUBE_CHANNEL_ID_7959 = "UCK9X9JACEsonjbqaewUtICA"           #Alice In Chains
YOUTUBE_CHANNEL_ID_7960 = "UCB_Z6rBg3WW3NL4-QimhC2A"           #Rolling Stones Channel
YOUTUBE_CHANNEL_ID_7961 = ""           #
YOUTUBE_CHANNEL_ID_7962 = "UCYvmuw-JtVrTZQ-7Y4kd63Q"           #Katy Perry Channel
YOUTUBE_CHANNEL_ID_7963 = "UCxMAbVFmxKUVGAll0WVGpFw"           #Cardi B Channel
YOUTUBE_CHANNEL_ID_7964 = "UCqECaJ8Gagnn7YCbPEzWH6g"           #Taylor Swift Channel
YOUTUBE_CHANNEL_ID_7965 = "UC-OO324clObi3H-U0bP77dw"           #Snoop Dogg Channel
YOUTUBE_CHANNEL_ID_7966 = "UCaKZA66vM_TUpetUNohmR0A"           #Led Zeppelin Channel
YOUTUBE_CHANNEL_ID_7967 = "UC49r4GNHHpc-eQ9hmD2Rg6A"           #The Eagles Channel
YOUTUBE_CHANNEL_ID_7968 = "UC-MMd_17p3qNSTVbLdiYzow"           #Rap Party Channel
YOUTUBE_CHANNEL_ID_7969 = ""           #
YOUTUBE_CHANNEL_ID_7970 = "blackeyedpeasvideo"                 #Black Eyed Peas
YOUTUBE_CHANNEL_ID_7971 = "VHTelevision"                       #Van Halen Channel
YOUTUBE_CHANNEL_ID_7972 = "UCsFPCqkPsesPa8XxN1pJx-w"           #The Heart Channel
YOUTUBE_CHANNEL_ID_7973 = "thebeatles"                         #The Beatles Channel
YOUTUBE_CHANNEL_ID_7974 = "UC7eaRqtonpyiYw0Pns0Au_g"           #The REM Channel
YOUTUBE_CHANNEL_ID_7975 = "UCEqrtYLjy1o4hvaUI0J530w"           #Jimi Hendrix Channel
YOUTUBE_CHANNEL_ID_7976 = "" #
YOUTUBE_CHANNEL_ID_7977 = "" #
YOUTUBE_CHANNEL_ID_7978 = "" #
YOUTUBE_CHANNEL_ID_7979 = "" #
YOUTUBE_CHANNEL_ID_7980 = "" #
YOUTUBE_CHANNEL_ID_7981 = ""           #
YOUTUBE_CHANNEL_ID_7982 = "" #
YOUTUBE_CHANNEL_ID_7983 = "" #
YOUTUBE_CHANNEL_ID_7984 = "" #
YOUTUBE_CHANNEL_ID_7985 = "" #
YOUTUBE_CHANNEL_ID_7986 = "" #
YOUTUBE_CHANNEL_ID_7987 = "" #
YOUTUBE_CHANNEL_ID_7988 = "" #
YOUTUBE_CHANNEL_ID_7989 = "" #
YOUTUBE_CHANNEL_ID_7990 = "" #
YOUTUBE_CHANNEL_ID_7991 = ""           #
YOUTUBE_CHANNEL_ID_7992 = "" #
YOUTUBE_CHANNEL_ID_7993 = "" #
YOUTUBE_CHANNEL_ID_7994 = "" #
YOUTUBE_CHANNEL_ID_7995 = "" #
YOUTUBE_CHANNEL_ID_7996 = "" #
YOUTUBE_CHANNEL_ID_7997 = "" #
YOUTUBE_CHANNEL_ID_7998 = "" #
YOUTUBE_CHANNEL_ID_7999 = "" #


#=====================================================================================================================


def WrestlingChannel():

	add_link_info('[B][COLORorange]=== Wrestling ===[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7560+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ring Of Honor Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7558+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Impact Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7562+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NWA Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7557+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Japan Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7565+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Global Force Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7566+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Elite Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7561+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Evolve Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7563+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reality Of Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7570+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Major League Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7559+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Revolution Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7564+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Bombshells Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7550+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Women Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7513+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WCW Womens Wrestling Classics[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7505+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shine Womans Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7526+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shimmer Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7545+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womans Wrestling Revolution[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7501+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]EVE Womens Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7540+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Total Womans Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7551+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Divaz Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7552+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lucha Libre AAA Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7571+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lucha Britannia Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7573+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Consejo Mundial de Lucha Libre[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7522+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7527+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Guerrilla[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7502+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Progress Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7541+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Over The Top Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7575+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Future Stars Of Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7516+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Classic HD Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7534+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]CZW Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7509+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]CZW Dojowars Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7510+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]House Of Hardcore Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7519+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westside Xtreme Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7536+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dragon Gate Pro Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7511+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chikara Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7576+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Innovate Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7507+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Wrestling League[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7529+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Generation Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7532+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Freelance Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7514+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paragon Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7535+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Premiere Wrestling Xperience[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7524+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]United Wrestling Coalition[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7533+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]International Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7521+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Premier Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7568+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anarchy Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7503+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Attack Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7504+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Beyond Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7572+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chaotic Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7506+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Top Rope Promotions Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7549+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ultra Championship Wrestling Zero[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7537+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Wave Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7508+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Impact Pro Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7546+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AAW Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7500+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IWF Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7523+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World Association Of Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7520+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]MCW Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7528+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rockstar Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7543+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World League Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7518+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New European Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7531+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Preston City Wresling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7530+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]House Of Bricks Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7515+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Southern States Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7547+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Gold Rush Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7517+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NWA Smokey Mountain[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7569+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rocky Mountain Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7544+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IWA Mid South Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7548+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Empire State Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7567+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Empire Wrestling Federation[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7512+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jersey All Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7542+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Keystone State Wrestling Alliance[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7525+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New England Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7539+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]United Wrestling Network[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7553+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WCF Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7554+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Vanguard Championship Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7555+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DOA Pro Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7556+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Discovery Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7579+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Primos Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7580+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dominating Backyard Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7578+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Wrestling Media TV[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7587+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Australia[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7592+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Melbourne City Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7585+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]House Of Glory Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7588+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IHWE Professional Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7586+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Evolution Pro Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7589+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pure Power Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7584+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Defy Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7583+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Smash Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7591+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rise Underground Pro[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7590+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Of The West Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7581+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Saint Louis Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7582+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Appalachian Mountain Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7593+"/", folder=True,
		icon=mediapath+"channels-wrestling.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

def MusicChannel():

	add_link_info('[B][COLORorange]=== Music ===[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]SBTV Music Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7926+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shinedown Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7927+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Slipknot Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7928+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Green Day Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7929+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Greta Van Fleet[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7930+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Depeche Mode Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7931+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Stone Temple Pilots[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7932+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Skillet Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7933+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pink Floyd Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7934+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The AC/DC Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7935+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Def Leppard Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7936+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Deep Purple Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7937+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music: U2 Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7938+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rival Sons Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7939+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Band Camino[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7940+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dirty Honey Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7941+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Crobot Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7942+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foreigner Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7943+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Weird Al Yankovic[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7944+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lynyrd Skynyrd Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7945+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lady Gaga Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7946+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rihanna Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7947+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metallica Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7948+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Britney Spears Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7949+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cranberries Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7950+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Red Hot Chili Peppers[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7951+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Queen Official Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7952+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Linkin Park Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7953+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nirvana Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7954+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lenny Kravitz Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7955+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kid Rock Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7957+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foo Fighters Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7958+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alice In Chains[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7959+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rolling Stones Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7960+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Katy Perry Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7962+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cardi B Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7963+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Taylor Swift Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7964+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Snoop Dogg Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7965+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Led Zeppelin Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7966+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Eagles Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7967+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rap Party Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7968+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Black Eyed Peas[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7970+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Van Halen Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7971+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Heart Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7972+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Beatles Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7973+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The REM Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7974+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jimi Hendrix Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7975+"/", folder=True,
		icon=mediapath+"channels-music.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)


def LiveChannel():

	add_link_info('[B][COLORorange]=== Live ===[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Live Now[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7901+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Upcoming Live[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7910+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Live Now: Sports[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7903+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Live Now: Space[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7904+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Live Now: Critters[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7905+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Live Now: News[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7902+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Live Now: Gaming[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7906+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Recent Live Stream[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7908+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]24-7 Music Streams[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7912+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Live Music Radio[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7911+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music Streams 24-7[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7913+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metal Music Streams[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7914+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]24-7 Rap, R&B, Hip-Hop[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7915+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 24-7 Music Streams[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7916+"/", folder=True,
		icon=mediapath+"channels-live.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)
	
def SinglesChannel():

	Singles.singles_list()
	#Common.add_channel("Def Leppard Story", icon, fanart, title=None, live=True)

def AnimeChannel():

	add_link_info('[B][COLORorange]== Anime ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Aquarion Dub Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7342+"/", folder=True,
		icon=mediapath+"channels-anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dragon Ball Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7343+"/", folder=True,
		icon=mediapath+"channels-anime.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Anime For Life Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7345+"/", folder=True,
		icon=mediapath+"channels-anime.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]Boku wa Tomodachi Ga Sukunai[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7348+"/", folder=True,
		icon=mediapath+"channels-anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hunter X Hunter[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7352+"/", folder=True,
		icon=mediapath+"channels-anime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anime: Naruto[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7353+"/", folder=True,
		icon=mediapath+"channels-anime.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)
	
def HorrorChannel():

	add_link_info('[B][COLORorange]== Horror ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The Kings Of Horror[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7200+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Viewster Horror Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7203+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Terror Films Horror Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7205+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]New Castle After Dark Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7206+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]A Touch Of Evil Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7208+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Horror Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7209+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cinenet Horror Movie Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7210+"/", folder=True,
		icon=mediapath+"channels-horror.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)
	
def ScifiChannel():

	add_link_info('[B][COLORorange]== Scifi ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Future Zone Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7100+"/", folder=True,
		icon=mediapath+"channels-scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Sci-fi TV Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7101+"/", folder=True,
		icon=mediapath+"channels-scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery Science Theater 3000[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7104+"/", folder=True,
		icon=mediapath+"channels-scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dust Sci-fi Shorts Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7105+"/", folder=True,
		icon=mediapath+"channels-scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Barbarella X Sci-fi Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7106+"/", folder=True,
		icon=mediapath+"channels-scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sci-fi Central Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7103+"/", folder=True,
		icon=mediapath+"channels-scifi.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

def SportsChannel():

	add_link_info('[B][COLORorange]== Sports ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Motocross, MX, Rally Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7002+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]EVE Womens Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7540+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sports Girl Montana Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7004+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sports Legends Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7005+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Big Mind Sports Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7006+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]BT Sport Boxing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7009+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ONE Championship Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7013+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sport Fishing Television[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7010+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sport Fishing Dan Hernandez[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7011+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]LFL Womens Football Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7012+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Women Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7513+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WCW Womens Wrestling Classics[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7505+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shine Womans Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7526+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Major League Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7559+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ring Of Honor Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7558+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NWA: National Wrestling Alliance[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7557+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The FIFA TV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7739+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ultimate Fighting Championship[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7740+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Football Live Gameplay[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7741+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NBC Sports Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7742+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Motorsports on NBC[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7743+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NFL Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7744+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NFL Throwback Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7745+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Atlantic Coast Conference[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7746+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NBA Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7749+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WNBA Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7750+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Showtime Sports Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7751+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Wimbledon Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7752+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]BT Sport Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7753+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sky Sports Boxing Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7754+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Fox Sports Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7755+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sky Sports Football Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7756+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The ESPN Sports Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7757+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Major League Baseball[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7758+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Formula 1 Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7759+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Volleyball World Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7760+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The BEIN Sports Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7761+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The IJF World Judo Tour[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7762+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sportsnet Canada Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7763+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nascar Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7764+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The NHL Video Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7765+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World Sailing TV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7766+"/", folder=True,
		icon=mediapath+"channels-sports.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)
	
def DocumentaryChannel():

	add_link_info('[B][COLORorange]== Documentary ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Space And The Universe Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7225+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Awesome Documentary Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7227+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Documentary Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7230+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Fifth Estate - Canada[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7232+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]BBC Dinosaur Documentaries[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7233+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Simply Space[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7234+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music Documentary & Concerts[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7236+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Filmrise Documentary Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7237+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Truth Documentaries Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7239+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reel Truth Crime Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7240+"/", folder=True,
		icon=mediapath+"channels-docs.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)
		
def AnimationChannel():

	add_link_info('[B][COLORorange]== Animation ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]Cartoon Movies Colectors City[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7309+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Pop Teen Toons Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7310+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Popcorn Toonz Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7311+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Monster High Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7312+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Voltron Animated Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7313+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kids Channel: Kids Video[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7315+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Bob The Builder Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7316+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Hoopla Kidz TV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7317+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Pocoyo English Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7318+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Fireman Sam Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7319+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Not Necessarily For Kids[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7320+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]VHS Museum Of Cartoons Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7322+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Morphle TV Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7323+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Olivia The Pig Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7324+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Popeye & Friends Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7325+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Sonic The Hedgehog Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7326+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Super Mario Bros Super Show[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7328+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]SheRa Princess Of Power[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7329+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Mr. Bean Cartoon World[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7330+"/", folder=True,
		icon=mediapath+"channels-animation.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

def MixedChannel():

	add_link_info('[B][COLORorange]== Mixed Genre ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The PopcornFlix Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7063+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Film Zone Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7064+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bigtime Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7066+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Filmrise Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7067+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Viewster Movies Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7068+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Maverick Movie Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7069+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Movieholic Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7070+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhits Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7071+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Artflix Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7050+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Flixdome Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7051+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]One Night At The Drive-in[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7053+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Timeless Classic Films[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7061+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Biscoot Hollywood Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7054+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel 3 Youtube[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7055+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pizza Flix Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7056+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]FamBrand TV Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7057+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Broken Trout Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7058+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drelbcom Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7059+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ampop Films Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7060+"/", folder=True,
		icon=mediapath+"channels-mixed.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

def ClassicChannel():

	add_link_info('[B][COLORorange]== Classic ==[/COLOR][/B]', mediapath+'channels.png', fanart)
	
	Add_Dir(
		name="[COLOR white][B]The Vintage Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7026+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Jagged Relief Movie Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7027+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Classic Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7028+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classix Flix Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7031+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]RBM Pictures Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7032+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Westerns Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7034+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Classic Cinema Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7035+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Retrospective Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7036+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Spuds Classic Video Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7040+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movie Navigator Classics[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7041+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Manic Movie Classics[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7042+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Amazingly Classic Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7043+"/", folder=True,
		icon=mediapath+"channels-classic.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

def FamilyChannel():

	add_link_info('[B][COLORorange]== Family ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Cloud 5 Family Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7075+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7077+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]FamBrand TV Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7057+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kedoo ToonsTV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7078+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Westerns On The Web[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7079+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Wild West Toys Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7080+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Grjngo Westerns Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7088+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Western Mania Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7089+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Vids 4 Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7081+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WB Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7082+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Club Baboo Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7083+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids Au Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7084+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fun Science For Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7085+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7086+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Universal Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7087+"/", folder=True,
		icon=mediapath+"channels-family.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

def FanfilmChannel():

	add_link_info('[B][COLORorange]== Fan Film ==[/COLOR][/B]', mediapath+'channels.png', fanart)
	
	Add_Dir(
		name="[COLOR white][B]Star Trek Fan Made: Star Trek[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7250+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Spirit Of The Force: Star Wars[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7251+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Throwback Studioz: Superheros[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7252+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Lonely Spider: Spider-Man[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7253+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Craftmanship: Marvel & More[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7254+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Story 1st Films: Marvel Knights[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7255+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]No Mercy Fan Film: Punisher[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7256+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Joey Lever: Spider-Man Fan Films[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7257+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Six Side Studio: Spider-Man[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7258+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman Fan Films Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7259+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shields Productions Justice League[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7260+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Spider-Man, Batman, Superman, Star Wars[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7261+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superheroine Fan Films[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7262+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superman Celebration Films[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7263+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The 1st Caped Crusaders Films[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7264+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Doctor Who Fan Film Database[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_7265+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Doctor Who: Infinite Films[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_7266+"/", folder=True,
		icon=mediapath+"channels-fanfilm.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)
	
def Playlists():

	add_link_info('[B][COLORorange]== Playlists ==[/COLOR][/B]', mediapath+'channels.png', fanart)

	Add_Dir(
		name="[COLOR white][B]1930s Film Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7276+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1940s Film Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7277+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1940s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7278+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1950s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7281+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1950s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7282+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cheesy 1950s Sci-fi[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7283+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1950s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7284+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1960s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7285+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1960s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7286+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1960s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7287+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1970s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7288+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1970s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7290+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1970s Horror[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7291+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1970s Made For TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7293+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1980s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7294+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1980s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7295+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies: More 1980s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7296+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1980s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7297+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1990s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7299+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1990s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7300+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1990s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7301+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1990s Sci-fi Horror[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7303+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 2000s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7304+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Movies In 2000s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_7305+"/", folder=True,
		icon=mediapath+"channels-years.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
