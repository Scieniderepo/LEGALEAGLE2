# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *
from resources.lib.modules.diyfix import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.diyfix')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

def Main():

	add_link_info('[B][COLORorange]=== DIY FIX ===[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]Fix Musical Instruments[/B][/COLOR]',BASE,44,mediapath+'diy_musical.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sm. Appliance Repair[/B][/COLOR]',BASE,41,mediapath+'diy_gadgets.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Appliance Repair[/B][/COLOR]',BASE,42,mediapath+'diy_appliance.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Lawnmower Repair[/B][/COLOR]',BASE,45,mediapath+'diy_lawn.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Home Repair And More[/B][/COLOR]',BASE,46,mediapath+'diy_home.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Electronics Repair[/B][/COLOR]',BASE,47,mediapath+'diy_electronics.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Gardening And More[/B][/COLOR]',BASE,43,mediapath+'diy_garden.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Automotive Repair[/B][/COLOR]',BASE,48,mediapath+'diy_auto.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Pets Info And Tips[/B][/COLOR]',BASE,49,mediapath+'diy_pets.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORlime] [/COLOR][/B]', icon, fanart)

#===============================================================================================================
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r

#====================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
	
#===== DIY FIX =====

if mode == 41:
	Gadgets()		
		
elif mode == 42:
	Appliance()

elif mode == 43:
	Garden()
	
elif mode == 44:
	DIY_Musical()

elif mode == 45:
	Lawn()

elif mode == 46:
	Home()

elif mode == 47:
	Electronics()
	
elif mode == 48:
	Auto()

elif mode == 49:
	Pets()

elif mode is None:
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)
