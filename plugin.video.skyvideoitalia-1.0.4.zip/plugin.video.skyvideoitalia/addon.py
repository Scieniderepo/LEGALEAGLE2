from resources.lib.main import SkyVideoItalia

sky = SkyVideoItalia()
sky.main()
