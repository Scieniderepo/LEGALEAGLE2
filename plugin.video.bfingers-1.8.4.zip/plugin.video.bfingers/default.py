# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *
from resources.lib.modules.bfingers import *
from resources.lib.modules.scraper import *
from resources.lib.modules.showVID import *

#from resources.lib.modules.tromaGenres import *
#from resources.lib.modules.movies import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.bfingers')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
genreImage = 'special://home/addons/script.j1.artwork/lib/resources/images/genres/'
mediapath = 'http://j1wizard.net/media/'

def Main():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)
	
	addDirMain('[COLOR white][B]Featured Movies[/B][/COLOR]',BASE,404,mediapath+'featured.png',fanart)
	addDirMain('[COLOR white][B]Action Movies[/B][/COLOR]',BASE,0,mediapath+'action.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animated Movies[/B][/COLOR]',BASE,1,mediapath+'animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Movies[/B][/COLOR]',BASE,2,mediapath+'classic.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Comedy, Romance Movies[/B][/COLOR]',BASE,3,mediapath+'comedy.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Crime, Mystery, Noir, Movies[/B][/COLOR]',BASE,4,mediapath+'crime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentaries[/B][/COLOR]',BASE,5,mediapath+'docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Drama & War Movies[/B][/COLOR]',BASE,6,mediapath+'drama.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family, Animated, Anime Movies[/B][/COLOR]',BASE,7,mediapath+'family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Horror Movies[/B][/COLOR]',BASE,8,mediapath+'horror.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Movie Mix[/B][/COLOR]',BASE,9,mediapath+'movie_mix.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Music Video[/B][/COLOR]',BASE,10,mediapath+'music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Scifi Movies[/B][/COLOR]',BASE,11,mediapath+'scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports, Games, Docs, Movies[/B][/COLOR]',BASE,12,mediapath+'sports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Toddler Video[/B][/COLOR]',BASE,13,mediapath+'toddlers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Western Movies[/B][/COLOR]',BASE,14,mediapath+'western.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Playlist By Year[/B][/COLOR]',BASE,15,mediapath+'years.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Risque 18+ Movies[/B][/COLOR]',BASE,405,mediapath+'risque.png',fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

def BFgenreList():

	add_link_info('[B][COLORorange]== Choose Genre ==[/COLOR][/B]', genreImage+'GenreLogo.png', fanart)
	
	addDirMain('[COLOR white][B]All Movies[/B][/COLOR]',BASE,403,genreImage+'All.png', fanart)
	addDirMain('[COLOR white][B]Action Movies[/B][/COLOR]',BASE,410,genreImage+'Action.png', fanart)
	addDirMain('[COLOR white][B]Anime Movies[/B][/COLOR]',BASE,426,genreImage+'Anime.png', fanart)
	addDirMain('[COLOR white][B]Classic Movies[/B][/COLOR]',BASE,412,genreImage+'Classic.png', fanart)
	addDirMain('[COLOR white][B]Comedy Movies[/B][/COLOR]',BASE,413,genreImage+'Comedy.png', fanart)
	addDirMain('[COLOR white][B]Crime Movies[/B][/COLOR]',BASE,414,genreImage+'Crime.png', fanart)
	addDirMain('[COLOR white][B]Documentaries[/B][/COLOR]',BASE,415,genreImage+'Documentary.png', fanart)
	addDirMain('[COLOR white][B]Drama Movies[/B][/COLOR]',BASE,416,genreImage+'Drama.png', fanart)
	addDirMain('[COLOR white][B]Family Movies[/B][/COLOR]',BASE,417,genreImage+'Family.png', fanart)
	addDirMain('[COLOR white][B]Fantasy Movies[/B][/COLOR]',BASE,418,genreImage+'Fantasy.png', fanart)
	addDirMain('[COLOR white][B]Horror Movies[/B][/COLOR]',BASE,419,genreImage+'Horror.png', fanart)
	addDirMain('[COLOR white][B]Music Movies[/B][/COLOR]',BASE,420,genreImage+'Music.png', fanart)
	addDirMain('[COLOR white][B]Mystery Movies[/B][/COLOR]',BASE,427,genreImage+'Mystery.png', fanart)
	addDirMain('[COLOR white][B]Scifi Movies[/B][/COLOR]',BASE,421,genreImage+'Scifi.png', fanart)
	addDirMain('[COLOR white][B]Sports Movies[/B][/COLOR]',BASE,422,genreImage+'Sports.png', fanart)
	addDirMain('[COLOR white][B]Thriller Movies[/B][/COLOR]',BASE,423,genreImage+'Thriller.png', fanart)
	addDirMain('[COLOR white][B]Western Movies[/B][/COLOR]',BASE,424,genreImage+'Western.png', fanart)
	addDirMain('[COLOR white][B]Zombie Movies[/B][/COLOR]',BASE,425,genreImage+'Zombie.png', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', genreImage+'GenreLogo.png', fanart)

def RQgenreList():

	add_link_info('[B][COLORorange]== Choose Genre ==[/COLOR][/B]', genreImage+'GenreLogo.png', fanart)
	
	addDirMain('[COLOR white][B]All Movies[/B][/COLOR]',BASE,409,genreImage+'All.png', fanart)
	addDirMain('[COLOR white][B]Action Movies[/B][/COLOR]',BASE,510,genreImage+'Action.png', fanart)
	addDirMain('[COLOR white][B]Anime Movies[/B][/COLOR]',BASE,526,genreImage+'Anime.png', fanart)
	addDirMain('[COLOR white][B]Classic Movies[/B][/COLOR]',BASE,512,genreImage+'Classic.png', fanart)
	addDirMain('[COLOR white][B]Comedy Movies[/B][/COLOR]',BASE,513,genreImage+'Comedy.png', fanart)
	addDirMain('[COLOR white][B]Crime Movies[/B][/COLOR]',BASE,514,genreImage+'Crime.png', fanart)
	addDirMain('[COLOR white][B]Documentaries[/B][/COLOR]',BASE,515,genreImage+'Documentary.png', fanart)
	addDirMain('[COLOR white][B]Drama Movies[/B][/COLOR]',BASE,516,genreImage+'Drama.png', fanart)
	addDirMain('[COLOR white][B]Fantasy Movies[/B][/COLOR]',BASE,518,genreImage+'Fantasy.png', fanart)
	addDirMain('[COLOR white][B]Horror Movies[/B][/COLOR]',BASE,519,genreImage+'Horror.png', fanart)
	addDirMain('[COLOR white][B]Music Movies[/B][/COLOR]',BASE,520,genreImage+'Music.png', fanart)
	addDirMain('[COLOR white][B]Mystery Movies[/B][/COLOR]',BASE,527,genreImage+'Mystery.png', fanart)
	addDirMain('[COLOR white][B]Romance Movies[/B][/COLOR]',BASE,517,genreImage+'Romance.png', fanart)
	addDirMain('[COLOR white][B]Scifi Movies[/B][/COLOR]',BASE,521,genreImage+'Scifi.png', fanart)
	addDirMain('[COLOR white][B]Sports Movies[/B][/COLOR]',BASE,522,genreImage+'Sports.png', fanart)
	addDirMain('[COLOR white][B]Thriller Movies[/B][/COLOR]',BASE,523,genreImage+'Thriller.png', fanart)
	addDirMain('[COLOR white][B]Western Movies[/B][/COLOR]',BASE,524,genreImage+'Western.png', fanart)
	#addDirMain('[COLOR white][B]Zombie Movies[/B][/COLOR]',BASE,525,genreImage+'Zombie.png', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', genreImage+'GenreLogo.png', fanart)


#==========================================================================================================

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r

#====================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#==========================================================================================================

if mode == 0:
	Action()
		
elif mode == 1:
	Animation()		
		
elif mode == 2:
	Classic()

elif mode == 3:
	Comedy()
	
elif mode == 4:
	Crime()

elif mode == 5:
	Docs()

elif mode == 6:
	Drama()

elif mode == 7:
	Family()
	
elif mode == 8:
	Horror()

elif mode == 9:
	Movie_Mix()

elif mode == 10:
	Music()

elif mode == 11:
	Scifi()
	
elif mode == 12:
	Sports()
	
elif mode == 13:
	Toddlers()

elif mode == 14:
	Western()

elif mode == 15:
	Bfingers_Playlists()

#=========================================
		
elif mode == 402:
	from resources.lib.modules.showsPL import *

elif mode == 403:
    Listing.Genres("All","Movies")
	
elif mode == 404:
    BFgenreList()

elif mode == 405:
    RQgenreList()
	
elif mode == 406:
    concertListing.Genres("All")
	
elif mode == 407:
    nowListing.Genres("All")
	
elif mode == 408:
    karaokeCH.Genres("All")

elif mode == 409:
    Listing.Genres("All","Sexy")

#=========================================

elif mode == 410:
    Listing.Genres("Action","Movies")

#elif mode == 411:
    #Listing.Genres("Animation","Movies")

elif mode == 412:
    Listing.Genres("Classic","Movies")

elif mode == 413:
    Listing.Genres("Comedy","Movies")

elif mode == 414:
    Listing.Genres("Crime","Movies")

elif mode == 415:
    Listing.Genres("Docs","Movies")

elif mode == 416:
    Listing.Genres("Drama","Movies")

elif mode == 417:
    Listing.Genres("Family","Movies")

elif mode == 418:
    Listing.Genres("Fantasy","Movies")

elif mode == 419:
    Listing.Genres("Horror","Movies")

elif mode == 420:
    Listing.Genres("Music","Movies")

elif mode == 421:
    Listing.Genres("Scifi","Movies")

elif mode == 422:
    Listing.Genres("Sports","Movies")

elif mode == 423:
    Listing.Genres("Thriller","Movies")

elif mode == 424:
    Listing.Genres("Western","Movies")

elif mode == 425:
    Listing.Genres("Zombie","Movies")

elif mode == 426:
    Listing.Genres("Anime","Movies")

elif mode == 427:
    Listing.Genres("Mystery","Movies")

#=========================================

elif mode == 510:
    Listing.Genres("Action","Sexy")

#elif mode == 511:
    #Listing.Genres("Animation","Sexy")

elif mode == 512:
    Listing.Genres("Classic","Sexy")

elif mode == 513:
    Listing.Genres("Comedy","Sexy")

elif mode == 514:
    Listing.Genres("Crime","Sexy")

elif mode == 515:
    Listing.Genres("Docs","Sexy")

elif mode == 516:
    Listing.Genres("Drama","Sexy")

elif mode == 517:
    Listing.Genres("Romance","Sexy")

elif mode == 518:
    Listing.Genres("Fantasy","Sexy")

elif mode == 519:
    Listing.Genres("Horror","Sexy")

elif mode == 520:
    Listing.Genres("Music","Sexy")

elif mode == 521:
    Listing.Genres("Scifi","Sexy")

elif mode == 522:
    Listing.Genres("Sports","Sexy")

elif mode == 523:
    Listing.Genres("Thriller","Sexy")

elif mode == 524:
    Listing.Genres("Western","Sexy")

elif mode == 525:
    Listing.Genres("Zombie","Sexy")

elif mode == 526:
    Listing.Genres("Anime","Sexy")

elif mode == 527:
    Listing.Genres("Mystery","Sexy")

#=========================================

elif mode == 801:
		
	#errorMsg="%s" % (url)
	#xbmcgui.Dialog().ok("url", errorMsg)

	Common.getVID(url)

#=========================================

elif mode==None:
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)
