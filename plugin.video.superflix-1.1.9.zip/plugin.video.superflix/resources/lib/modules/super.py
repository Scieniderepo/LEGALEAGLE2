# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.superflix')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

YOUTUBE_CHANNEL_ID_9001 = "" #
YOUTUBE_CHANNEL_ID_9002 = "" #
YOUTUBE_CHANNEL_ID_9003 = "PLBViV1-Hnp9059XCcf-b7ZbQkVi5DJJd2" #Captain America Episodes
YOUTUBE_CHANNEL_ID_9004 = "PL0pdDMSI6cJ7sgWL_CMlA-rAAT4gpdqBU" #Avengers: Earths Mightiest Heroes
YOUTUBE_CHANNEL_ID_9005 = "" #
YOUTUBE_CHANNEL_ID_9006 = "PLDlNWvEmxHt642snFwTBs7M7Mzlziz8_C" #
YOUTUBE_CHANNEL_ID_9007 = "PLaNb7ob8C17ihtq7FwjUo9DOgqc1dVwT1" #
YOUTUBE_CHANNEL_ID_9008 = "PLaNb7ob8C17hjCLZl6hhVAY27MmBk_VmB" #
YOUTUBE_CHANNEL_ID_9009 = "PL5E-2871Km0KplJRTpZn2NFeftnyRBR_A" #
YOUTUBE_CHANNEL_ID_9010 = "PLmTCZd4l3_-LXf-vBtkPhMq_B684sEqpH" #
YOUTUBE_CHANNEL_ID_9011 = "" #
YOUTUBE_CHANNEL_ID_9012 = "PLZyrems8ZnTaB1J7Y9oUDStxeEqgdCMC5" #X-men Animated Series
YOUTUBE_CHANNEL_ID_9013 = "" #
YOUTUBE_CHANNEL_ID_9014 = "" #
YOUTUBE_CHANNEL_ID_9015 = "" #
YOUTUBE_CHANNEL_ID_9016 = "" #
YOUTUBE_CHANNEL_ID_9017 = "PLLhOnau-tupSQX2KHE2C15vPIubyhBhBN" #Spider Woman Episodes
YOUTUBE_CHANNEL_ID_9018 = "" #
YOUTUBE_CHANNEL_ID_9019 = ""
YOUTUBE_CHANNEL_ID_9020 = "PLJNLODMJ7bj95kbMtfRRn5vGo-f-SR_HH" #Iron Man 1994
YOUTUBE_CHANNEL_ID_9021 = "PLJ69ZCjgUw9wuXrfXuscGQsC-bISW1Agv" #Iron Man And Thor
YOUTUBE_CHANNEL_ID_9022 = "PLJdDaTA1sQBONinRImyFJC3x34T6-WM_T" #Iron Man Cartoons
YOUTUBE_CHANNEL_ID_9023 = "" #
YOUTUBE_CHANNEL_ID_9024 = "PLAkrOtpiWdyGmXdXQ2LsqunficPENiBv9" #Fantastic Four Episodes
YOUTUBE_CHANNEL_ID_9025 = "PL5381BE18F8316D72"                 #The Submariner 1960s
YOUTUBE_CHANNEL_ID_9026 = "PL9-4wsTsXmtfwMI6XXZFXI7KnuXJUU21r" #Classic Spiderman And More
YOUTUBE_CHANNEL_ID_9027 = "" #
YOUTUBE_CHANNEL_ID_9028 = "" #
YOUTUBE_CHANNEL_ID_9029 = "" #
YOUTUBE_CHANNEL_ID_9030 = "" #
YOUTUBE_CHANNEL_ID_9031 = "" #
YOUTUBE_CHANNEL_ID_9032 = "" #
YOUTUBE_CHANNEL_ID_9033 = "" #
YOUTUBE_CHANNEL_ID_9034 = "" #
YOUTUBE_CHANNEL_ID_9035 = "" #
YOUTUBE_CHANNEL_ID_9036 = "" #
YOUTUBE_CHANNEL_ID_9037 = "" #
YOUTUBE_CHANNEL_ID_9038 = "" #
YOUTUBE_CHANNEL_ID_9039 = "" #
YOUTUBE_CHANNEL_ID_9040 = "" #
YOUTUBE_CHANNEL_ID_9041 = "" #
YOUTUBE_CHANNEL_ID_9042 = "" #
YOUTUBE_CHANNEL_ID_9043 = "" #
YOUTUBE_CHANNEL_ID_9044 = "" #
YOUTUBE_CHANNEL_ID_9045 = "" #
YOUTUBE_CHANNEL_ID_9046 = "" #
YOUTUBE_CHANNEL_ID_9047 = "" #
YOUTUBE_CHANNEL_ID_9048 = "PLcZkwR3bL1rudUN5dC3kmk-lXFvhVKL0x" #DC Super Hero Girls
YOUTUBE_CHANNEL_ID_9049 = "" #
YOUTUBE_CHANNEL_ID_9050 = "PL5VLQ-btqmnkT5rHaCMevY53h1YMvVwai" #DC Kids Justice League
YOUTUBE_CHANNEL_ID_9051 = "PL9balS1QRN0egPRMn3xF0vayD1lRYUIRp" #Teen Titans Go
YOUTUBE_CHANNEL_ID_9052 = "PLIpMLQ_IpCIfC3FtBqrYyDa-oCDaGY-hW" #Wild C.A.T.s
YOUTUBE_CHANNEL_ID_9053 = "PLZs0gQed9tMQayY8VqN_Pj8KAUe30nLdf" #Batman: Gotham Knight
YOUTUBE_CHANNEL_ID_9054 = "PLJms5sWamFOWc1zy_6KBrw-xtYo8FpICC" #Batman: Telltale Series
YOUTUBE_CHANNEL_ID_9055 = "" #
YOUTUBE_CHANNEL_ID_9056 = "" #
YOUTUBE_CHANNEL_ID_9057 = "PLX0I1A3rnJ55CC4fQ7Evrvq8PhXb62T47" #Mystery Of The Bat-Man
YOUTUBE_CHANNEL_ID_9058 = "PLL7vojAITnsWu1cg0ceNY0iaoxl5d_hWp" #Justice League Of America 1967
YOUTUBE_CHANNEL_ID_9059 = "PL43cESfW-NvHVnsyvsK9LBRGBz8UJw2MH" #DC Filmation 1967-1968
YOUTUBE_CHANNEL_ID_9060 = "PLtDv0k_sYMS3Az8tIi608GD0kRPi0bDU5" #DC Comics: Wonder Woman
YOUTUBE_CHANNEL_ID_9061 = "PLkLimRXN6NKwOybbWpLUuYZfJZxxgLj-D" #Justice League animated s1,s2
YOUTUBE_CHANNEL_ID_9062 = "PLZs0gQed9tMS9BLYfxtyyd7OQlQe1n_-f" #DC Heros 1960s Cartoons
YOUTUBE_CHANNEL_ID_9063 = "PLHclw_SkIUEWK4eahMcZbHMji4Z8JkU2Z" #DCs Filmation 1967
YOUTUBE_CHANNEL_ID_9064 = "PLcrApfnvcfVziLpbjdtWlpJd7E9czrZR3" #DC Super Friends
YOUTUBE_CHANNEL_ID_9065 = "PLcrApfnvcfVx6cBCnVWcbW8wPZZZ6Pcza" #Batman Unlimited
YOUTUBE_CHANNEL_ID_9066 = "PLcrApfnvcfVzhReuqA7CrP9_-K1YWDReb" #Classic DC Cartoons
YOUTUBE_CHANNEL_ID_9067 = "UCpq_3STONuP2fuZUirJuBNA"           #Superman Animated
YOUTUBE_CHANNEL_ID_9068 = "UCJAWEVDvEJe1W299pWuTZUQ"           #Batman Animated Series
YOUTUBE_CHANNEL_ID_9069 = "" #
YOUTUBE_CHANNEL_ID_9070 = "" #
YOUTUBE_CHANNEL_ID_9071 = "" #
YOUTUBE_CHANNEL_ID_9072 = "" #
YOUTUBE_CHANNEL_ID_9073 = "" #
YOUTUBE_CHANNEL_ID_9074 = "" #
YOUTUBE_CHANNEL_ID_9075 = "" #
YOUTUBE_CHANNEL_ID_9076 = "" #
YOUTUBE_CHANNEL_ID_9077 = "" #
YOUTUBE_CHANNEL_ID_9078 = "" #
YOUTUBE_CHANNEL_ID_9079 = "" #
YOUTUBE_CHANNEL_ID_9080 = "PLr6CnVmCtp_Wg2qZoX3b56bbNqy2OkP7F" #Marvel Comics Fan Films
YOUTUBE_CHANNEL_ID_9081 = "PLSLCfdq4O1lNVBtXevSd12fIDEBl8588U" #Best Superhero Fan Films
YOUTUBE_CHANNEL_ID_9082 = "PLLNnOZf56AQJVxD8Pg67pF35jA8k49xB7" #Marvel: More Fan Films
YOUTUBE_CHANNEL_ID_9083 = "PL6624435483FCAF86"                 #Deadpool Ongoing Film Series
YOUTUBE_CHANNEL_ID_9084 = "PLK9wo04PtT1kViHcxaDBuwCcv0tsQOznq" #Best Spiderman Fan Films
YOUTUBE_CHANNEL_ID_9085 = "PLVra6xST2ql3k_W-pLuLrnjq3_lRAw3mq" #Superhero Fan Films
YOUTUBE_CHANNEL_ID_9086 = "PLBKqQIX9AHaNFlLzG6XYfV8WP4WfG-1XQ" #Awesome Spider-Man Fan Films
YOUTUBE_CHANNEL_ID_9087 = "PLAZSCGTToIqB76Juv23NBBq6VSCQENr1N" #Batman Fan Films
YOUTUBE_CHANNEL_ID_9088 = "PLr6CnVmCtp_UMag1XOJQfWbQkqzvuobQk" #DC Comics Fan Films
YOUTUBE_CHANNEL_ID_9089 = "PLr6CnVmCtp_Wmix18gGBAOm1uUuH6_4A6" #Superman Fan Films
YOUTUBE_CHANNEL_ID_9090 = "PLeRc76eufSX2ZtO-mgpLm0EoGmW7bkPcB" #Harley Quinn Fan Films
YOUTUBE_CHANNEL_ID_9091 = "PLIsbD-29t0_7VRaRQwuaW9lWMTzoN7r6h" #More Superhero Fan Films
YOUTUBE_CHANNEL_ID_9092 = "PL0GCFzAAB4vMrFcM1miiQAEtuEb7aW7no" #Mixed Super Fan Films
YOUTUBE_CHANNEL_ID_9093 = "PLm4t14Vqz9NZUrB_0gpdzha3lCqFjoscC" #More DC Fan Films
YOUTUBE_CHANNEL_ID_9094 = "PLKdjhT5d6Y5lYJSDMOvmkmbOUq_GUbSGA" #The Flash Fan Films
YOUTUBE_CHANNEL_ID_9095 = "PLC4097786E84CCCD0"                 #Green Lantern Fan Films
YOUTUBE_CHANNEL_ID_9096 = "" #
YOUTUBE_CHANNEL_ID_9097 = "" #
YOUTUBE_CHANNEL_ID_9098 = "" #
YOUTUBE_CHANNEL_ID_9099 = "" #
YOUTUBE_CHANNEL_ID_9119 = "PLDg7FjaC1Jx9mFfwswQJRf5Be4I3hAlVR" #Inspector Gadget
YOUTUBE_CHANNEL_ID_9120 = "UCUh6BtszC2-ubKiv0hLf6gQ"           #She-Ra Channel
YOUTUBE_CHANNEL_ID_9121 = "HeMan"                              #He Man Channel
YOUTUBE_CHANNEL_ID_9122 = "UCHpsEFbbXOSovRKp5Wvg5aA"           #Bravestar Channel
YOUTUBE_CHANNEL_ID_9123 = "PLGsVaqfVidOwKdxkIkmJhyHWqrynazT78" #Robotboy Compilations
YOUTUBE_CHANNEL_ID_9124 = "PLmprnjY0aArOHlrP-fBs-bXBf0yuHmsxq" #Space Ranger Roger
YOUTUBE_CHANNEL_ID_9125 = "PLP38q3guFLTgdeGLYxjV8qjag7u1cUt74" #Classic Superhero Cartoons
YOUTUBE_CHANNEL_ID_9126 = "" #
YOUTUBE_CHANNEL_ID_9127 = "PLuI7BiC5LyGZnYLDQ1gvCNyHX-nUm-tR-" #The Tick 1994-1996
YOUTUBE_CHANNEL_ID_9128 = "PL6fJmjt84zZgXis8FBu51yi98pL6VGDyE" #Mega Man 1994-1995
YOUTUBE_CHANNEL_ID_9129 = "PLNQ-3rd6vA8k0Ruic25d5B6LwWDUjFcdE" #Buzz Lightyear Series (kids)
YOUTUBE_CHANNEL_ID_9130 = "PLySo2SlSHPSOOGZM3_2Qun52hCaRNYW9y" #Sonic the Hedgehog
YOUTUBE_CHANNEL_ID_9131 = "" #
YOUTUBE_CHANNEL_ID_9132 = "PLLrV5xCMn4kB1hBeqRFuvY994bOs5Jmjw" #Superhero Toons
YOUTUBE_CHANNEL_ID_9133 = "PL6Iw4ELd-WzXfweLJtlt5LtxllTUkZ53P" #Superhero cartoons
YOUTUBE_CHANNEL_ID_9134 = "" #
YOUTUBE_CHANNEL_ID_9135 = "PLZs0gQed9tMT2zhdJ9Fwx5AHlA5gYEaqE" #Mighty Mouse
YOUTUBE_CHANNEL_ID_9136 = "PLF9Ksz48e9pP_uJr94if6ZXoDxmggT9SB" #Mighty Mouse
YOUTUBE_CHANNEL_ID_9137 = "PLwygboCFkeeCed_Q0TthVkHWoFw4m6Y1j" #Superhero Cartoons
YOUTUBE_CHANNEL_ID_9138 = "PLZs0gQed9tMSbCJ9ormlr1jx7Fu692CqR" #Toxic Crusaders
YOUTUBE_CHANNEL_ID_9139 = "" #
YOUTUBE_CHANNEL_ID_9140 = "" #
YOUTUBE_CHANNEL_ID_9141 = "PL_Dj2ayYHVRz1YhLVeJrrxDrHC33SHdFU" #PJ Masks Episodes
YOUTUBE_CHANNEL_ID_9142 = "PL_Dj2ayYHVRwJR3nafjPf9G3UX18KKRAo" #Best Of PJ Masks
YOUTUBE_CHANNEL_ID_9143 = "PL_Dj2ayYHVRw-JRhPZAJ6YfNBM0oGnW6J" #PJ Masks 2018
YOUTUBE_CHANNEL_ID_9144 = "PL_Dj2ayYHVRwAZpNOjPk45YxLmrnPmF1B" #PJ Masks New Video
YOUTUBE_CHANNEL_ID_9145 = "PL_Dj2ayYHVRzsBo9JkrFZleVIIyWejX8r" #PJ Masks Awesome Video
YOUTUBE_CHANNEL_ID_9146 = "PL_Dj2ayYHVRzmuPZJOdxRYHV3Awwaj2rv" #PJ Masks Christmas
YOUTUBE_CHANNEL_ID_9147 = "PL_Dj2ayYHVRxea-7jB4dCxZGNdR2fJFeC" #PJ Masks Halloween
YOUTUBE_CHANNEL_ID_9148 = "" #
YOUTUBE_CHANNEL_ID_9149 = "" #
YOUTUBE_CHANNEL_ID_9150 = "PLuqAhcLGBAaV3Y7NjJmnU7GifaKec8Uyh" #Green Hornet 1940 Serial
YOUTUBE_CHANNEL_ID_9151 = "PLx7nFNCVfZF9ycdm_TR4Xujs8vklREiaX" #Superman-Batman 1945 Serial
YOUTUBE_CHANNEL_ID_9152 = "PLQlo-pRU8xAjzfMg0qR8gkcbrFROlL9kh" #Superman Cartoon Serial 1942
YOUTUBE_CHANNEL_ID_9153 = "PLgShfJ6QB549W-47UdHC3WLsZ2rB6nPOi" #Captain America 1944
YOUTUBE_CHANNEL_ID_9154 = "PL0y_pNxamlHSsWG89pnfuFF5LE_DQgHNb" #Adventures Of Captain Marvel
YOUTUBE_CHANNEL_ID_9155 = "" #
YOUTUBE_CHANNEL_ID_9156 = "" #
YOUTUBE_CHANNEL_ID_9157 = "PLX0I1A3rnJ55CC4fQ7Evrvq8PhXb62T47" #Mystery Of The Bat-Man
YOUTUBE_CHANNEL_ID_9158 = "" #
YOUTUBE_CHANNEL_ID_9159 = "PLHXdEb-At4D8I6tTHbFXpDHeJnBGV0OB2" #Commando Cody Sky Marshall 1953
YOUTUBE_CHANNEL_ID_9160 = "PLpagE74pQ4IXQh2NWzP1xh8H8u0bTUYJf" #The Phantom 1943 Serial
YOUTUBE_CHANNEL_ID_9161 = "" #
YOUTUBE_CHANNEL_ID_9162 = "" #
YOUTUBE_CHANNEL_ID_9163 = "" #
YOUTUBE_CHANNEL_ID_9164 = "" #
YOUTUBE_CHANNEL_ID_9165 = "PL5Mr4L33ibXqySs7ehQLZr_GsIWYOTxoa" #Best Comic Book Documentaries
YOUTUBE_CHANNEL_ID_9166 = "PL5afmekC_ltrZxXP654kPzzXGtlO6IdXD" #Superhero Comic Docs
YOUTUBE_CHANNEL_ID_9167 = "PLBmJJYzWGHFGzfs57JPrFSqKtE6WM4Qo0" #Comic Book Documentaries
YOUTUBE_CHANNEL_ID_9168 = "" 
YOUTUBE_CHANNEL_ID_9169 = "PLF94E6BBC4B9447DE" #
YOUTUBE_CHANNEL_ID_9170 = "PLwCdjUicFeE-GfU93sKxS0qtvnGooPa4U" #Documentary: Comics
YOUTUBE_CHANNEL_ID_9171 = "PLCXUkTSTu9wntaCnPmMk2P3LlfdvkpzOr" #
YOUTUBE_CHANNEL_ID_9172 = "PL2J6kLWeTPwUQbrSSkJAp7rSuizVPqcUI" #Documentary: Comic Artists
YOUTUBE_CHANNEL_ID_9173 = "PLFu-YqdFUEU8pv4Fe2DSh_yA8lWzwHO6X" #Stan Lee: Super Humans
YOUTUBE_CHANNEL_ID_9174 = "PL0IruygMlugBgupQ18pxD73yXb4_Jc-zh" #Marvel Comics Explained
YOUTUBE_CHANNEL_ID_9175 = "" #
YOUTUBE_CHANNEL_ID_9176 = "" #
YOUTUBE_CHANNEL_ID_9177 = "" #
YOUTUBE_CHANNEL_ID_9178 = "" #
YOUTUBE_CHANNEL_ID_9179 = "" #	
YOUTUBE_CHANNEL_ID_9180 = "UCnILoK3xuBuuEpIsMXI5X5Q" #Classic Marvel
YOUTUBE_CHANNEL_ID_9181 = "" #
YOUTUBE_CHANNEL_ID_9182 = "UCB8IDKgihlho9UPXSOb0ykw" #Avengers Movies
YOUTUBE_CHANNEL_ID_9183 = "" #
YOUTUBE_CHANNEL_ID_9184 = "" #
YOUTUBE_CHANNEL_ID_9185 = "" #
YOUTUBE_CHANNEL_ID_9186 = "" #
YOUTUBE_CHANNEL_ID_9187 = "" #
YOUTUBE_CHANNEL_ID_9188 = "" #
YOUTUBE_CHANNEL_ID_9189 = "PLj2-UyrquQIkNDhgO8ZP8YjoL6HbksSVy" #CG Super Movies
YOUTUBE_CHANNEL_ID_9190 = "" #
YOUTUBE_CHANNEL_ID_9191 = "" #
YOUTUBE_CHANNEL_ID_9192 = "" #
YOUTUBE_CHANNEL_ID_9193 = "" #
YOUTUBE_CHANNEL_ID_9194 = "" #
YOUTUBE_CHANNEL_ID_9195 = "" #
YOUTUBE_CHANNEL_ID_9196 = "" #
YOUTUBE_CHANNEL_ID_9197 = "" #
YOUTUBE_CHANNEL_ID_9198 = "" #
YOUTUBE_CHANNEL_ID_9199 = "" #
YOUTUBE_CHANNEL_ID_9200 = "UCRdVJ9XqHCb6BqApCIO_TYg" #Channel: Super Hero Girls 
YOUTUBE_CHANNEL_ID_9201 = "UCyu8StPfZWapR6rfW_JgqcA" #Channel: DC Kids
YOUTUBE_CHANNEL_ID_9202 = "" #
YOUTUBE_CHANNEL_ID_9203 = "UCxwitsUVNzwS5XBSC5UQV8Q" #Channel: Marvel HQ
YOUTUBE_CHANNEL_ID_9204 = "UC0CelqHTkd3P7xgWEtB8ywQ" #Channel: Marvel Avengers
YOUTUBE_CHANNEL_ID_9205 = "UCsHIrJxzA_7_uenC0pqY1OQ" #Channel: Marvel Hub
YOUTUBE_CHANNEL_ID_9206 = "UC-b-PiM8vHkGGk33I3qaviA" #Channel: Marvel Universe
YOUTUBE_CHANNEL_ID_9207 = "UCJ078ukSvhejqsVKyM8TH_A" #Channel: DC Universe
YOUTUBE_CHANNEL_ID_9208 = "" #
YOUTUBE_CHANNEL_ID_9209 = "" #
YOUTUBE_CHANNEL_ID_9210 = "marvelonlineru" #USER TEST MARVEL HEROS
YOUTUBE_CHANNEL_ID_9211 = "" #
YOUTUBE_CHANNEL_ID_9212 = "" #
YOUTUBE_CHANNEL_ID_9213 = "" #
YOUTUBE_CHANNEL_ID_9214 = "" #
YOUTUBE_CHANNEL_ID_9215 = "" #
YOUTUBE_CHANNEL_ID_9216 = "" #
YOUTUBE_CHANNEL_ID_9217 = "" #
YOUTUBE_CHANNEL_ID_9218 = "" #
YOUTUBE_CHANNEL_ID_9219 = "" #
YOUTUBE_CHANNEL_ID_9220 = "" #

##@route(mode='marvel')
def Marvel():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Captain America Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9003+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Avengers: Earths Mightiest Heroes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9004+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]X-men Animated Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9012+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Iron Man 1994[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9020+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Iron Man And Thor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9021+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Iron Man Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9022+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fantastic Four Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9024+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Submariner 1960s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9025+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Spiderman And Captain America[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9026+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Avengers Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9182+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Marvel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9180+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
##@route(mode='dc')
def DC():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir(
		name="[COLOR white][B]DC Super Friends[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9064+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman Unlimited[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9065+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic DC Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9066+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superman Animated Series[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9067+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman Animated Series[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9068+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Super Hero Girls[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9048+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Justice League Animated S1,S2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9061+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Kids Justice League[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9050+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Teen Titans Go[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9051+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Wild C.A.T.s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9052+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]DCs Filmation 1967[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9063+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Heros 1960s Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9062+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Comics: Wonder Woman[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9060+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Filmation 1967-1968[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9059+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman: Gotham Knight[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9053+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman: Telltale Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9054+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Justice League Of America 1967[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9058+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
##@route(mode='more_supers')
def More_supers():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Avengers: Earths Mightiest Heros[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9004+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Avengers Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9182+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Spider Woman Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9017+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Marvel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9180+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Justice League animated s1,s2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9061+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Kids Justice League[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9050+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
#@route(mode='super_channels')
def Super_channels():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]Channel: Superman Animated[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9067+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Channel: Batman Animated[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9068+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]She-Ra Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9120+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]He Man Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_9121+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Bravestar Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9122+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Channel: Super Hero Girls[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9200+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: DC Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9201+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: Marvel HQ[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9203+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: Marvel Avengers[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9204+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: Marvel Hub[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9205+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: Marvel Universe[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9206+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: DC Universe[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9207+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: Avengers Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9182+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel: Marvel Heros[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_9210+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
#@route(mode='fan_films')
def Fan_films():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Marvel Comics Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9080+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Superhero Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9081+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Marvel: More Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9082+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Deadpool Ongoing Film Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9083+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Spiderman Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9084+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9085+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Awesome Spider-Man Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9086+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Batman Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9087+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DC Comics Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9088+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superman Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9089+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Harley Quinn Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9090+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Superhero Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9091+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mixed Super Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9092+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More DC Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9093+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Flash Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9094+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Green Lantern Fan Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9095+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
#@route(mode='serial')
def Serial():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Superman Cartoon Serial 1942[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9152+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Adventures Of Captain Marvel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9154+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superman-Batman Serial 1945[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9151+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery Of The Bat-Man[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9157+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Captain America 1944[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9153+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Phantom 1943 Serial[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9160+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Commando Cody Sky Marshall 1953[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9159+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Green Hornet 1940 Serial[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9150+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
#@route(mode='pj_masks')
def PJ_masks():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]PJ Masks Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9141+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Best Of PJ Masks[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9142+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]PJ Masks 2018[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9143+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]PJ Masks New Video[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9144+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]PJ Masks Christmas[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9146+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PJ Masks Halloween[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9147+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PJ Masks Awesome Video[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9145+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)
	
#@route(mode='misc')
def Misc():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]Inspector Gadget[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9119+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]She-Ra Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9120+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]He Man Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_9121+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Bravestar Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_9122+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Robotboy Compilations[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9123+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Space Ranger Roger[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9124+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Classic Superhero Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9125+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Toxic Crusaders[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9138+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Superhero Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9137+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]The Tick 1994-1996[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9127+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mega Man 1994-1995[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9128+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Buzz Lightyear Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9129+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sonic the Hedgehog[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9130+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9132+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]More Superhero Toons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9133+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Mighty Mouse Cartoons[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9135+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Mighty Mouse[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9136+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)

#@route(mode='superdocs')
def Superdocs():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', mediapath+'super.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Best Comic Book Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9165+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Superhero Comic Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9166+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Comic Book Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9167+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Comic Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9169+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Documentary: Comics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9170+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Comic Book: Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9171+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Documentary: Comic Artists[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9172+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Stan Lee: Super Humans[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9173+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Marvel Comics Explained[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9174+"/", folder=True,
		icon=mediapath+"super.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'super.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
