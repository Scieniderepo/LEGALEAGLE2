# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.kidzclub import *
from resources.lib.modules.common import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.kidzclub')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

def Main():

	add_link_info('[B][COLORlime]== Kidz Club ==[/COLOR][/B]', mediapath+'kidzclub.png', fanart)

	addDirMain('[COLOR white][B]Kids Channels[/B][/COLOR]',BASE,695,mediapath+'kidzclub_channels.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kids Network Channels[/B][/COLOR]',BASE,685,mediapath+'kidzclub_network.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Comedy Shows, Movies[/B][/COLOR]',BASE,63,mediapath+'kidzclub_comedy.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kids Documentaries[/B][/COLOR]',BASE,65,mediapath+'kidzclub_docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family Movies, Shows[/B][/COLOR]',BASE,67,mediapath+'kidzclub_family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Heroes For Kids[/B][/COLOR]',BASE,68,mediapath+'kidzclub_heroes.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Kids Music Video[/B][/COLOR]',BASE,69,mediapath+'kidzclub_music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Shows For Toddlers[/B][/COLOR]',BASE,64,mediapath+'kidzclub_toddlers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animation Movies, Shorts[/B][/COLOR]',BASE,61,mediapath+'kidzclub_animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Cartoons For Kids[/B][/COLOR]',BASE,62,mediapath+'kidzclub_cartoons.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Western Movies, Shows[/B][/COLOR]',BASE,66,mediapath+'kidzclub_western.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'kidzclub.png', fanart)

		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

#====================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===== KIDZ CLUB =====
		
if mode == 61:
	Kidzclub_Animation()		
	
elif mode == 62:
	Kidzclub_Cartoons()

elif mode == 63:
	Kidzclub_Comedy()
	
elif mode == 64:
	Kidzclub_Toddlers()

elif mode == 65:
	Kidzclub_Docs()
	
elif mode == 66:
	Kidzclub_Western()

elif mode == 67:
	Kidzclub_Family()
	
elif mode == 68:
	Kidzclub_Heroes()

elif mode == 69:
	Kidzclub_Music()

elif mode == 685:
	Kidzclub_Networks()

elif mode == 695:
	Kidzclub_Channels()

#elif mode in kidzclublib.Common.get_genres():
#    Channels.genre_list(mode)

elif mode is None:
	Main()
	
else:
    Channels.get_channel(mode)
		
xbmcplugin.endOfDirectory(plugin_handle)
