"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from common import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.channels')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/media/'))

class ChannelsSingles:

    @staticmethod
    def section_list():
        #Generate Section List
        for section in sorted(moviechannelslib.Common.get_sections(), reverse=False):
            moviechannelslib.Common.add_section(section, moviechannelslib.Common.get_channels_logo(section, "section"), fanart)

    @staticmethod
    def genres_list():
        # Generate Genre List
        for genre in sorted(moviechannelslib.Common.get_singles_genres(), reverse=False):
            moviechannelslib.Common.add_section(genre, moviechannelslib.Common.get_channels_logo(genre, "genre"), fanart)

    @staticmethod
    def genre_list(genre):
        # Generate Channel List within given genre
        for channel in sorted(moviechannelslib.Common.get_singles(), reverse=False):
            if genre in channel["type"]:
                moviechannelslib.Common.add_channel(channel["name"], moviechannelslib.Common.get_channels_logo(channel["name"]), fanart)

    @staticmethod
    def singles_list():
        # Generate video List
        for channel in sorted(moviechannelslib.Common.get_singles(), reverse=False):
            moviechannelslib.Common.add_channel(channel["name"], moviechannelslib.Common.get_channels_logo(channel["name"]), fanart)

    @staticmethod
    def get_singles(mode):
        moviechannelslib.Common.get_stream_and_play(mode)

class Content:

    @staticmethod
    def section_list():
        #Generate Section List
        for section in sorted(moviechannelslib.Common.get_sections(), reverse=False):
            moviechannelslib.Common.add_section(section, moviechannelslib.Common.get_logo(section, "section"), fanart)

    @staticmethod
    def genres_list():
        # Generate Genre List
        for genre in sorted(moviechannelslib.Common.get_content_genres(), reverse=False):
            moviechannelslib.Common.add_section(genre, moviechannelslib.Common.get_logo(genre, "genre"), fanart)

    @staticmethod
    def genre_list(genre):
        # Generate Channel List within given genre
        for channel in sorted(moviechannelslib.Common.get_content(), reverse=False):
            if genre in channel["type"]:
                moviechannelslib.Common.add_channel(channel["name"], moviechannelslib.Common.get_logo(channel["name"]), fanart)

    @staticmethod
    def content_list():
        # Generate Channel List
        for channel in sorted(moviechannelslib.Common.get_content(), reverse=False):
            moviechannelslib.Common.add_channel(channel["name"], moviechannelslib.Common.get_logo(channel["name"]), fanart)

    @staticmethod
    def get_content(mode):
        moviechannelslib.Common.get_stream_and_play(mode)

class Channels:

    @staticmethod
    def section_list():
        #Generate Section List
        for section in sorted(moviechannelslib.Common.get_sections(), reverse=False):
            moviechannelslib.Common.add_section(section, moviechannelslib.Common.get_logo(section, "section"), fanart)

    @staticmethod
    def genres_list():
        # Generate Genre List
        for genre in sorted(moviechannelslib.Common.get_channels_genres(), reverse=False):
            moviechannelslib.Common.add_section(genre, moviechannelslib.Common.get_logo(genre, "genre"), fanart)

    @staticmethod
    def genre_list(genre):
        # Generate Channel List within given genre
        for channel in sorted(moviechannelslib.Common.get_channels(), reverse=False):
            if genre in channel["type"]:
                moviechannelslib.Common.add_channel(channel["name"], moviechannelslib.Common.get_logo(channel["name"]), fanart)

    @staticmethod
    def channel_list():
        # Generate Channel List
        for channel in sorted(moviechannelslib.Common.get_channels(), reverse=False):
            moviechannelslib.Common.add_channel(channel["name"], moviechannelslib.Common.get_logo(channel["name"]), fanart)

    @staticmethod
    def get_channel(mode):
        moviechannelslib.Common.get_stream_and_play(mode)

