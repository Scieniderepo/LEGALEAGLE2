plugin.video.cbcnews
================

Kodi Video Addon for CBC News - for use in Canada only
For Kodi matrix and later releases

Version 4.0.0 Initial Release for Matrix