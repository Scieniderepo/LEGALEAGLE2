plugin.video.buzzr
================

Kodi Video Addon for BUZZR TV Live
For Kodi Matrix and above releases

Version 4.0.0 Initial Release for Matrix

