NHKラジオ、民放ラジオ（radiko.jp）ほかが提供するインターネットラジオ放送局を聴いたり、番組をファイル保存できるKodiアドオンです。
Windows、macOSで動作します。Linuxやその他のOSでの動作は未検証です。
詳しくは http://kodiful.com をご覧ください。

以下を参考にしました。
http://xbmc.inpane.com/main/heavy_user/script_radiko.php
@xbmc_nowさん、ありがとうございます。
