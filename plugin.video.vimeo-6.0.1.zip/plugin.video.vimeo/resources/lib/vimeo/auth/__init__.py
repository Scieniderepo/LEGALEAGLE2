#! /usr/bin/env python
# encoding: utf-8


class GrantFailed(Exception):
    """Grant permission failed."""

    pass
