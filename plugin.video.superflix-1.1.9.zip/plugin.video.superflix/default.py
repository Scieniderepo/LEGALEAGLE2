# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.super import *
from resources.lib.modules.common import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.superflix')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

def Main():

	add_link_info('[B][COLORorange]== Super Flix ==[/COLOR][/B]', icon, fanart)
	addDirMain('[COLOR white][B]Marvel Comics[/B][/COLOR]',BASE,81,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]DC Comics[/B][/COLOR]',BASE,82,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]More Supers[/B][/COLOR]',BASE,83,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Channels[/B][/COLOR]',BASE,89,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Other Superheroes[/B][/COLOR]',BASE,92,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Documentary[/B][/COLOR]',BASE,90,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Super Fan Films[/B][/COLOR]',BASE,84,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Super Serials[/B][/COLOR]',BASE,87,mediapath+'super.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]PJ Masks Cartoons[/B][/COLOR]',BASE,91,mediapath+'super.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

#==========================================================================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#=====Super======
		
if mode == 81:
	Marvel()		
		
elif mode == 82:
	DC()

elif mode == 83:
	More_supers()
	
elif mode == 84:
	Fan_films()

elif mode == 85:
	Spider_man()

elif mode == 86:
	Justice_league()

elif mode == 87:
	Serial()
	
elif mode == 88:
	Super_movies()

elif mode == 89:
	Super_channels()

elif mode == 90:
	Superdocs()

elif mode == 91:
	PJ_masks()

elif mode == 92:
	Misc()

elif mode is None:
	Main()
	
else:
    Main()
		
xbmcplugin.endOfDirectory(plugin_handle)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
