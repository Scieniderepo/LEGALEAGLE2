# The *hd-trailers.net (reloaded)* Addon

This is the repository for the *Kodi hd-trailers.net (reloaded) Addon*.
Insprired by the famous *HD-Trailers.net* Addon by Tristan Fischer for non 
Kodi-Matrix.


[Kodi](https://kodi.tv/) is a famous media center software. This
plugin enables you to access video content from
[hd-trailers.net](http://www.hd-trailers.net) from within Kodi.


