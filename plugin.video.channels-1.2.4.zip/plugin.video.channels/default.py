# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

try:
    # Python 3
    from urllib.parse import unquote_plus, quote_plus
except ImportError:
    # Python 2
    from urllib import unquote_plus, quote_plus

from resources.lib.modules.moviechannels import *
from resources.lib.modules.common import *

params = get_params()
mode = None

#===============================================================================

selfAddon = xbmcaddon.Addon(id=addon_id)

try:
    datapath= xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
except:
    datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.channels')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

try:
    fanart = xbmcvfs.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmcvfs.translatePath(os.path.join(home, 'icon.png'))
except:
    fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmc.translatePath(os.path.join(home, 'icon.png'))

mediapath = 'http://j1wizard.net/media/'

#===============================================================================

def Main():

	add_link_info('[B][COLORorange]== Channels ==[/COLOR][/B]', mediapath+'channels.png', fanart)
	addDirMain('[COLOR white][B]Live Channels[/B][/COLOR]',BASE,120,mediapath+'channels-live.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Horror Channels[/B][/COLOR]',BASE,110,mediapath+'channels-horror.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sci-fi Channels[/B][/COLOR]',BASE,111,mediapath+'channels-scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family Channels[/B][/COLOR]',BASE,118,mediapath+'channels-family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Anime Channels[/B][/COLOR]',BASE,114,mediapath+'channels-anime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports Channels[/B][/COLOR]',BASE,117,mediapath+'channels-sports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Wrestling Channels[/B][/COLOR]',BASE,122,mediapath+'channels-wrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animation Channels[/B][/COLOR]',BASE,119,mediapath+'channels-animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary Channels[/B][/COLOR]',BASE,115,mediapath+'channels-docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Movie Channels[/B][/COLOR]',BASE,116,mediapath+'channels-classic.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Mixed Movie Channels[/B][/COLOR]',BASE,113,mediapath+'channels-mixed.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Music Channels[/B][/COLOR]',BASE,121,mediapath+'channels-music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]By Year Playlists[/B][/COLOR]',BASE,112,mediapath+'channels-years.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

def play_videoID(id):
		
    errorMsg="%s" % (id)
    xbmcgui.Dialog().ok("id", errorMsg)

    #xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=<VIDEO-ID>)')
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=%s)') % (id)
    return

#==========================================================================================================
		
params=get_params()
url=None
name=None
iconimage=None
mode=None
description=None

#======================================================

try:
        url=unquote_plus(params["url"])
except:
        pass
try:
        name=unquote_plus(params["name"])
except:
        pass
try:
        mode = unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#======================================================

if mode == 110:
	HorrorChannel()
		
elif mode == 111:
	ScifiChannel()		
		
elif mode == 112:
	Playlists()

elif mode == 113:
	MixedChannel()
	
elif mode == 114:
	AnimeChannel()

elif mode == 115:
	DocumentaryChannel()

elif mode == 116:
	ClassicChannel()

elif mode == 117:
	SportsChannel()
	
elif mode == 118:
	FamilyChannel()

elif mode == 119:
	AnimationChannel()

elif mode == 120:
	LiveChannel()

elif mode == 121:
	MusicChannel()

elif mode == 122:
	WrestlingChannel()

elif mode is None:
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
