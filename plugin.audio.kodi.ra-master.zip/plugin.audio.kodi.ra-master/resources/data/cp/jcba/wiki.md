|地域|放送局|
|:---|:---|
|北海道|[FMはな](http://fmhana.jp)|
|北海道|[エフエムもえる](http://www.moeru.fm/)|
|北海道|[Airてっし](http://www.nayoro.fm/)|
|青森県|[FM AZUR](http://www.fmazur.jp/)|
|青森県|[アップルウェーブ](http://www.applewave.co.jp/)|
|岩手県|[FMONE](http://fm-one.net/)|
|宮城県|[エフエムいわぬま](http://www.fm779.com/)|
|宮城県|[H＠！FM](http://hat-fm.net/)|
|山形県|[ラジオ モンスター](http://www.fm762.co.jp/)|
|山形県|[エフエムNCV](http://fm834.jp/)|
|山形県|[えふえむい～じゃんおらんだらじお](http://oranda-radio.jp/)|
|山形県|[ハーバーラジオ](http://www.sakatafm.com/)|
|福島県|[ウルトラFM](http://ultrafm868.jp/)|
|福島県|[FMポコ](http://www.fm-poco.co.jp/)|
|福島県|[エフエムきたかた](http://www.fm-kitakata.co.jp/)|
|茨城県|[FMだいご](http://www.town.daigo.ibaraki.jp/page/page000779.html)|
|茨城県|[FMかしま](http://www.767fm.com/)|
|群馬県|[ラジオ高崎](http://www.takasaki.fm/)|
|群馬県|[エフエム太郎](http://www.fmtaro.co.jp/)|
|群馬県|[FM OZE](http://www.fm-oze.co.jp/)|
|群馬県|[ラヂオななみ](http://www.fm773.co.jp/)|
|埼玉県|[FMチャッピー](http://www.fmchappy.jp/)|
|埼玉県|[発するＦＭ](http://fm840.com/)|
|千葉県|[市川うららＦＭ(I&amp;U-LaLaFM)](http://www.fmu.co.jp/)|
|千葉県|[かずさエフエム](http://www.kazusafm.net/)|
|千葉県|[ラジオ成田](http://narita.fm/)|
|千葉県|[ふくろうFM](http://296.fm/)|
|東京都|[FMえどがわ](http://www.fm843.co.jp/)|
|東京都|[むさしのFM](http://www.musashino-fm.co.jp/)|
|東京都|[FMしながわ](https://www.fm-shinagawa.co.jp/)|
|神奈川県|[FMブルー湘南](http://www.yokosukafm.com/)|
|神奈川県|[鎌倉FM](http://www.kamakurafm.co.jp/)|
|神奈川県|[FM湘南ナパサ](http://www.fmshonan783.co.jp/)|
|神奈川県|[FMおだわら](http://fm-odawara.com/)|
|神奈川県|[湘南マジックウェイブ](http://fm-smw.jp/)|
|神奈川県|[FMやまと](http://www.fmyamato.co.jp/)|
|神奈川県|[レディオ湘南](http://www.radioshonan.co.jp/index.php)|
|神奈川県|[FMサルース](http://www.fm-salus.jp/index.php)|
|山梨県|[エフエム甲府](http://www.fm-kofu.co.jp/)|
|山梨県|[FMふじやま](http://fujiyama776.jp/)|
|山梨県|[エフエム　ふじごこ](http://www.fm2255.jp/)|
|山梨県|[ＦＭ八ヶ岳](http://www.yatsugatake.ne.jp/)|
|新潟県|[ラジオチャット・ＦＭにいつ](http://www.chat761.com/index.html)|
|新潟県|[FMうおぬま](http://www.fm-u814.sakura.ne.jp/)|
|新潟県|[エフエムながおか](http://www.fmnagaoka.com/)|
|新潟県|[エフエムしばた](http://www.agatt769.co.jp/)|
|新潟県|[FM KENTO](http://www.fmkento.com/)|
|新潟県|[ＦＭゆきぐに](http://www.fm762.jp/)|
|新潟県|[FM-J エフエム上越](http://www.fmj761.com/)|
|長野県|[LCV FM](http://lcvfm769.jp/)|
|長野県|[FM軽井沢](http://www.fm-karuizawa.co.jp/)|
|岐阜県|[FMPiPi](http://www.fmpipi.co.jp/)|
|岐阜県|[FMわっち](http://www.fm-watch.jp/)|
|岐阜県|[Hits FM](http://www.hidanet.ne.jp/~hitsfm/)|
|静岡県|[FM Haro！](http://www.fmharo.co.jp/)|
|静岡県|[FM IS](http://fmis.jp/)|
|静岡県|[g-sky76.5](http://www.gsky765.jp/)|
|静岡県|[富士山GOGOFM](http://www.863.fm/)|
|静岡県|[ボイスキュー](http://777fm.com/)|
|静岡県|[マリンパル](http://www.mrn-pal.com/)|
|静岡県|[FM-Hi！](http://www.fmhi.co.jp/)|
|静岡県|[Radio-f](http://radio-f.jp/index.html)|
|静岡県|[COAST－FM76.7MHｚ](http://www.coast-fm.com/)|
|静岡県|[エフエムなぎさステーション](https://www.fmito.com/)|
|愛知県|[エフエム　ななみ](http://www.clovernet.co.jp/nanami/)|
|愛知県|[United North](http://842fm.jp/)|
|愛知県|[RADIO SANQ](http://845.fm/)|
|愛知県|[i-wave](http://iwave765.com/)|
|三重県|[いなBee](http://fm861.com/)|
|富山県|[富山シティエフエム株式会社](http://www.city-fm.co.jp/)|
|富山県|[エフエムとなみ](http://www.fmtonami.jp/)|
|富山県|[ラジオたかおか](http://www.radiotakaoka.co.jp/)|
|石川県|[ラジオこまつ](http://www.radio-komatsu-new.com/)|
|石川県|[ラジオななお](http://www.radionanao.co.jp/)|
|石川県|[ラジオかなざわ](http://www.radiokanazawa.co.jp/)|
|滋賀県|[えふえむ草津](http://www.fm785.jp/)|
|京都府|[FMいかる](http://www.fmikaru.jp/)|
|京都府|[FMうじ](https://www.fmuji.com/)|
|京都府|[FMまいづる](http://775maizuru.jp)|
|京都府|[FM845](http://www.fm-845.com/)|
|大阪府|[FM千里](http://www.senri-fm.jp/)|
|大阪府|[FMちゃお](http://792.jp/)|
|大阪府|[ウメダFM Be Happy!789](http://www.be-happy789.com/)|
|大阪府|[FM-HANAKO 82.4MHz](http://fmhanako.jp/)|
|大阪府|[タッキー816みのおエフエム](http://fm.minoh.net/)|
|兵庫県|[エフエムいたみ](http://www.itami.fm/)|
|兵庫県|[ハミングFM宝塚](http://835.jp/)|
|兵庫県|[さくらFM](http://sakura-fm.co.jp/)|
|兵庫県|[エフエムみっきぃ](http://www.fm-miki.jp/)|
|兵庫県|[805たんば](http://805.tanba.info/)|
|奈良県|[なら どっと FM](http://narafm.jp/)|
|奈良県|[エフエムハイホー](http://www.fm814.co.jp/)|
|奈良県|[FM五條](http://www.shousuien.or.jp/fm_gojo/)|
|和歌山県|[バナナエフエム](http://877.fm/)|
|和歌山県|[FM TANABE](https://www.fm885.jp/index.php)|
|和歌山県|[FMはしもと](http://816.fm/)|
|和歌山県|[FMビーチステーション](https://www.fm764.com/)|
|岡山県|[レディオ モモ](http://www.fm790.co.jp/)|
|岡山県|[エフエムくらしき](http://www.fmkurashiki.com/)|
|広島県|[FMふくやま](http://fm777.co.jp/pc/index.html)|
|広島県|[エフエムおのみち](http://www.fmo.co.jp/)|
|広島県|[ＦＭちゅーピー](http://chupea.fm/)|
|広島県|[FMはつかいち](http://www.761.jp/)|
|広島県|[FM東広島](http://fmhigashi.jp/)|
|広島県|[FOR　LIFE　RADIO](https://www.fm-mihara.jp/index.html)|
|山口県|[COME ON ! FM](http://www.c-fm.co.jp/index.php)|
|山口県|[しゅうなんFM](http://www.fms784.co.jp/index.php)|
|鳥取県|[RADIO BIRD](http://www.radiobird.net/)|
|愛媛県|[FMラヂオバリバリ](http://www.baribari789.com/)|
|愛媛県|[FMがいや](http://www.gaiya769.jp/)|
|愛媛県|[Hello! NEW 新居浜 FM](http://www.heartnetwork.jp/)|
|福岡県|[DreamsFM](http://www.dreamsfm.co.jp/)|
|福岡県|[FM八女](http://www.fmyame.jp/)|
|佐賀県|[FMからつ](http://www.fmkaratsu.com/)|
|熊本県|[Kappa　FM](http://www.kappafm.com/)|
|熊本県|[FM791](http://fm791.jp/)|
|大分県|[ゆふいんラヂオ局](http://874.fm/)|
|大分県|[NOASFM](http://789.fm/)|