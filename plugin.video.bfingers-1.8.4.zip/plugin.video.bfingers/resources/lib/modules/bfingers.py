# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
#artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.bfingers')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

#==================================================================================

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

YOUTUBE_CHANNEL_ID_1 = "PLc9pOkgwR7R-6j_zWe9SQoZ0Ys9a572XR" #Mystery dos
YOUTUBE_CHANNEL_ID_2 = "PLJloLxwk_dPWKVNFTjajasPVIA-m1SP_r" #Mystery docs
YOUTUBE_CHANNEL_ID_3 = "PLcJSkbOhx_uiEaWF-zicqw3ri3J2QwY3i" #mystery docs
YOUTUBE_CHANNEL_ID_4 = "PLFpHQFR1whr9tedK5KP_igREFo8gwiE_6" #History's Mysteries
YOUTUBE_CHANNEL_ID_5 = "PLpf-o-gGms2AzvlUFaIulsrTZeuyL-6KD" #Mysterious Universe
YOUTUBE_CHANNEL_ID_6 = "PLDlNWvEmxHt642snFwTBs7M7Mzlziz8_C" #mystery docs ?
YOUTUBE_CHANNEL_ID_7 = "PLaNb7ob8C17ihtq7FwjUo9DOgqc1dVwT1" #mystery Bigfoot DELETES
YOUTUBE_CHANNEL_ID_8 = "PLaNb7ob8C17hjCLZl6hhVAY27MmBk_VmB" #mystery YETI
YOUTUBE_CHANNEL_ID_9 = "PL5E-2871Km0KplJRTpZn2NFeftnyRBR_A" #Mystery Weird or What
YOUTUBE_CHANNEL_ID_10 = "PLmTCZd4l3_-LXf-vBtkPhMq_B684sEqpH" #Mystery ghost ships and planes
YOUTUBE_CHANNEL_ID_11 = "" #
YOUTUBE_CHANNEL_ID_12 = "PLqrLEr7tAISpJ9N_xeCB0IslQDB-o_XNN"
YOUTUBE_CHANNEL_ID_13 = "PLX9_I-EOJPdGFAVAwQj4J7hg8q3m4AW5x" #Classic War Movies
YOUTUBE_CHANNEL_ID_14 = ""           #
YOUTUBE_CHANNEL_ID_15 = "PLhNKDzMMjN8w9AloWcE7Z6ulQibM9A7Tm" #classic Mystery Movies
YOUTUBE_CHANNEL_ID_16 = "" #
YOUTUBE_CHANNEL_ID_17 = "" #
YOUTUBE_CHANNEL_ID_18 = "PLSeZ6qt37vqyLGXbHeS4Ko4tfZ4qsT1ZN" #Classic Horror ***
YOUTUBE_CHANNEL_ID_19 = "FilmNoirTV"                         #Timeless Film-Noir
YOUTUBE_CHANNEL_ID_20 = "PLqrLEr7tAISpfHW7NcjXhY-fX66zI2fhH"
YOUTUBE_CHANNEL_ID_21 = "PLqrLEr7tAISpefkUZHIKYhzqk-QZ6ArJQ"
YOUTUBE_CHANNEL_ID_22 = "PLqrLEr7tAISqiV5cqxhRvEMgR9Y4Q-apy" #comedy
YOUTUBE_CHANNEL_ID_23 = "PL-kg-GL4FKRTYe2CwXTl12ffpiJJTEgSy" #
YOUTUBE_CHANNEL_ID_24 = "PLi4lYGGXHIkODAkKFIXtLZpAjMptl-xSl" #docs
YOUTUBE_CHANNEL_ID_25 = "PLLY_ynX8paGH3D_04pyqibRdEyZxAELf_" #26-horror
YOUTUBE_CHANNEL_ID_26 = "" #
YOUTUBE_CHANNEL_ID_27 = "PLeSK8oZavDZksbefTHmqNde2-mTfudNFQ" #scifi
YOUTUBE_CHANNEL_ID_28 = "PLU-EAetueZUSl2zwzjcefqC2zUaFxVrc1" #horror 267
YOUTUBE_CHANNEL_ID_29 = "" #
YOUTUBE_CHANNEL_ID_30 = "PLMos4PviivCwyf2CZfPR8r9xR3Gegwwph" #horror scifi mix test deletes
YOUTUBE_CHANNEL_ID_31 = "PLsrovtzkHBQWc6pW5PbLKj5ejeidJGMD_" #cheesy sci-fi
YOUTUBE_CHANNEL_ID_32 = "PLSeZ6qt37vqyLGXbHeS4Ko4tfZ4qsT1ZN" #Classic horror
YOUTUBE_CHANNEL_ID_33 = "PLeagipoZmyfnIxkk9qKN-ewkuDeI-JP0i" #Great Classic Movies
YOUTUBE_CHANNEL_ID_34 = "" #
YOUTUBE_CHANNEL_ID_35 = "PLKUihZ3LvFaOyX9b4zHwHTIORyAvEe5cv" #Old Fun Horror Movies
YOUTUBE_CHANNEL_ID_36 = "PLajqNV0-qkKdGiFNzmK5BA16MujBJ0bvv" #Film Noir Movies
YOUTUBE_CHANNEL_ID_37 = "PLgTLZSbwbEZycajt3dETO-OWMGMlbDusz" #Comedy movies
YOUTUBE_CHANNEL_ID_38 = "PLeagipoZmyfka1ErT1ZqWG489PyQV3l4_" #action adventure
YOUTUBE_CHANNEL_ID_39 = "PLkzvgsq3ySHBduUI5DSAwpJylNKkGYjqg" #Ghoulish Grin Films
YOUTUBE_CHANNEL_ID_40 = "" #
YOUTUBE_CHANNEL_ID_41 = "PLsZQnDqnebk6N7EchSMbmLXkGTFguhUba" #Popcorn Flix Drama
YOUTUBE_CHANNEL_ID_42 = "PLgTLZSbwbEZyhiPgeiO7pdwZQoeMl8dDD" #Kisstube Westerns
YOUTUBE_CHANNEL_ID_43 = "PLVuKsHxUDogz6EVwLDQvGxEqHzPNRYHE1" #Hallmark romance delete test
YOUTUBE_CHANNEL_ID_44 = "" #
YOUTUBE_CHANNEL_ID_45 = "PL79F09C65ABCEF855" #Movie mix
YOUTUBE_CHANNEL_ID_46 = "PLItvZTYiHnTaVEjKYLB5BLuLnamqQx2W-" #espn Sports docs
YOUTUBE_CHANNEL_ID_47 = "" #
YOUTUBE_CHANNEL_ID_48 = "PL9lDxmOVB4z5WAuY3U6vz6ugrJdrAcEe2" #Mystery, Crime, Detectives
YOUTUBE_CHANNEL_ID_49 = "" #
YOUTUBE_CHANNEL_ID_50 = "PLKLyNt670pENW70Io1rHsWWyBtetmnDxo" #Lifetime Movies
YOUTUBE_CHANNEL_ID_51 = "PLv7MWTL-Arz429W0pO2C3v5WX-xr2T8KJ" #Monster Movies
YOUTUBE_CHANNEL_ID_52 = "PL74839542356C41F1" #Hammer Horror & British Horror
YOUTUBE_CHANNEL_ID_53 = "PLyJXkvwe3Tj7qMsJdI79Wzg2-MPNhNEqn" #Romance & Comedy
YOUTUBE_CHANNEL_ID_54 = "PLDySQNnzfMCqoBxquMEhCOi0GUEB1RbCf" #Maverick Movie Mix
YOUTUBE_CHANNEL_ID_55 = "PLKnoifHxcT0b16B_2eR0l61igOsZHR7rp" #Rock Concerts
YOUTUBE_CHANNEL_ID_56 = "PLR8X0-qEtOCf8aeA-6bEBHNNwZv0GqvyZ" #All Genre Concerts
YOUTUBE_CHANNEL_ID_57 = "" #
YOUTUBE_CHANNEL_ID_58 = "PLHrguy3J2ka2NrIba_vzXMw6ZCOSeJagd" #Metal Rock
YOUTUBE_CHANNEL_ID_59 = "PLFCF55651BB105A0A" #Christian Music
YOUTUBE_CHANNEL_ID_60 = "PLdTy4tnpIn-PuUJaziWbheSLwnpdKrPF8" #Mix Genre Concerts
YOUTUBE_CHANNEL_ID_61 = "" #
YOUTUBE_CHANNEL_ID_62 = "" #
YOUTUBE_CHANNEL_ID_63 = "PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n" #Nature Docs
YOUTUBE_CHANNEL_ID_64 = "PLlHanBMNk-DKQzkktkFKGvJR_9gSRDhBr" #PBS Nova
YOUTUBE_CHANNEL_ID_65 = "PL_jFbqOSEqaLIYGS0Oz8jTlrB8PaHiwdp" #Animal Docs
YOUTUBE_CHANNEL_ID_66 = "PL9lDxmOVB4z4g2aeA9Em8lSK3TS-QBn0X" #True Crime
YOUTUBE_CHANNEL_ID_67 = "PL_FvdirKjxxv2ErAABDGJf23ah7kjvq4j" #Action Movies
YOUTUBE_CHANNEL_ID_68 = "" #
YOUTUBE_CHANNEL_ID_69 = "PL_FvdirKjxxta1fabzOXkBdpXmDYjf7cE" #Action Heroes
YOUTUBE_CHANNEL_ID_70 = "PL_FvdirKjxxs9PUud4-E7a_j5ezZ8yI_h" #Action Adventure
YOUTUBE_CHANNEL_ID_71 = "PLfS4i_GXOfPzestgSDJlG2PWwCs1TTLmZ" #LFL FULL Games
YOUTUBE_CHANNEL_ID_72 = "PLq-isVVF3foenhVLcdsGj1ww63hXKrso8" #WWE Full Matches
YOUTUBE_CHANNEL_ID_73 = "PLv0QwOQCR8PDNq8DjYWz1lWhQUM7elS23" #Sports Movies
YOUTUBE_CHANNEL_ID_74 = "PLCkP5LViwv1hpdmDR0WzOcCvOzMmAerUL" #Wrestling Docs
YOUTUBE_CHANNEL_ID_75 = "PLNNR5FiyIxqbO93WhkgS8yed0iq68IHUQ" #UK Football Docs
YOUTUBE_CHANNEL_ID_76 = "PLf0oK3K9_SbEaPZqDBWxNq_YTIpDkXVwn" #Wrestling Docs
YOUTUBE_CHANNEL_ID_77 = "PLX9_I-EOJPdGFAVAwQj4J7hg8q3m4AW5x" #War Drama
YOUTUBE_CHANNEL_ID_78 = "" #
YOUTUBE_CHANNEL_ID_79 = "PLajqNV0-qkKdVtKsaiiZoOI4ATsJMi0p8" #Drama and War
YOUTUBE_CHANNEL_ID_80 = "PLGKblFQXqJaed-4W_rZ-lYFTEbH667hIo" #Drama Movies
YOUTUBE_CHANNEL_ID_81 = "" #
YOUTUBE_CHANNEL_ID_82 = "PLFHLBLrXahtba_VDAfS1KtaXP1sVhIkxq" #Anime Movies
YOUTUBE_CHANNEL_ID_83 = "PLy6nRkX3CzyL4l6BAWjHSRwmXWvWgNdGU" #Anime 80s,90,2k
YOUTUBE_CHANNEL_ID_84 = "" #
YOUTUBE_CHANNEL_ID_85 = "PLKrpm9lxqdtyR8z1jz0M3ps_sgU9kJxfr" #Anime delete test
YOUTUBE_CHANNEL_ID_86 = "PLRQAisQ_6Be4x4J2zVdEuITH5lXDpPIaQ" #Anime Movies
YOUTUBE_CHANNEL_ID_87 = "PL653U1NizVmQrhW5_6DwnxU7bXj9eVyP2" #Animated Kids Movies
YOUTUBE_CHANNEL_ID_88 = "PLQ1h4vDpyXDMm_G5v0VBmqtnpgsmwKuKC" #80s Cartoon Movies
YOUTUBE_CHANNEL_ID_89 = "" #
YOUTUBE_CHANNEL_ID_90 = "" #
YOUTUBE_CHANNEL_ID_91 = "" #
YOUTUBE_CHANNEL_ID_92 = "" #
YOUTUBE_CHANNEL_ID_93 = "" #
YOUTUBE_CHANNEL_ID_94 = "" #
YOUTUBE_CHANNEL_ID_95 = "" #
YOUTUBE_CHANNEL_ID_96 = "" #
YOUTUBE_CHANNEL_ID_97 = "" #
YOUTUBE_CHANNEL_ID_98 = "" #
YOUTUBE_CHANNEL_ID_99 = "" #
YOUTUBE_CHANNEL_ID_100 = "" #
YOUTUBE_CHANNEL_ID_187 = "PLgTLZSbwbEZyhiPgeiO7pdwZQoeMl8dDD" #Kisstube Westerns
YOUTUBE_CHANNEL_ID_188 = "PLMoqN2xEQkkc9b_57p8WLxXbvES74XDhm" #John Wayne
YOUTUBE_CHANNEL_ID_189 = "PLttOfW_IF8ou8o_oW44XQ2fwZUWHpVopx" #English Westerns
YOUTUBE_CHANNEL_ID_190 = "PLttOfW_IF8oujCyF9SFhk9tkiSn4tBRDW" #More Westerns (296)
YOUTUBE_CHANNEL_ID_191 = "PLttOfW_IF8otgW8iqYhHcdtlU9HMt7BMM" #Westerns: More
YOUTUBE_CHANNEL_ID_192 = "PLttOfW_IF8ou_WTDOId6S2ay7Vkqc1aKd" #Westerns (401)
YOUTUBE_CHANNEL_ID_193 = "PLttOfW_IF8oudzC4YAqlrHjF2E2_mOX9c" #Spaghetti Westerns
YOUTUBE_CHANNEL_ID_194 = "" #
YOUTUBE_CHANNEL_ID_195 = "" #
YOUTUBE_CHANNEL_ID_196 = "" #
YOUTUBE_CHANNEL_ID_197 = "PLO6BFV6fgGwshi6dyglSREMxzpCsbI00W" #Kings Of Horror: Occult
YOUTUBE_CHANNEL_ID_198 = "PLO6BFV6fgGwt52dMGnLiUvezcI2Nl_UVR" #Kings Of Horror: Paranormal
YOUTUBE_CHANNEL_ID_199 = "PLO6BFV6fgGwsnq-D4Ywepm4Iqo_0H1ZAt" #Kings of Horror Cult Classics
YOUTUBE_CHANNEL_ID_200 = "" #
YOUTUBE_CHANNEL_ID_201 = "" #
YOUTUBE_CHANNEL_ID_202 = "PLO6BFV6fgGwt5x5KOWp0dBF-2moeUAfXT" #Kings Of Horror: Zombies
YOUTUBE_CHANNEL_ID_203 = "" #
YOUTUBE_CHANNEL_ID_204 = "PLO6BFV6fgGwtdn2Cit6wNTFjr4smKUfFp" #Kings Of Horror: Monster
YOUTUBE_CHANNEL_ID_205 = "" #
YOUTUBE_CHANNEL_ID_206 = "" #
YOUTUBE_CHANNEL_ID_207 = "PL8833BA169D818131"                 #Ghostbusters
YOUTUBE_CHANNEL_ID_208 = "PLJhIcqoOEkIHzRfW7JkToSanTq3_sVC9Y" #Halloween Specials (kids)
YOUTUBE_CHANNEL_ID_209 = "PLJhIcqoOEkIF3IDCJKzeUrFz8DJVI99wf" #Christmas Specials (kids)
YOUTUBE_CHANNEL_ID_210 = "PLJhIcqoOEkIGvRL_xHLR-rJ02ugIjIvIN" #Veggie Tales
YOUTUBE_CHANNEL_ID_211 = "PLC5928B59A036F71F"                 #Casper The Friendly Ghost
YOUTUBE_CHANNEL_ID_212 = "PLJhIcqoOEkIG8V0mD9R4UHEn2D_H0uYTw" #Postman Pat
YOUTUBE_CHANNEL_ID_213 = "PLJhIcqoOEkIHf_U2Xm51ikdQStv5itLkG" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_214 = "PLJhIcqoOEkIGK4UJc4ipDXAs5C5cExrUg" #Animated Shorts & Movies
YOUTUBE_CHANNEL_ID_215 = "PLJhIcqoOEkIG7ZHKu_XPC1PVXqHs_ziP-" #Animated Shows & Movies
YOUTUBE_CHANNEL_ID_216 = "PL653U1NizVmQrhW5_6DwnxU7bXj9eVyP2" #Animated Kids Movies
YOUTUBE_CHANNEL_ID_217 = "PLLCcmBcBRcT9jhSlKI_ZN1GBLHIKrfmtq" #He-Man Episodes
YOUTUBE_CHANNEL_ID_218 = "PLNw_hEO5pK1oWX6Uymk8YBtNcmC64EZlY" #
YOUTUBE_CHANNEL_ID_219 = "PLNw_hEO5pK1oilmenQgX3KuWZZ6xlG_5Y" #
YOUTUBE_CHANNEL_ID_220 = "PLNw_hEO5pK1rdjEOr5_CsfOG2IF0k6RJj" #
YOUTUBE_CHANNEL_ID_221 = "PLNw_hEO5pK1oRPp3UP1zM8g58cqae-tZM" #
YOUTUBE_CHANNEL_ID_222 = "" #
YOUTUBE_CHANNEL_ID_223 = "PLAPGcD5LGrp6oKuxwa8GlXNSFBrZXNZik" #Twilight Zone 2002
YOUTUBE_CHANNEL_ID_224 = "PL2J5vJE5wP76sr7UZXADB0NupTOkeOmrH" #Murder She Wrote
YOUTUBE_CHANNEL_ID_225 = "PL5q8VRGX_yLIDj-WwthUSxp4KO02E08zz" #Dragnet
YOUTUBE_CHANNEL_ID_226 = "PLQ52K4zUTvHZTA0yQE1xBIy90qwVc1heV" #Tales Of The Crypt
YOUTUBE_CHANNEL_ID_227 = "PLmHgXUJMN1TVtqyVXJ4D3ozPxgwpV-UpQ" #Sherlock Holmes
YOUTUBE_CHANNEL_ID_228 = "PLC1EDzqtkrh9qeOtJCDt4Tr1QCCt4Fat4" #Mr Bean
YOUTUBE_CHANNEL_ID_229 = "PLgNgFgeTm0piyrBYD_7R3aGFTX2OAznWx" #Hanna Montana
YOUTUBE_CHANNEL_ID_230 = "PLOZzM8Kp5jhrsRi4n7KDHLZNL8owoM7Mp" #Western TV Shows
YOUTUBE_CHANNEL_ID_231 = "PLfJt-7qbuNtMFHMG_k2py2ABxrdnsEHIQ" #The Rebel
YOUTUBE_CHANNEL_ID_232 = "PL1V2SSERycssvC_FFdtBA16Qhiityw_ii" #Beverly Hillbillies
YOUTUBE_CHANNEL_ID_233 = "PL5q8VRGX_yLKVGbvIA6H18WTQmWS3TdH4" #New Detectives
YOUTUBE_CHANNEL_ID_234 = "PLeagipoZmyfnGP2cUhKrGU-6nv7CrtoE7" #Robin Hood 2006
YOUTUBE_CHANNEL_ID_235 = "PLmHgXUJMN1TXCZbl3w_RYofN_XMCRDtdy" #The Lucky Show
YOUTUBE_CHANNEL_ID_236 = "PLAPGcD5LGrp6WZOZyH1y3dkxi2eTxXi74" #Blake 7
YOUTUBE_CHANNEL_ID_237 = "PLd4rjD_RVZHEn0GxzchcjIdBBYTjsWv-X" #Classic Mr Bean
YOUTUBE_CHANNEL_ID_238 = "PL-QrWtkF-hBXqQslPleMFyAzjP7W7rF3u" #Classic BBC Mystery
YOUTUBE_CHANNEL_ID_239 = "PLB4401F8B2A9A304E"                 #Supercar
YOUTUBE_CHANNEL_ID_240 = "PL98x8JlHx_53N__G9_FFi3kcFJmgsHzkY" #Wagon Train
YOUTUBE_CHANNEL_ID_241 = "" #
YOUTUBE_CHANNEL_ID_242 = "" #
YOUTUBE_CHANNEL_ID_243 = "" #
YOUTUBE_CHANNEL_ID_244 = "" #
YOUTUBE_CHANNEL_ID_245 = "PLZeX9OgnzaHTfuoHY1Iz-SVEmOjF8Ryqp" #Medabots
YOUTUBE_CHANNEL_ID_246 = "PLoZfc2ixKLaGVrxuIP9j3eMVkDTeVA_Hz" #Clutch Cargo
YOUTUBE_CHANNEL_ID_247 = "PL2olSkgdlnHRytv2YEMltf04-QjNgbDuI" #King Of The Hill
YOUTUBE_CHANNEL_ID_248 = "PLNw_hEO5pK1oWX6Uymk8YBtNcmC64EZlY" #Guardians Of The Galaxy
YOUTUBE_CHANNEL_ID_249 = "PLNw_hEO5pK1oilmenQgX3KuWZZ6xlG_5Y" #Super Hero Squad
YOUTUBE_CHANNEL_ID_250 = "PLNw_hEO5pK1rdjEOr5_CsfOG2IF0k6RJj" #Ultimate Spider-man
YOUTUBE_CHANNEL_ID_251 = "PLNw_hEO5pK1oRPp3UP1zM8g58cqae-tZM" #Avengers Assemble" #
YOUTUBE_CHANNEL_ID_252 = "PLmgflcERua_0WknstC140kI8NFw3FqKNx" #Animated Toon Shows
YOUTUBE_CHANNEL_ID_253 = "PLqcNVz8UuCsJ0yJ5Td4bxbVHejncVncIj" #Inspector Gadget
YOUTUBE_CHANNEL_ID_254 = "" #
YOUTUBE_CHANNEL_ID_255 = "PLfuvnXufZmWLwwxtSXtDhNeFQeDXNjcYu" #Ancient Aliens
YOUTUBE_CHANNEL_ID_256 = "" #
YOUTUBE_CHANNEL_ID_257 = "" #
YOUTUBE_CHANNEL_ID_258 = "PLKhPstAakbEdzU-e3UwOglKg7w-Bjvj2C" #Bassmaster
YOUTUBE_CHANNEL_ID_259 = "PLXOUT0qRzAKFKd9O9KYchkp0_ZgxT3zoJ" #Wrestling Pay Per Views
YOUTUBE_CHANNEL_ID_260 = "PL0PTdhK8s-5QxWhL4o9cK5xZDzdfoZx6c" #Robson Green Fishing
YOUTUBE_CHANNEL_ID_261 = "" #
YOUTUBE_CHANNEL_ID_262 = "" #
YOUTUBE_CHANNEL_ID_263 = "" #
YOUTUBE_CHANNEL_ID_264 = "" #
YOUTUBE_CHANNEL_ID_265 = "" #
YOUTUBE_CHANNEL_ID_266 = "" #
YOUTUBE_CHANNEL_ID_267 = "" #
YOUTUBE_CHANNEL_ID_268 = "" #
YOUTUBE_CHANNEL_ID_269 = "" #
YOUTUBE_CHANNEL_ID_270 = "" #
YOUTUBE_CHANNEL_ID_271 = "PLuALSlPoVa23Ok2TFHCrftqkDKOnIpFLo" #Official Pat and Stan
YOUTUBE_CHANNEL_ID_272 = "PLRU3FsQ1MS5KFsjh5Txh14b4PuGEn9MUK" #Tractor Tom
YOUTUBE_CHANNEL_ID_273 = "PLHOR8x-IicVJDAmJWZmJ-IMu1x3lTAld5" #HUMF
YOUTUBE_CHANNEL_ID_274 = "PLM7OLrgQDj4YIWPViSg4IudtwqluSJ60E" #Max & Ruby
YOUTUBE_CHANNEL_ID_275 = "PLV3Gd8vEgOrjvlv718bZzcAf5DdcyGjHr" #Hoopla Kids Show
YOUTUBE_CHANNEL_ID_276 = "" #
YOUTUBE_CHANNEL_ID_277 = "PL1jLb_9BOrCC2kd1wxZi2Bnvi2hkMTDCd" #Kids Channel
YOUTUBE_CHANNEL_ID_278 = "PLaKLlbutuIs83m4PDnCkxgz_5hduThPsG" #TuTiTu TV
YOUTUBE_CHANNEL_ID_279 = "PL-qhrpQ30cRzkr24PV9xbLxQXgCaNH0je" #Yo GABBA GABBA
YOUTUBE_CHANNEL_ID_280 = "" #
YOUTUBE_CHANNEL_ID_281 = "" #
YOUTUBE_CHANNEL_ID_282 = "" #
YOUTUBE_CHANNEL_ID_283 = "PLpd15K7DiNG8mj-bcXKwvqmET6ZWIWGzS" #Bananas In Pyjamas
YOUTUBE_CHANNEL_ID_284 = "PLhLlo5SXGT_0kedDOwvbTeMwp0Uz3Af4q" #Fifi and the Flowertots
YOUTUBE_CHANNEL_ID_285 = "PLzcEpQYkRSQ1hBS_Caklp3a3NupYQxbqM" #Postman Pat
YOUTUBE_CHANNEL_ID_286 = "PLKxKJVHwiseXLWkzfAOIVqZyUDNLnuplm" #Olivia The Pig
YOUTUBE_CHANNEL_ID_287 = "PLT81qowKRHzRCE2M7wuj2Y56ZTPLq0DMD" #Little Charlie Bear
YOUTUBE_CHANNEL_ID_288 = "PLGYOf7BkKBf0iifp9NGfwId1wZcd1WSJX" #VeggieTales
YOUTUBE_CHANNEL_ID_289 = "PL-zGgztzqlybth6-PPi1d2T39srXc--8q" #Strawberry Shortcake
YOUTUBE_CHANNEL_ID_290 = "PL3WuRw0nOgHPOgZ04JAzw_BfLzw0LHpLE" #Noddy In Toyland
YOUTUBE_CHANNEL_ID_291 = "PL6um4JyGrH5oe9UGIlUUB2efBS_erzvL1" #Ben and Holly Little Kingdom
YOUTUBE_CHANNEL_ID_292 = "PLdpyjDsvgMln1KZ7tqtKEMgCUMpRRLaip" #The Kids Club
YOUTUBE_CHANNEL_ID_293 = "PLB6QoGOGkP7OSV0vkG53hxyX6oFwkwQ4O" #Giggle Bellies
YOUTUBE_CHANNEL_ID_294 = "PLtgzvugo5sZdLGaHopCexqGPGiaZgBgl3" #Oh My Genius
YOUTUBE_CHANNEL_ID_295 = "PLBlSpozHTVp0MTkOsHfYkqmM-XoFmS4is" #Fluffy Jet Toys
YOUTUBE_CHANNEL_ID_296 = "" #
YOUTUBE_CHANNEL_ID_297 = "" #
YOUTUBE_CHANNEL_ID_298 = "" #
YOUTUBE_CHANNEL_ID_299 = "" #
YOUTUBE_CHANNEL_ID_300 = "" #

YOUTUBE_CHANNEL_ID_325 = "" #
YOUTUBE_CHANNEL_ID_326 = "UCf8eeJIxklNmYLK_Zi_eCCQ" #The Vintage Movies Channel
YOUTUBE_CHANNEL_ID_327 = "JaggedReliefCartoons" #Jagged Relief Channel
YOUTUBE_CHANNEL_ID_328 = "UCGBzBkV-MinlBvHBzZawfLQ" #Classic Movies Channel
YOUTUBE_CHANNEL_ID_329 = "" #
YOUTUBE_CHANNEL_ID_330 = "" #
YOUTUBE_CHANNEL_ID_331 = "Classixflix" #Classix Flix Channel
YOUTUBE_CHANNEL_ID_332 = "UCYHHgSLnAvhpGszOpZZwnbg" #RBM Pictures Channel
YOUTUBE_CHANNEL_ID_333 = "UCgVhSufhsCLnLYo_xqvmpvw" #Mr. Spinks Channel
YOUTUBE_CHANNEL_ID_334 = "UCmXQRtLSFJC4v_pYXaM3DGQ" #Classic Westerns Channel
YOUTUBE_CHANNEL_ID_335 = "UCycDFnpMeWzaITQSD1dWsOA" #Classic Cinema Channel
YOUTUBE_CHANNEL_ID_336 = "UCibOdW_Yj0-pj5SQGZxZIgA" #Retrospective Channel
YOUTUBE_CHANNEL_ID_337 = "" #
YOUTUBE_CHANNEL_ID_338 = "" #
YOUTUBE_CHANNEL_ID_339 = "" #
YOUTUBE_CHANNEL_ID_340 = "" #
YOUTUBE_CHANNEL_ID_341 = "" #
YOUTUBE_CHANNEL_ID_342 = "" #
YOUTUBE_CHANNEL_ID_343 = "" #
YOUTUBE_CHANNEL_ID_344 = "" #
YOUTUBE_CHANNEL_ID_345 = "" #
YOUTUBE_CHANNEL_ID_346 = "" #
YOUTUBE_CHANNEL_ID_347 = "" #
YOUTUBE_CHANNEL_ID_348 = "" #
YOUTUBE_CHANNEL_ID_349 = "" #
YOUTUBE_CHANNEL_ID_350 = "UCNcUc5v0Kt5afE_jcbbZUBQ" #Artflix Movies Channel
YOUTUBE_CHANNEL_ID_351 = "UCBWJEa2VHKB3PXHYMpgOj1Q" #Flixdome Movies Channel
YOUTUBE_CHANNEL_ID_352 = "" #
YOUTUBE_CHANNEL_ID_353 = "UCQ7W-F1-p28MZnYGPmLQ7bw" #One Night At The Drive-in
YOUTUBE_CHANNEL_ID_354 = "UC_kZkohCJURAQLwzzOUtBhA" #Biscoot Hollywood Movies
YOUTUBE_CHANNEL_ID_355 = "papadoc73" #Channel 3 Youtube
YOUTUBE_CHANNEL_ID_356 = "PizzaFlix" #The Pizza Flix Channel
YOUTUBE_CHANNEL_ID_357 = "" #
YOUTUBE_CHANNEL_ID_358 = "" #
YOUTUBE_CHANNEL_ID_359 = "drelbcom" #drelbcom Channel
YOUTUBE_CHANNEL_ID_360 = "ampopfilms" #Ampop Films Channels
YOUTUBE_CHANNEL_ID_361 = "TimelessClassicFilms" #Timeless Classic Films
YOUTUBE_CHANNEL_ID_362 = "" #
YOUTUBE_CHANNEL_ID_363 = "" #
YOUTUBE_CHANNEL_ID_364 = "PLqS983RUSTgz0ME8aYN2lgNWiB82nflw3" #Sports Movies
YOUTUBE_CHANNEL_ID_365 = "PLVklzdh0Ba4YYrXAfxmlMsfJHiHQ9be0A" #More Sports Flix
YOUTUBE_CHANNEL_ID_366 = "PLOeYAlRPoCMClPcWPiyYYSziQ1odDpqwP" #More Sports Movies
YOUTUBE_CHANNEL_ID_367 = "PLsZQnDqnebk6RNHCtE-lpzKI8azCpxUac" #Popcorn Flix Sports
YOUTUBE_CHANNEL_ID_368 = "" #
YOUTUBE_CHANNEL_ID_369 = "" #
YOUTUBE_CHANNEL_ID_370 = "" #
YOUTUBE_CHANNEL_ID_371 = "" #
YOUTUBE_CHANNEL_ID_372 = "" #
YOUTUBE_CHANNEL_ID_373 = "" #
YOUTUBE_CHANNEL_ID_374 = "" #
YOUTUBE_CHANNEL_ID_375 = "UCCYhvWD88Mbd2M14GqpPM9A" #Cloud 5 Family Channel
YOUTUBE_CHANNEL_ID_376 = "" #
YOUTUBE_CHANNEL_ID_377 = "UCNLdqhBwGzscezZwsdcm0SA" #Superhero Kids Channel
YOUTUBE_CHANNEL_ID_378 = "multfilm" #Kedoo ToonsTV Channel
YOUTUBE_CHANNEL_ID_379 = "westernsontheweb" #Westerns On The Web
YOUTUBE_CHANNEL_ID_380 = "wildwesttoys1" #Wild West Toys Channel
YOUTUBE_CHANNEL_ID_381 = "vids4kidstv" #Vids 4 Kids Channel
YOUTUBE_CHANNEL_ID_382 = "UC9trsD1jCTXXtN3xIOIU8gg" #WB Kids Channel
YOUTUBE_CHANNEL_ID_383 = "" #
YOUTUBE_CHANNEL_ID_384 = "TheVoiceKidsAU" #The Voice Kids Au
YOUTUBE_CHANNEL_ID_385 = "UCkOxf5c1enax60y6wfB-Y6g" #Fun Science For Kids
YOUTUBE_CHANNEL_ID_386 = "UCknQp_ATYj_o4_uPS3hDcTw" #Little Kids Channel
YOUTUBE_CHANNEL_ID_387 = "UCZ6jURNr1WQZCNHF0ao-c0g" #Universal Kids Channel
YOUTUBE_CHANNEL_ID_388 = "" #
YOUTUBE_CHANNEL_ID_389 = "" #
YOUTUBE_CHANNEL_ID_390 = "" #
YOUTUBE_CHANNEL_ID_391 = "" #
YOUTUBE_CHANNEL_ID_392 = "" #
YOUTUBE_CHANNEL_ID_393 = "" #
YOUTUBE_CHANNEL_ID_394 = "" #
YOUTUBE_CHANNEL_ID_395 = "" #
YOUTUBE_CHANNEL_ID_396 = "" #
YOUTUBE_CHANNEL_ID_397 = "" #
YOUTUBE_CHANNEL_ID_398 = "" #
YOUTUBE_CHANNEL_ID_399 = "" #
YOUTUBE_CHANNEL_ID_400 = "UCnk71WleNch-LckZvidkTYA" #Future Zone Movie Channel
YOUTUBE_CHANNEL_ID_401 = "UCHuG1lSWjlTbeGJpfQgFWfg" #The Sci-fi TV Channel
YOUTUBE_CHANNEL_ID_402 = "" #
YOUTUBE_CHANNEL_ID_403 = "" #
YOUTUBE_CHANNEL_ID_404 = "mst3kofficial" #Mystery Science Theater 3000
YOUTUBE_CHANNEL_ID_405 = "UC7sDT8jZ76VLV1u__krUutA" #Dust Sci-fi Shorts Channel
YOUTUBE_CHANNEL_ID_406 = "UCZUkQij64MCMH-3b1ycUGjg" #Barbarella X Sci-fi Channel
YOUTUBE_CHANNEL_ID_407 = "" #
YOUTUBE_CHANNEL_ID_408 = "" #
YOUTUBE_CHANNEL_ID_409 = "" #
YOUTUBE_CHANNEL_ID_410 = "" #
YOUTUBE_CHANNEL_ID_411 = "" #
YOUTUBE_CHANNEL_ID_412 = "" #
YOUTUBE_CHANNEL_ID_413 = "" #
YOUTUBE_CHANNEL_ID_414 = "" #
YOUTUBE_CHANNEL_ID_415 = "" #
YOUTUBE_CHANNEL_ID_416 = "" #
YOUTUBE_CHANNEL_ID_417 = "" #
YOUTUBE_CHANNEL_ID_418 = "" #
YOUTUBE_CHANNEL_ID_419 = "" #
YOUTUBE_CHANNEL_ID_420 = "" #
YOUTUBE_CHANNEL_ID_500 = "TheKingsofHorror" #The Kings of Horror
YOUTUBE_CHANNEL_ID_501 = "" #
YOUTUBE_CHANNEL_ID_502 = "" #
YOUTUBE_CHANNEL_ID_503 = "UCIbCd95HIkwZx6DqlWSeDcA" #The Viewster Horror Channel
YOUTUBE_CHANNEL_ID_504 = "" #
YOUTUBE_CHANNEL_ID_505 = "UCqoWfNP5nYndE47qJ6KSYYg" #Terror Films Horror Channel
YOUTUBE_CHANNEL_ID_506 = "UC951AqujycbBI083GmKRY3A" #New Castle After Dark Channel
YOUTUBE_CHANNEL_ID_507 = "" #
YOUTUBE_CHANNEL_ID_508 = "UCHgm6IUmnTV2aAMMCSPq8zA" #A Touch Of Evil Channel
YOUTUBE_CHANNEL_ID_509 = "" #
YOUTUBE_CHANNEL_ID_510 = "cinenethorror" #Cinenet Horror Movie Channel
YOUTUBE_CHANNEL_ID_511 = "" #
YOUTUBE_CHANNEL_ID_512 = "" #
YOUTUBE_CHANNEL_ID_513 = "" #
YOUTUBE_CHANNEL_ID_514 = "" #
YOUTUBE_CHANNEL_ID_515 = "" #
YOUTUBE_CHANNEL_ID_516 = "" #
YOUTUBE_CHANNEL_ID_517 = "" #
YOUTUBE_CHANNEL_ID_518 = "" #
YOUTUBE_CHANNEL_ID_519 = "" #
YOUTUBE_CHANNEL_ID_520 = "" #
YOUTUBE_CHANNEL_ID_521 = "" #
YOUTUBE_CHANNEL_ID_522 = "" #
YOUTUBE_CHANNEL_ID_523 = "" #
YOUTUBE_CHANNEL_ID_524 = "" #
YOUTUBE_CHANNEL_ID_525 = "UC9pYOJPB5UYlMlGKKZWo-Bw" #Space And The Universe
YOUTUBE_CHANNEL_ID_526 = "" #
YOUTUBE_CHANNEL_ID_527 = "AwesomeDocumentary"       #Awesome Documentary Channel
YOUTUBE_CHANNEL_ID_528 = "" #
YOUTUBE_CHANNEL_ID_529 = "UCQJZ7iNyu1wBhwmkfB9lS5g" #Movie Star Documentary
YOUTUBE_CHANNEL_ID_530 = "UCp4wHZCrDhITkiUILOd4gRw" #The Documentary Channel
YOUTUBE_CHANNEL_ID_531 = "" #
YOUTUBE_CHANNEL_ID_532 = "UCa-bX3gZC3YnCThlGM5d38Q" #The Fifth Estate - Canada
YOUTUBE_CHANNEL_ID_533 = "UCfCO1oX5zmrZmWGgB6VyTBg" #BBC Dinosaur Documentaries
YOUTUBE_CHANNEL_ID_534 = "UCfCPuldqz1tCk6xa2HoL1yA" #Space Documentary Channel
YOUTUBE_CHANNEL_ID_535 = "" #
YOUTUBE_CHANNEL_ID_536 = "UCParRQKYTA8Yh7_lo4DvGQA" #Music Documentary & Concerts
YOUTUBE_CHANNEL_ID_537 = "FilmRiseDocumentary"      #Filmrise Documentary Channel
YOUTUBE_CHANNEL_ID_538 = "" #
YOUTUBE_CHANNEL_ID_539 = "Wober"                    #Truth Documentaries Channel
YOUTUBE_CHANNEL_ID_540 = "UC_0r3EheCnp-wVvndYDGviQ" #Reel Truth Crime Channel
YOUTUBE_CHANNEL_ID_541 = "" #
YOUTUBE_CHANNEL_ID_542 = "" #
YOUTUBE_CHANNEL_ID_543 = "UCXeFop7x3vyUAe_O7gliRkA" #Ultra Action Channel
YOUTUBE_CHANNEL_ID_544 = "UCJ6CnjyJh5OPLrF6OZGkcqQ" #Fight Area Movie Channel
YOUTUBE_CHANNEL_ID_545 = "UCO7swxrJsImdC1k5WsXxANA" #Rjval Fighting Movies
YOUTUBE_CHANNEL_ID_546 = "UC42AWLZ4V5iIKMClSZVcl9g" #Kung Fu N Fight Movies
YOUTUBE_CHANNEL_ID_547 = "UCpuFQWstSTZ_q_qtCZq0phg" #Alpha X War Movies
YOUTUBE_CHANNEL_ID_548 = "" #
YOUTUBE_CHANNEL_ID_549 = "PL8zlx4BqIHThGh2vDxHgeesdj1kbRv-kb" #Musical Movies
YOUTUBE_CHANNEL_ID_550 = "PL8Nn95jd6kYVouE2YjQT2oTwG7ZbAjak1" #Classic Musicals
YOUTUBE_CHANNEL_ID_551 = "PLI0NxXh5RQAnMedqVNzJSo7ohKRASd1TT" #More Musical Flix
YOUTUBE_CHANNEL_ID_552 = "" #
YOUTUBE_CHANNEL_ID_553 = "" #
YOUTUBE_CHANNEL_ID_554 = "" #
YOUTUBE_CHANNEL_ID_555 = "" #
YOUTUBE_CHANNEL_ID_556 = "" #
YOUTUBE_CHANNEL_ID_557 = "" #
YOUTUBE_CHANNEL_ID_558 = "" #
YOUTUBE_CHANNEL_ID_559 = "" #
YOUTUBE_CHANNEL_ID_560 = "" #
YOUTUBE_CHANNEL_ID_561 = "" #
YOUTUBE_CHANNEL_ID_562 = "" #
YOUTUBE_CHANNEL_ID_563 = "" #
YOUTUBE_CHANNEL_ID_564 = "" #
YOUTUBE_CHANNEL_ID_565 = "" #
YOUTUBE_CHANNEL_ID_566 = "" #
YOUTUBE_CHANNEL_ID_567 = "UCZdj-4sy4usytsZ6qbPnqsw" #Animation Movies Channel
YOUTUBE_CHANNEL_ID_568 = "UCr22Oyd2WENz0LiDphyIkJA" #Cartoon Toonz Channel
YOUTUBE_CHANNEL_ID_569 = "UCybRyeQsPlObwkJ8SO7bxoA" #Redwall Cartoon Channel
YOUTUBE_CHANNEL_ID_570 = "" #
YOUTUBE_CHANNEL_ID_571 = "" #
YOUTUBE_CHANNEL_ID_572 = "" #
YOUTUBE_CHANNEL_ID_573 = "" #
YOUTUBE_CHANNEL_ID_574 = "" #
YOUTUBE_CHANNEL_ID_575 = "" #
YOUTUBE_CHANNEL_ID_576 = "PLBHqHeFZPW9Hs_AyvGkYFqRiyGEID7qqe" #1930s Film Classics
YOUTUBE_CHANNEL_ID_577 = "PLk0JVm_FsEBFOS6GQzU6OPGCDyVdr9FPX" #1940s Film Classics
YOUTUBE_CHANNEL_ID_578 = "PLHCfKqP2kHUjfU0FuP4069ueXitcXaqL0" #1940s Horror Movies
YOUTUBE_CHANNEL_ID_579 = "" #
YOUTUBE_CHANNEL_ID_580 = "" #
YOUTUBE_CHANNEL_ID_581 = "PLwygboCFkeeDCVhsPydRRgn7_pYo0_Ni_" #More 1950s Movies
YOUTUBE_CHANNEL_ID_582 = "PLGFUJPQvStUl8SLGRQZmJV2888yCbaZyl" #1950s Sci-fi Movies
YOUTUBE_CHANNEL_ID_583 = "PLhDmoH4Bxhxyp8v3Lq-V0EoFMxlm2nefR" #Cheesy 1950s Sci-fi
YOUTUBE_CHANNEL_ID_584 = "PLHCfKqP2kHUi_WgUsakf7xK0Lj4o-SqlQ" #1950s Horror Movies
YOUTUBE_CHANNEL_ID_585 = "PLjygzGIObj88pLTHJUmUD8hUnhqVYJ25Y" #Movies Of The 1960s
YOUTUBE_CHANNEL_ID_586 = "PL1Lpcnsvs3JH9VYW5FAVIMVMCGpzwk3Rk" #1960s Sci-fi Movies
YOUTUBE_CHANNEL_ID_587 = "PLqAeW2ChBiNPKXoTykZZGDYHc4CYgt_1_" #1960s Horror Movies
YOUTUBE_CHANNEL_ID_588 = "PL54qFWNk70fQxVBKl792TYM6ZjNjw0ehZ" #Movies Of The 1970s
YOUTUBE_CHANNEL_ID_589 = "" #
YOUTUBE_CHANNEL_ID_590 = "PLBD55FC56A8CE49B4"                 #1970s Horror Movies
YOUTUBE_CHANNEL_ID_591 = "PLSeZ6qt37vqzA1UF-Jt-umIh5rPdnL3B1" #More 1970s Horror
YOUTUBE_CHANNEL_ID_592 = "PL9-JlwYEj37W_Mx6OMVrGb4TOBCeCQ9de" #Rare 1980s Movies
YOUTUBE_CHANNEL_ID_593 = "PL9G-CZo8LnsMFzi9lbjZRbTBRO584nYYL" #1970s Made For TV
YOUTUBE_CHANNEL_ID_594 = "" #
YOUTUBE_CHANNEL_ID_595 = "PLGoD7-IRaE5UxNGFJ92YZIfBVglzvmntV" #1980s Sci-fi Movies
YOUTUBE_CHANNEL_ID_596 = "PLjygzGIObj89_G0e8w6yHDGFfGSrTs9so" #Movies: More 1980s
YOUTUBE_CHANNEL_ID_597 = "PLaKd4X9vJ__zkjUwwMt-Szr_2lTZB-B6z" #More 1980s Movies
YOUTUBE_CHANNEL_ID_598 = "" #
YOUTUBE_CHANNEL_ID_599 = "PL7AzNmZEtiHWTI6VdOHOYwSaELMWC78yO" #Movies Of The 1990s
YOUTUBE_CHANNEL_ID_600 = "PLKxdKKLx3iRTyfWK8SQghHUGHfOTGhRl2" #More 1990s Movies
YOUTUBE_CHANNEL_ID_601 = "PLSSECiTJe_BWtMaN1ATjxZE1aSYUTnter" #1990s Horror Movies
YOUTUBE_CHANNEL_ID_602 = "" #
YOUTUBE_CHANNEL_ID_603 = "PLVyxJvG53fqAsscxnskG9MQUlWucbAJaO" #1990s Sci-fi Horror
YOUTUBE_CHANNEL_ID_604 = "PLjygzGIObj89nvIY6-wj3Ed40_zXGf89D" #Movies Of The 2000s
YOUTUBE_CHANNEL_ID_605 = "PLGrVBhFJEP2OPAbjW_HVkIpgpHxiNUGFX" #More Movies In 2000s
YOUTUBE_CHANNEL_ID_606 = "" #
YOUTUBE_CHANNEL_ID_607 = "PL9G-CZo8LnsPjEJq3I04FiumS5WFZCx2o" #True Crime Movies
YOUTUBE_CHANNEL_ID_608 = "PLVyxJvG53fqAO7cMgpNAqyUQomz1h-3pW" #Crime Movies 30s-60s
YOUTUBE_CHANNEL_ID_609 = "PL0petlbNFocpMGCtAjwp917hPJPv8onFl" #More True Crime Flix
YOUTUBE_CHANNEL_ID_610 = ""           #
YOUTUBE_CHANNEL_ID_611 = "UC_0r3EheCnp-wVvndYDGviQ"           #Reel Truth Crime
YOUTUBE_CHANNEL_ID_612 = "UCyG3mbSm4z6SyGPNvkgx_Yg"           #Filmrise Crime Channel
YOUTUBE_CHANNEL_ID_613 = "" #
YOUTUBE_CHANNEL_ID_614 = "" #
YOUTUBE_CHANNEL_ID_615 = "" #
YOUTUBE_CHANNEL_ID_616 = "" #
YOUTUBE_CHANNEL_ID_617 = "" #
YOUTUBE_CHANNEL_ID_618 = "" #
YOUTUBE_CHANNEL_ID_619 = "" #
YOUTUBE_CHANNEL_ID_620 = "" #
YOUTUBE_CHANNEL_ID_621 = "" #
YOUTUBE_CHANNEL_ID_622 = "" #
YOUTUBE_CHANNEL_ID_623 = "" #
YOUTUBE_CHANNEL_ID_624 = "" #
YOUTUBE_CHANNEL_ID_625 = "" #
YOUTUBE_CHANNEL_ID_626 = "" #
YOUTUBE_CHANNEL_ID_627 = "" #
YOUTUBE_CHANNEL_ID_628 = "" #
YOUTUBE_CHANNEL_ID_629 = "" #
YOUTUBE_CHANNEL_ID_630 = "" #
YOUTUBE_CHANNEL_ID_631 = "" #
YOUTUBE_CHANNEL_ID_632 = "" #
YOUTUBE_CHANNEL_ID_633 = "" #
YOUTUBE_CHANNEL_ID_634 = "" #
YOUTUBE_CHANNEL_ID_635 = "" #
YOUTUBE_CHANNEL_ID_636 = "" #
YOUTUBE_CHANNEL_ID_637 = "" #
YOUTUBE_CHANNEL_ID_638 = "" #
YOUTUBE_CHANNEL_ID_639 = "" #
YOUTUBE_CHANNEL_ID_640 = "" #
YOUTUBE_CHANNEL_ID_641 = "" #
YOUTUBE_CHANNEL_ID_642 = "" #
YOUTUBE_CHANNEL_ID_643 = "" #
YOUTUBE_CHANNEL_ID_644 = "" #
YOUTUBE_CHANNEL_ID_645 = "" #
YOUTUBE_CHANNEL_ID_646 = "" #
YOUTUBE_CHANNEL_ID_647 = "" #
YOUTUBE_CHANNEL_ID_648 = "" #
YOUTUBE_CHANNEL_ID_649 = "" #
YOUTUBE_CHANNEL_ID_650 = "" #
YOUTUBE_CHANNEL_ID_651 = "" #
YOUTUBE_CHANNEL_ID_652 = "" #
YOUTUBE_CHANNEL_ID_653 = "" #
YOUTUBE_CHANNEL_ID_654 = "" #
YOUTUBE_CHANNEL_ID_655 = "" #
YOUTUBE_CHANNEL_ID_656 = "" #
YOUTUBE_CHANNEL_ID_657 = "" #
YOUTUBE_CHANNEL_ID_658 = "" #
YOUTUBE_CHANNEL_ID_659 = "" #
YOUTUBE_CHANNEL_ID_660 = "" #
YOUTUBE_CHANNEL_ID_661 = "" #
YOUTUBE_CHANNEL_ID_662 = "" #
YOUTUBE_CHANNEL_ID_663 = "" #
YOUTUBE_CHANNEL_ID_664 = "" #
YOUTUBE_CHANNEL_ID_665 = "" #
YOUTUBE_CHANNEL_ID_666 = "" #
YOUTUBE_CHANNEL_ID_667 = "" #
YOUTUBE_CHANNEL_ID_668 = "" #
YOUTUBE_CHANNEL_ID_669 = "" #
YOUTUBE_CHANNEL_ID_670 = "" #
YOUTUBE_CHANNEL_ID_671 = "" #
YOUTUBE_CHANNEL_ID_672 = "" #
YOUTUBE_CHANNEL_ID_673 = "" #
YOUTUBE_CHANNEL_ID_674 = "" #
YOUTUBE_CHANNEL_ID_675 = "" #
YOUTUBE_CHANNEL_ID_676 = "ScreenMediaPictures"      #The PopcornFlix Channel
YOUTUBE_CHANNEL_ID_677 = "UCeuA6RU1Ua3Mstr2gcnAYCQ" #Film Zone Channel
YOUTUBE_CHANNEL_ID_678 = "" #
YOUTUBE_CHANNEL_ID_679 = "UCE_0zvmu1pMYZAgqyjW6qsQ" #Bigtime Movies Channel
YOUTUBE_CHANNEL_ID_680 = "UC8IHAQMuiJdY6ALuhG7iU8Q" #Filmrise Movies Channel
YOUTUBE_CHANNEL_ID_681 = "ViewsterTV"               #Viewster Movies Channel
YOUTUBE_CHANNEL_ID_682 = "UClNYP19GgDfR8GZpZ87ewoQ" #Amazingly Classic Movies
YOUTUBE_CHANNEL_ID_683 = "maverickent"              #Maverick Movie Channel
YOUTUBE_CHANNEL_ID_684 = "UCyJYCQ6WaEMhdZAuPo799bA" #Grjngo Westerns Channel
YOUTUBE_CHANNEL_ID_685 = "westernmaniadotcom"       #Western Mania Channel
YOUTUBE_CHANNEL_ID_686 = "UCRHcpjAIeJpAVhnSaa_I2hQ" #The Movieholic Channel
YOUTUBE_CHANNEL_ID_687 = "UCDhey18N756Hi0IB8Tudr1g" #Superhits Movie Channel
YOUTUBE_CHANNEL_ID_688 = "UCOTeh4TQ6MrFF4Agq_pYXJQ" #Movie Navigator Classics
YOUTUBE_CHANNEL_ID_689 = "manicmoviesdotcom"        #Manic Movie Classics
YOUTUBE_CHANNEL_ID_690 = "UCOwzRfgVa2VkvdPEM1XVW4Q" #Flix Vault Channel
YOUTUBE_CHANNEL_ID_691 = "" #
YOUTUBE_CHANNEL_ID_692 = "" #
YOUTUBE_CHANNEL_ID_693 = "" #
YOUTUBE_CHANNEL_ID_694 = "" #
YOUTUBE_CHANNEL_ID_695 = "" #
YOUTUBE_CHANNEL_ID_696 = "" #
YOUTUBE_CHANNEL_ID_697 = "" #
YOUTUBE_CHANNEL_ID_698 = "" #
YOUTUBE_CHANNEL_ID_699 = "" #
YOUTUBE_CHANNEL_ID_700 = "" #

YOUTUBE_CHANNEL_ID_717 = "PL1Lpcnsvs3JEAjIVbEQUv1DSw1TkCRHC1" #Jerry Lewis N Dean Martin
YOUTUBE_CHANNEL_ID_718 = "" #
YOUTUBE_CHANNEL_ID_719 = "PLjyBAuyo5sMgphUs0ICrTv0KQCghD-ErS" #Laurel And Hardy Movies

YOUTUBE_CHANNEL_ID_750 = "PL2aoGe5t_a0IRRvENQlsWv9OIe8F7PH4U" #90s Anime Movies
YOUTUBE_CHANNEL_ID_751 = "PL3JwyBd7p0ZI6wn7Fk2_GeII8_VYky3CO" #Anime Films N Shorts

##@route(mode='action')
def Action():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir( 
		name="[COLOR white][B]Action Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_67+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Action Hero Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_69+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Action Adventure Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_70+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Action & Adventure[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_38+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns from Kisstube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_42+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Ultra Action Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_543+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Fight Area Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_544+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Rjval Fighting Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_545+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Kung Fu N Fight Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_546+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Alpha X War Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_547+"/", folder=True,
		icon=mediapath+"action.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

##@route(mode='animation')
def Animation():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Anime Films N Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_751+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]90s Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_750+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Animated Kids Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_87+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]80s Cartoon Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_88+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Anime 80s, 90s, 2k[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_83+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Movies: Anime[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_86+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Anime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_82+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Animation Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_567+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Cartoon Toonz Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_568+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Redwall Cartoon Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_569+"/", folder=True,
		icon=mediapath+"animation.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='classic')
def Classic():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Amazingly Classic Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_682+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movie Navigator Classics[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_688+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Manic Movie Classics[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_689+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]The Vintage Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_326+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Jagged Relief Movie Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_327+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Classic Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_328+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classix Flix Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_331+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]RBM Pictures Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_332+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mr. Spinks Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_333+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Classic Westerns Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_334+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Classic Cinema Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_335+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Retrospective Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_336+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic War Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drama by Popcorn Flix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_41+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Westerns from Kisstube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_42+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]Classic Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_18+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Mystery Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Timeless Film Noir[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_19+"/", folder=True,
		icon=mediapath+"classic.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='comedy')
def Comedy():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_37+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hallmark Romance Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_43+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Romance & Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_53+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Laurel N Hardy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_719+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jerry Lewis N Dean Martin[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_717+"/", folder=True,
		icon=mediapath+"comedy.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='crime')
def Crime():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery, Crime, Detectives[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_48+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]True Crime Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_66+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Crime Movies 30s-60s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_608+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]True Crime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_607+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Crime Movie Channel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_609+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reel Truth Crime[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_611+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Filmrise Crime Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_612+"/", folder=True,
		icon=mediapath+"crime.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='docs')
def Docs():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Space And The Universe Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_525+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Awesome Documentary Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_527+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Documentary Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_530+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Fifth Estate - Canada[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_532+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]BBC Dinosaur Documentaries[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_533+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Space Documentary Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_534+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music Documentary & Concerts[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_536+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Filmrise Documentary Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_537+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Truth Documentaries Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_539+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reel Truth Crime Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_540+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_24+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ghost Ships & Planes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nature Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_63+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PBS Nova Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_64+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Animal Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_65+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mysterious Universe[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Weird Or What Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery Docs: Yeti[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]True Crime Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_66+"/", folder=True,
		icon=mediapath+"docs.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)
	
#@route(mode='drama')
def Drama():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Drama by Popcorn Flix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_41+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic War & Drama[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_77+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drama & War Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_79+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drama Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_80+"/", folder=True,
		icon=mediapath+"drama.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='family')
def Family():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Cloud 5 Family Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_375+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhero Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_377+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kedoo ToonsTV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_378+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Westerns On The Web[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_379+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Wild West Toys Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_380+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Vids 4 Kids Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_381+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WB Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_382+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids Au Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_384+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fun Science For Kids[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_385+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_386+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Universal Kids Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_387+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lifetime Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_50+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Grjngo Westerns Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_684+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Western Mania Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_685+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns from Kisstube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_42+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hallmark Romance Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_43+"/", folder=True,
		icon=mediapath+"family.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='horror')
def Horror():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The Kings Of Horror[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_500+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Viewster Horror Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_503+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Terror Films Horror Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_505+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)		

	Add_Dir(
		name="[COLOR white][B]New Castle After Dark Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_506+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]A Touch Of Evil Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_508+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cinenet Horror Movie Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_510+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hammer & British Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_52+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_28+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ghoulish Grin Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_39+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Classic Horror Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_32+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_51+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Old Fun Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_35+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Horror/Scifi Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_30+"/", folder=True,
		icon=mediapath+"horror.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='movie_mix')
def Movie_Mix():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)
		
	Add_Dir(
		name="[COLOR white][B]Flick Vault Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_690+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Maverick Movie Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_683+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Movieholic Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_686+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Superhits Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_687+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The PopcornFlix Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_676+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Film Zone Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_677+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Bigtime Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_679+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Filmrise Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_680+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Viewster Movies Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_681+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Artflix Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_350+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Flixdome Movies Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_351+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]One Night At The Drive-in[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_353+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Timeless Classic Films[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_361+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Biscoot Hollywood Movies[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_354+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Channel 3 Youtube[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_355+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pizza Flix Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_356+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Drelbcom Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_359+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ampop Films Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_360+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Maverick Movie Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_54+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Romance & Comedy Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_53+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery, Crime, Detectives[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_48+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Movie Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_45+"/", folder=True,
		icon=mediapath+"movie_mix.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='music')
def Music():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Christian Music Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_59+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Rock Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_55+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Music Concert Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_56+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metal Rock Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_58+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mixed Genre Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_60+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movie Musicals[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_549+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Musicals[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_550+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Musical Flix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_551+"/", folder=True,
		icon=mediapath+"music.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

	
#@route(mode='scifi')
def Scifi():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Future Zone Movie Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_400+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Sci-fi TV Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_401+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mystery Science Theater 3000[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_404+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dust Sci-fi Shorts Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_405+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Barbarella X Sci-fi Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_406+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cheesy Scifi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_31+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Monster Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_51+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Science Fiction Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_27+"/", folder=True,
		icon=mediapath+"scifi.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='sports')
def Sports():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_74+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_76+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Sports Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_73+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Baseball Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_72+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ESPN Sports Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_46+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Football Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_75+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]LFL Full Length Games[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_71+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More: Sports Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_364+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More: Sports Flix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_365+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Sports: More Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_366+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Popcorn Flix Sports[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_367+"/", folder=True,
		icon=mediapath+"sports.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#@route(mode='toddlers')
def Toddlers():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Official Pat & Stan[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_271+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Tractor Tom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_272+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]HUMF Official[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_273+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Max & Ruby[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_274+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hoopla Kids Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_275+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TuTiTu TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_278+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Yo Gabba Gabba[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_279+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oh My Genius[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_294+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bananas In Pyjamas[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_283+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fifi & The Flowertots[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_284+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Postman Pat[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_285+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Olivia The Pig[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_286+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Little Charlie Bear[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_287+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]VeggieTales Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_288+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Strawberry Shortcake[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_289+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Noddy In Toyland[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_290+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ben & Holly Little Kingdom[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_291+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Kids Club[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_292+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Giggle Bellies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_293+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]Fluffy Jet Toys[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_295+"/", folder=True,
		icon=mediapath+"toddlers.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)
	
#@route(mode='western')
def Western():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Grjngo Westerns Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_684+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Western Mania Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_685+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westerns: John Wayne[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_188+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]English Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_189+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Western Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_190+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_191+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Westerns: More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_192+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Spaghetti Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_193+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Kisstube Westerns[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_187+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Classic Westerns Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_334+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Westerns On The Web[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_379+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Wild West Toys Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_380+"/", folder=True,
		icon=mediapath+"western.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#============================================================================================================================
	
#@route(mode='bfingers_playlists')
def Bfingers_Playlists():

	add_link_info('[B][COLORorange]== Butter Fingers ==[/COLOR][/B]', mediapath+'bfingers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]1930s Film Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_576+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1940s Film Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_577+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1940s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_578+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1950s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_581+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1950s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_582+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cheesy 1950s Sci-fi[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_583+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1950s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_584+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1960s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_585+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1960s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_586+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1960s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_587+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1970s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_588+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1970s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_590+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1970s Horror[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_591+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1970s Made For TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_593+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rare 1980s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_592+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1980s Sci-fi Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_595+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies: More 1980s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_596+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1980s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_597+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 1990s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_599+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More 1990s Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_600+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1990s Horror Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_601+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]1990s Sci-fi Horror[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_603+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies Of The 2000s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_604+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Movies In 2000s[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_605+"/", folder=True,
		icon=mediapath+"years.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'bfingers.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
