
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, os, sys

from resources.lib.modules.common import *
from resources.lib.modules.wrestlers import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.muzic')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
media = 'special://home/addons/script.j1.artwork/lib/resources/images/genres/'
mediapath = 'http://j1wizard.net/media/'

PL = "playlist/"
CH = "channel/"
US = "user/"
#====================================

channellist=[
        ("[COLOR white][B]WWE Matches, Moments, Segments[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8062, mediapath+'wwe.png'),
        ("[COLOR white][B]WWE: Championship Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8063, mediapath+'wwe.png'),
        ("[COLOR white][B]Full WWE Wrestling Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8064, mediapath+'wwe.png'),
        ("[COLOR white][B]WWE Full Wrestling Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8065, mediapath+'wwe.png'),
        ("[COLOR white][B]More WWE Wrestling Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8066, mediapath+'wwe.png'),
        ("[COLOR white][B]WWE And NXT Wrestling Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8067, mediapath+'wwe.png'),
        ("[COLOR white][B]WWE Wrestling And More[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8068, mediapath+'wwe.png'),
        ("[COLOR white][B]More Full WWE Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8069, mediapath+'wwe.png'),
        ("[COLOR white][B]Raw, Smackdown, And More[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8070, mediapath+'wwe.png'),
        ("[COLOR white][B]Everything WWE And NXT[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8071, mediapath+'wwe.png'),
        ("[COLOR white][B]Full Matches WWE Wrestling[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8072, mediapath+'wwe.png'),
        ("[COLOR white][B]WWE: More Wrestling Matches[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8073, mediapath+'wwe.png'),
        ("[COLOR white][B]WWE: Matches, Divas, And More[/B][/COLOR]", PL+YOUTUBE_CHANNEL_ID_8074, mediapath+'wwe.png'),
]

#=====================================

class wweMOD:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for title, id, thumbnail in channellist:     #sorted(channellist, reverse=False):
	        Add_Dir(name=title,url="plugin://plugin.video.youtube/"+id+"/",folder=True,icon=thumbnail,fanart=fanart)

#=====================================
