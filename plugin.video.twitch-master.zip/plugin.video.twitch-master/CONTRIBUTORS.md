
## Collaborators

<!-- readme: collaborators -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/MrSprigster">
            <img src="https://avatars.githubusercontent.com/u/6219686?v=4" width="100;" alt="MrSprigster"/>
            <br />
            <sub><b>MrSprigster</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/anxdpanic">
            <img src="https://avatars.githubusercontent.com/u/17665050?v=4" width="100;" alt="anxdpanic"/>
            <br />
            <sub><b>anxdpanic</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: collaborators -end -->

## Contributors

<!-- readme: contributors -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/anxdpanic">
            <img src="https://avatars.githubusercontent.com/u/17665050?v=4" width="100;" alt="anxdpanic"/>
            <br />
            <sub><b>anxdpanic</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/MrSprigster">
            <img src="https://avatars.githubusercontent.com/u/6219686?v=4" width="100;" alt="MrSprigster"/>
            <br />
            <sub><b>MrSprigster</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ccaspers">
            <img src="https://avatars.githubusercontent.com/u/2117023?v=4" width="100;" alt="ccaspers"/>
            <br />
            <sub><b>ccaspers</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/StateOfTheArt89">
            <img src="https://avatars.githubusercontent.com/u/1682868?v=4" width="100;" alt="StateOfTheArt89"/>
            <br />
            <sub><b>StateOfTheArt89</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/grocal">
            <img src="https://avatars.githubusercontent.com/u/896246?v=4" width="100;" alt="grocal"/>
            <br />
            <sub><b>grocal</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/weblate">
            <img src="https://avatars.githubusercontent.com/u/1607653?v=4" width="100;" alt="weblate"/>
            <br />
            <sub><b>weblate</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/ingwinlu">
            <img src="https://avatars.githubusercontent.com/u/4435962?v=4" width="100;" alt="ingwinlu"/>
            <br />
            <sub><b>ingwinlu</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/torstehu">
            <img src="https://avatars.githubusercontent.com/u/871220?v=4" width="100;" alt="torstehu"/>
            <br />
            <sub><b>torstehu</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/BtbN">
            <img src="https://avatars.githubusercontent.com/u/294293?v=4" width="100;" alt="BtbN"/>
            <br />
            <sub><b>BtbN</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/DimmKG">
            <img src="https://avatars.githubusercontent.com/u/8424428?v=4" width="100;" alt="DimmKG"/>
            <br />
            <sub><b>DimmKG</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/G4RL1N">
            <img src="https://avatars.githubusercontent.com/u/8591654?v=4" width="100;" alt="G4RL1N"/>
            <br />
            <sub><b>G4RL1N</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/apo86">
            <img src="https://avatars.githubusercontent.com/u/57818762?v=4" width="100;" alt="apo86"/>
            <br />
            <sub><b>apo86</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/CDehning">
            <img src="https://avatars.githubusercontent.com/u/4777216?v=4" width="100;" alt="CDehning"/>
            <br />
            <sub><b>CDehning</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ebod">
            <img src="https://avatars.githubusercontent.com/u/3525368?v=4" width="100;" alt="ebod"/>
            <br />
            <sub><b>ebod</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/KlingOne">
            <img src="https://avatars.githubusercontent.com/u/3019060?v=4" width="100;" alt="KlingOne"/>
            <br />
            <sub><b>KlingOne</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/stevensmedia">
            <img src="https://avatars.githubusercontent.com/u/4483829?v=4" width="100;" alt="stevensmedia"/>
            <br />
            <sub><b>stevensmedia</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/stevenroose">
            <img src="https://avatars.githubusercontent.com/u/853468?v=4" width="100;" alt="stevenroose"/>
            <br />
            <sub><b>stevenroose</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/stuross">
            <img src="https://avatars.githubusercontent.com/u/178643?v=4" width="100;" alt="stuross"/>
            <br />
            <sub><b>stuross</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/Oyuret">
            <img src="https://avatars.githubusercontent.com/u/1458128?v=4" width="100;" alt="Oyuret"/>
            <br />
            <sub><b>Oyuret</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/blddk">
            <img src="https://avatars.githubusercontent.com/u/544358?v=4" width="100;" alt="blddk"/>
            <br />
            <sub><b>blddk</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/disrupted">
            <img src="https://avatars.githubusercontent.com/u/4771462?v=4" width="100;" alt="disrupted"/>
            <br />
            <sub><b>disrupted</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/svms1">
            <img src="https://avatars.githubusercontent.com/u/6218137?v=4" width="100;" alt="svms1"/>
            <br />
            <sub><b>svms1</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/beastd">
            <img src="https://avatars.githubusercontent.com/u/4342576?v=4" width="100;" alt="beastd"/>
            <br />
            <sub><b>beastd</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/spiffomatic64">
            <img src="https://avatars.githubusercontent.com/u/6806506?v=4" width="100;" alt="spiffomatic64"/>
            <br />
            <sub><b>spiffomatic64</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/Blayr">
            <img src="https://avatars.githubusercontent.com/u/17113158?v=4" width="100;" alt="Blayr"/>
            <br />
            <sub><b>Blayr</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ccope">
            <img src="https://avatars.githubusercontent.com/u/412019?v=4" width="100;" alt="ccope"/>
            <br />
            <sub><b>ccope</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/dadobt">
            <img src="https://avatars.githubusercontent.com/u/5913204?v=4" width="100;" alt="dadobt"/>
            <br />
            <sub><b>dadobt</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Eng2Heb">
            <img src="https://avatars.githubusercontent.com/u/31464752?v=4" width="100;" alt="Eng2Heb"/>
            <br />
            <sub><b>Eng2Heb</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/alan7000">
            <img src="https://avatars.githubusercontent.com/u/7330585?v=4" width="100;" alt="alan7000"/>
            <br />
            <sub><b>alan7000</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Giacom">
            <img src="https://avatars.githubusercontent.com/u/1524810?v=4" width="100;" alt="Giacom"/>
            <br />
            <sub><b>Giacom</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/ha107642">
            <img src="https://avatars.githubusercontent.com/u/6672586?v=4" width="100;" alt="ha107642"/>
            <br />
            <sub><b>ha107642</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/vrokolos">
            <img src="https://avatars.githubusercontent.com/u/278046?v=4" width="100;" alt="vrokolos"/>
            <br />
            <sub><b>vrokolos</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/joelpurra">
            <img src="https://avatars.githubusercontent.com/u/1398544?v=4" width="100;" alt="joelpurra"/>
            <br />
            <sub><b>joelpurra</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Kr0nZ">
            <img src="https://avatars.githubusercontent.com/u/1561389?v=4" width="100;" alt="Kr0nZ"/>
            <br />
            <sub><b>Kr0nZ</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/lekma">
            <img src="https://avatars.githubusercontent.com/u/1482125?v=4" width="100;" alt="lekma"/>
            <br />
            <sub><b>lekma</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Tomalak">
            <img src="https://avatars.githubusercontent.com/u/28300?v=4" width="100;" alt="Tomalak"/>
            <br />
            <sub><b>Tomalak</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/mCzolko">
            <img src="https://avatars.githubusercontent.com/u/1011500?v=4" width="100;" alt="mCzolko"/>
            <br />
            <sub><b>mCzolko</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/kokarn">
            <img src="https://avatars.githubusercontent.com/u/1373940?v=4" width="100;" alt="kokarn"/>
            <br />
            <sub><b>kokarn</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Preovaleo">
            <img src="https://avatars.githubusercontent.com/u/6892913?v=4" width="100;" alt="Preovaleo"/>
            <br />
            <sub><b>Preovaleo</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/xsellier">
            <img src="https://avatars.githubusercontent.com/u/6616005?v=4" width="100;" alt="xsellier"/>
            <br />
            <sub><b>xsellier</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/astrilchuk">
            <img src="https://avatars.githubusercontent.com/u/1706688?v=4" width="100;" alt="astrilchuk"/>
            <br />
            <sub><b>astrilchuk</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/dnn1s">
            <img src="https://avatars.githubusercontent.com/u/8132941?v=4" width="100;" alt="dnn1s"/>
            <br />
            <sub><b>dnn1s</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/kravone">
            <img src="https://avatars.githubusercontent.com/u/1407288?v=4" width="100;" alt="kravone"/>
            <br />
            <sub><b>kravone</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/lucabric">
            <img src="https://avatars.githubusercontent.com/u/1241765?v=4" width="100;" alt="lucabric"/>
            <br />
            <sub><b>lucabric</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/markus80">
            <img src="https://avatars.githubusercontent.com/u/16596265?v=4" width="100;" alt="markus80"/>
            <br />
            <sub><b>markus80</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ntfwc">
            <img src="https://avatars.githubusercontent.com/u/441277?v=4" width="100;" alt="ntfwc"/>
            <br />
            <sub><b>ntfwc</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: contributors -end -->

## Founder of the add-on

<!-- readme: StateOfTheArt89 -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/stateoftheart89">
            <img src="https://avatars.githubusercontent.com/u/1682868?v=4" width="100;" alt="stateoftheart89"/>
            <br />
            <sub><b>stateoftheart89</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: StateOfTheArt89 -end -->

## Author of https://github.com/ingwinlu/python-twitch

<!-- readme: ingwinlu -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/ingwinlu">
            <img src="https://avatars.githubusercontent.com/u/4435962?v=4" width="100;" alt="ingwinlu"/>
            <br />
            <sub><b>ingwinlu</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: ingwinlu -end -->
