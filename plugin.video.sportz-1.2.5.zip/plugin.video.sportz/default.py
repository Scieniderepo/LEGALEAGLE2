
import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.sportz import *
from resources.lib.modules.scraper import *
from resources.lib.modules.common import *
from resources.lib.modules.showVID import *

params = get_params()
mode = None
    
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.sportz')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

#==========================================================================================================

def Main():

	add_link_info('[B][COLORorange]== Sportz ==[/COLOR][/B]', mediapath+'sportz.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Live Sports[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_3573+"/", folder=True,
		icon=mediapath+"LiveSports.png", fanart=mediapath+'fanart.jpg')

	addDirMain('[COLOR white][B]Wrestling Events[/B][/COLOR]',BASE,112,mediapath+'EventsSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Wrestling Shows[/B][/COLOR]',BASE,113,mediapath+'WrestleSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Wrestle Docs[/B][/COLOR]',BASE,111,mediapath+'DocWrestle.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports Docs[/B][/COLOR]',BASE,110,mediapath+'DocSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Game Sports[/B][/COLOR]',BASE,100,mediapath+'GameSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Motor Sports[/B][/COLOR]',BASE,101,mediapath+'motorsports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Euro Sports[/B][/COLOR]',BASE,103,mediapath+'eurosports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Womens Sports[/B][/COLOR]',BASE,104,mediapath+'WomensSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Combat Sports[/B][/COLOR]',BASE,109,mediapath+'combat.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]More Sports Docs[/B][/COLOR]',BASE,107,mediapath+'DocsSports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Wrestling[/B][/COLOR]',BASE,106,mediapath+'SportsWrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Womens Wrestling[/B][/COLOR]',BASE,105,mediapath+'WomansWrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Fishing[/B][/COLOR]',BASE,108,mediapath+'fishing.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports: Hunting[/B][/COLOR]',BASE,102,mediapath+'hunting.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'sportz.png', fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
		
#errorMsg="%s" % (mode)
#xbmcgui.Dialog().ok("mode", errorMsg)
 
#=======================================================

if mode == 100:
	GameSports()
		
elif mode == 101:
	Motorsports()		
		
elif mode == 102:
	Hunting()

elif mode == 103:
	Eurosports()
	
elif mode == 104:
	WomensSports()

elif mode == 105:
	WomensWrestling()

elif mode == 106:
	SportsWrestling()

elif mode == 107:
	Docs_sports()
	
elif mode == 108:
	Fishing()

elif mode == 109:
	Combat()

elif mode == 110:
	Listing.Genres("All","Sports")
	
elif mode == 111:
    Listing.Genres("All","Wrestling")
	
elif mode == 112:
    Listing.Genres("All","Events")
	
elif mode == 113:
    Listing.Genres("All","Genre")

#=======================================================

elif mode == 801:
		
	#errorMsg="%s" % (url)
	#xbmcgui.Dialog().ok("url", errorMsg)

	Common.getVID(url)

#=======================================================

elif mode is None:
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
