plugin.video.foxnews
================

Kodi Addon for Fox News website

Version 7.0.0 Initial version for Matrix