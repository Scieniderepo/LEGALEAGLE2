# Kodi Dramacool Henz Addon
A kodi addon that you can use to watch Asian Drama in Kodi Mediaplayer

# Screenshots
![Screen-Shot-1](https://github.com/henry-richard7/Kodi-Dramacool-Henz-Addon/raw/master/Screenshots/1.png)
![Screen-Shot-2](https://github.com/henry-richard7/Kodi-Dramacool-Henz-Addon/raw/master/Screenshots/2.png)
![Screen-Shot-3](https://github.com/henry-richard7/Kodi-Dramacool-Henz-Addon/raw/master/Screenshots/3.png)

# How does it work?
The addon just scrapes the drama from https://asianembed.io/ and displays it in kodi.

# How to use
* Download the zip from releases.
* Go to addons in kodi.
* Select Install From ZIP.
* Select the Zip File that you have downloaded.

## Donations

If you like my projects then consider making a small donation by clicking below button ^\_^
<br/>
[![](https://img.shields.io/badge/Donate-Paypal-blue?style=for-the-badge&logo=paypal)](https://www.paypal.com/paypalme/henryrics)
