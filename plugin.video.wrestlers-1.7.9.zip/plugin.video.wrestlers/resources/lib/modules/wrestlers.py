# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *

params = get_params()
mode = None

#===============================================================================

addon_id = xbmcaddon.Addon().getAddonInfo('id')
selfAddon = xbmcaddon.Addon(id=addon_id)

try:
    datapath= xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
except:
    datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.wrestlers')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

try:
    fanart = xbmcvfs.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmcvfs.translatePath(os.path.join(home, 'icon.png'))
except:
    fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmc.translatePath(os.path.join(home, 'channels.png'))

mediapath = 'http://j1wizard.net/media/'

#===============================================================================

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"

YOUTUBE_CHANNEL_ID_8001 = ""
YOUTUBE_CHANNEL_ID_8002 = "PLATP1LrJF2xgVUWVvWRJCb8PuZ4nF1W1A" #AIW Absolute Archives
YOUTUBE_CHANNEL_ID_8003 = "PLATP1LrJF2xhE2PS9jsBmokoYkpeFjxmV" #AIW Girls Night Out
YOUTUBE_CHANNEL_ID_8004 = "PLATP1LrJF2xhf2CFPQLRw_Ly_BK6LDP9w" #AIW Intergender Wrestling
YOUTUBE_CHANNEL_ID_8005 = "PL083823CA8E4BDD46"                 #AIW Intense TV
YOUTUBE_CHANNEL_ID_8006 = "PLATP1LrJF2xjOvPjPtIDe43tmCuYLmebl" #AIW Cleveland All Pro Wrestling
YOUTUBE_CHANNEL_ID_8007 = "PLXxd6kuGsAA4Rws2n23BdWJ0c4sqPA7wM" #Wrestling Society X
YOUTUBE_CHANNEL_ID_8008  = "PL31AB9FED3C24BB68"                #AAW Web Shows
YOUTUBE_CHANNEL_ID_8009 = "PL5zDuK5FLT0i9qD7FWMBUhRgT5TVYfAyD" #AAW Match Of The Week
YOUTUBE_CHANNEL_ID_8010 = "PL5zDuK5FLT0j7vch_aaTwNuuWBVrKGoHC" #AAW TV Episodes
YOUTUBE_CHANNEL_ID_8011 = "" #
YOUTUBE_CHANNEL_ID_8012 = "PL8E0FA09CCE5E073A"                 #APW Classics
YOUTUBE_CHANNEL_ID_8013 = "PL19776A842AB7536A"                 #APW Super Summer Series
YOUTUBE_CHANNEL_ID_8014 = "PL9F3B989CC2DECFA8"                 #APW Gym Wars S1
YOUTUBE_CHANNEL_ID_8015 = "PLFAC1BED3C15CB7F1"                 #APW Gym Wars S2
YOUTUBE_CHANNEL_ID_8016 = "PL658276A01B97A245"                 #APW Gym Wars S3
YOUTUBE_CHANNEL_ID_8017 = "PLrwU8ocj2I50NPzBAP3WzZWUgL3H2V_dd" #APW Gym Wars S4
YOUTUBE_CHANNEL_ID_8018 = "" #
YOUTUBE_CHANNEL_ID_8019 = "PLuirrQyElQ0RCJ45jJJnzoyZex-OWQanP" #AWF Mayday Madness
YOUTUBE_CHANNEL_ID_8020 = "PLuirrQyElQ0S2sem_hFdYyBK8o6qwzL9U" #AWF Crossfire
YOUTUBE_CHANNEL_ID_8021 = "PLuirrQyElQ0TRtem1EIkHr6ro3jJ0OHBu" #AWF Showcase
YOUTUBE_CHANNEL_ID_8022 = "" #
YOUTUBE_CHANNEL_ID_8023 = "PL08kPbxpEW4bJk10hfKlzfL5a52F3VRrV" #Misc: ESW Full Matches
YOUTUBE_CHANNEL_ID_8024 = "PL028DFF37566ECDDE"                 #Misc: IWC Full Matches
YOUTUBE_CHANNEL_ID_8025 = "PLle2hLmiUR-hsrFpvri8mxlrvogt5AjCb" #Misc: MCW Flashback Fridays
YOUTUBE_CHANNEL_ID_8026 = "PLoNbV6gdRhovhAmPJbec_YM9ysn7xAs93" #Misc: MFPW Network
YOUTUBE_CHANNEL_ID_8027 = "PLoNbV6gdRhosgY_6iBf4cxXOu2MyqcrmG" #Misc: The MFPW
YOUTUBE_CHANNEL_ID_8028 = "" #
YOUTUBE_CHANNEL_ID_8029 = "PLRUB0ydEGMFPwO839Ay-VPzAKihGCXptt" #PPW TV Championship Matches
YOUTUBE_CHANNEL_ID_8030 = "PLRUB0ydEGMFPOAI1ssuXXL-de6UB6LBom" #PPW Womens Championships
YOUTUBE_CHANNEL_ID_8031 = "PLRUB0ydEGMFNhH8LcJjkQUqvIMq-VrqK1" #PPW Tag Team Championships
YOUTUBE_CHANNEL_ID_8032 = "PLRUB0ydEGMFPWYXwCoeFwd997yvElx5ir" #PPW Heavyweight Championships
YOUTUBE_CHANNEL_ID_8033 = "PLRUB0ydEGMFNi5WXKk3U_vS4ejGzay-H1" #PPW No Limits Championships
YOUTUBE_CHANNEL_ID_8034 = "" #
YOUTUBE_CHANNEL_ID_8035 = "" #
YOUTUBE_CHANNEL_ID_8036 = "" #
YOUTUBE_CHANNEL_ID_8037 = "" #
YOUTUBE_CHANNEL_ID_8038 = "" #
YOUTUBE_CHANNEL_ID_8039 = "" #
YOUTUBE_CHANNEL_ID_8040 = "" #
YOUTUBE_CHANNEL_ID_8041 = ""
YOUTUBE_CHANNEL_ID_8042 = ""
YOUTUBE_CHANNEL_ID_8043 = "PLSWpYv_bOhw7SNLUrtddXcdEZ3OcuKwuc" #Indie Womens Matches
YOUTUBE_CHANNEL_ID_8044 = ""
YOUTUBE_CHANNEL_ID_8045 = "PLtAN6pxdpW4Ofrjpp0PwQE1KzHCN-W8iZ" #WWE Womens Matches
YOUTUBE_CHANNEL_ID_8046 = "PLd5i7MH1IK-XaRJB2qQk3lcAYOQdOLWwY" #Indie Womans Wrestling
YOUTUBE_CHANNEL_ID_8047 = ""
YOUTUBE_CHANNEL_ID_8048 = "PL9acBpmvhNsryiWTxFgIZC9EbFyEdMDkG" #WWE And NXT Womens Matches
YOUTUBE_CHANNEL_ID_8049 = "PLeEVBrTMHdSNbr4vtSc5eafH1dyw331Ba" #Best Womens Matches
YOUTUBE_CHANNEL_ID_8050 = ""
YOUTUBE_CHANNEL_ID_8051 = "PL4PYdqna41zcUh4EYhru8WLLd-I1REr46" #More: Womens Wrestling Matches
YOUTUBE_CHANNEL_ID_8052 = "PL9clXsLdIvqm7n-eu5aEHelm_NvaxVfBv" #Independent Womens Wrestling
YOUTUBE_CHANNEL_ID_8053 = "PLVy5nQwGUE4vXDEsQED7ZWm-xF2CXutNA" #More: Womens Matches
YOUTUBE_CHANNEL_ID_8054 = "PL26nK03MuWcD-uO2jzqIfllDsjVIHo3se" #Women Of TNA
YOUTUBE_CHANNEL_ID_8055 = "PLFBE78201C74B5A0E"                 #UK Womens Matches
YOUTUBE_CHANNEL_ID_8056 = "PLmdPopYzmrplKAA8O7j27pBe_-okGrafQ" #WWE Bra And Panties Matches
YOUTUBE_CHANNEL_ID_8057 = "" #
YOUTUBE_CHANNEL_ID_8058 = "" #
YOUTUBE_CHANNEL_ID_8059 = "" #
YOUTUBE_CHANNEL_ID_8060 = "" #
YOUTUBE_CHANNEL_ID_8061 = "" #
YOUTUBE_CHANNEL_ID_8062 = "PLQOJdrIdqhW3hB8EuTofununVfX0pBDPa" #WWE Matches, Moments, Segments
YOUTUBE_CHANNEL_ID_8063 = "PLRrCpwYbdXe_Q506LWw6zw1RWQk9fjqR0" #WWE: Championship Matches
YOUTUBE_CHANNEL_ID_8064 = "PLx3e32FQNG9YdX7mYbtcLi_tH_JWBnIj-" #Full WWE Wrestling Matches
YOUTUBE_CHANNEL_ID_8065 = "PLqC9EL1RBCwgxCsIbEgVOQ9fhE6ahMfSn" #WWE Full Wrestling Matches
YOUTUBE_CHANNEL_ID_8066 = "PLAfgWszLXPKKZ0llsIhm3Z9YdSvNq4-Jy" #More WWE Wrestling Matches
YOUTUBE_CHANNEL_ID_8067 = "PLzXU5E1b4sEATHpeG1xl5S3mGlWxnzWUR" #WWE And NXT Wrestling Matches
YOUTUBE_CHANNEL_ID_8068 = "PLarPoghTrqCM_gXZdwvaAypjoT3i85DWt" #WWE Wrestling And More
YOUTUBE_CHANNEL_ID_8069 = "PLYbcy5TOg9YoIsidjHrrSjDNi2oBRxYDf" #More Full WWE Matches
YOUTUBE_CHANNEL_ID_8070 = "PL3aWzXGYM-cIxdlXQN3PwXqITUfPBcAVn" #Raw, Smackdown, And More
YOUTUBE_CHANNEL_ID_8071 = "PLxeNGOzgTkpSlhOa_uBcA7aHgDnX8Dkui" #Everything WWE And NXT
YOUTUBE_CHANNEL_ID_8072 = "PLdSb6YVhXagMNl2Spt4MTp7BYyu5TDvqM" #Full Matches WWE Wrestling ???
YOUTUBE_CHANNEL_ID_8073 = "PLKLX1_yw8ReXLhs5ODFJrul8wBx95MJl3" #WWE: More Wrestling Matches 
YOUTUBE_CHANNEL_ID_8074 = "PLMeYCvv1jZ5RKwJo0ZduLAzUHBnP72GiR" #WWE: Matches, Divas, And More
YOUTUBE_CHANNEL_ID_8075 = "" #
YOUTUBE_CHANNEL_ID_8076 = "" #
YOUTUBE_CHANNEL_ID_8077 = "" #
YOUTUBE_CHANNEL_ID_8078 = "" #
YOUTUBE_CHANNEL_ID_8079 = "" #
YOUTUBE_CHANNEL_ID_8080 = "" #
YOUTUBE_CHANNEL_ID_8081 = "" #
YOUTUBE_CHANNEL_ID_8082 = "" #
YOUTUBE_CHANNEL_ID_8083 = "" #
YOUTUBE_CHANNEL_ID_8084 = "" #
YOUTUBE_CHANNEL_ID_8085 = "" #
YOUTUBE_CHANNEL_ID_8086 = "" #
YOUTUBE_CHANNEL_ID_8087 = "" #
YOUTUBE_CHANNEL_ID_8088 = "" #
YOUTUBE_CHANNEL_ID_8089 = "" #
YOUTUBE_CHANNEL_ID_8090 = "" #
YOUTUBE_CHANNEL_ID_8091 = "" #
YOUTUBE_CHANNEL_ID_8092 = "" #
YOUTUBE_CHANNEL_ID_8093 = "" #
YOUTUBE_CHANNEL_ID_8094 = "" #
YOUTUBE_CHANNEL_ID_8095 = "" #
YOUTUBE_CHANNEL_ID_8096 = "" #
YOUTUBE_CHANNEL_ID_8097 = "" #
YOUTUBE_CHANNEL_ID_8098 = "" #
YOUTUBE_CHANNEL_ID_8099 = "" #
YOUTUBE_CHANNEL_ID_8100 = "" #
YOUTUBE_CHANNEL_ID_8101 = "" #
YOUTUBE_CHANNEL_ID_8102 = "" #
YOUTUBE_CHANNEL_ID_8103 = "" #
YOUTUBE_CHANNEL_ID_8104 = "PL4HqUCfKObKgtyEGWZnASaCH0qVG5vyZd" #Hardcore: Wrestling Extreme
YOUTUBE_CHANNEL_ID_8105 = "PLF6JtbjTHfLKPGjJoTzNVSbbXLUrxvq3g" #I Quit, No DQ, Cage Match
YOUTUBE_CHANNEL_ID_8106 = "PL1ga3FvCwBgr1XPJLWWs8eaflNmAPqpg-" #Most Violent Matches
YOUTUBE_CHANNEL_ID_8107 = "PLUaUJIgR4uwVydcuBHgVMmib84wU8IGww" #Extreme Rules Matches
YOUTUBE_CHANNEL_ID_8108 = "PLAuDLTEMClpH8OxK_gGCTpq1ZH0eAhifz" #WWE Hardcore Street Fights
YOUTUBE_CHANNEL_ID_8109 = "PLcSwQ25Fl0yVxj-PVQoSHLZWBICeMDWuO" #Popular Tables Ladders
YOUTUBE_CHANNEL_ID_8110 = "PLSDDUhzpikTk4GZdMOIOSa7ghxahV-rqJ" #Steel Cage Matches
YOUTUBE_CHANNEL_ID_8111 = "PLeN0LMcySIpumCR_E-q9KB8mG3mQQ9Y9N" #Best Of Cage Matches Ever
YOUTUBE_CHANNEL_ID_8112 = "PLeN0LMcySIpt-0P1hRGb55iL3Us6SgVDh" #More Steel Cage Matches
YOUTUBE_CHANNEL_ID_8113 = "PL31AIbVp8UnjxA-BjgDH0tqV3VzN_CDvu" #WWE: Steel Cage Matches
YOUTUBE_CHANNEL_ID_8114 = "PLSDDUhzpikTm6z0tPnQ11Lq7WK_Yt9o5c" #Ladder Matches
YOUTUBE_CHANNEL_ID_8115 = "PLnq4y0PnPBYu2NWFtm9n8U0Kxnf0z1_dW" #WWE: TLC Matches
YOUTUBE_CHANNEL_ID_8116 = "PLeT0PCHsn8qYchCiqqQJN0ipoyZOhf7pe" #Tables Ladders Chairs
YOUTUBE_CHANNEL_ID_8117 = "PLcSwQ25Fl0yWJ9KBiIOP5EttX70myfyCs" #Popular TLC Matches
YOUTUBE_CHANNEL_ID_8118 = "" #
YOUTUBE_CHANNEL_ID_8119 = "" #
YOUTUBE_CHANNEL_ID_8120 = "" #
YOUTUBE_CHANNEL_ID_8121 = "" #
YOUTUBE_CHANNEL_ID_8122 = "" #
YOUTUBE_CHANNEL_ID_8123 = "" #
YOUTUBE_CHANNEL_ID_8124 = "" #
YOUTUBE_CHANNEL_ID_8125 = "" #
YOUTUBE_CHANNEL_ID_8126 = "" #
YOUTUBE_CHANNEL_ID_8127 = "PL53kKJBMWATdIPkA-8x6JXUhr8sE5zC9l" #ROH Throwback Thursday
YOUTUBE_CHANNEL_ID_8128 = "PL53kKJBMWATcFGQFDJeUHiV_hWzHb6TJw" #ROH Women Of Honor
YOUTUBE_CHANNEL_ID_8129 = "PL53kKJBMWATc3B9l7g65tXusV3F5nC1LK" #ROH Future Of Honor
YOUTUBE_CHANNEL_ID_8130 = "PLVJTeNTGVLAS6AfQr-P3AFlvqcPMogTf3" #ROH Full Matches
YOUTUBE_CHANNEL_ID_8131 = "PL-ZV3jb0LhLJZjygvojD04l0pEbSL_oOq" #Full ROH Matches
YOUTUBE_CHANNEL_ID_8132 = "PLeN0LMcySIpthoJv2hs7Sif5Td-3PHzDj" #Best ROH PPV Matches
YOUTUBE_CHANNEL_ID_8133 = "PL8cVQv887SU8IcYrsp8kyTGAPuOvLmfPp" #ROH Wrestling Matches
YOUTUBE_CHANNEL_ID_8134 = "PLKgxaFMBiByjIjuwjwQTZ0rV4OR5qF8Yv" #Ring Of Honor Matches
YOUTUBE_CHANNEL_ID_8135 = "PLWFKjwucZtO3LOv5K1soEfxL1NZoRImWZ" #R.O.H. Full Matches
YOUTUBE_CHANNEL_ID_8136 = "PLV-koloSNSqbuJ9cuUrC7VHSpcGknNt1N" #R.O.H Wrestling Matches
YOUTUBE_CHANNEL_ID_8137 = "PLDTodg3Ir4nkV4vruDIJ8oTcwUCkg6tVp" #ROH Old School Matches
YOUTUBE_CHANNEL_ID_8138 = "" #
YOUTUBE_CHANNEL_ID_8139 = "" #
YOUTUBE_CHANNEL_ID_8140 = "" #
YOUTUBE_CHANNEL_ID_8141 = "PLwzzNv6ZXzhE6mAi77Vxr5CDpQjjqDI6c" #TNA Impact Wrestling
YOUTUBE_CHANNEL_ID_8142 = "PLQOJdrIdqhW3bSbk9hzLLxGcPCyqsQQtP" #TNA Impact Full Matches
YOUTUBE_CHANNEL_ID_8143 = "PLcovtt7Bdo9OvxEgoKSbHIIdnlXmPCHi4" #TNA Impact Wrestling
YOUTUBE_CHANNEL_ID_8144 = "PLfMyxLDt3AL3RDf_BXUccO2BbT2BZXSdx" #TNA: More Impact Matches
YOUTUBE_CHANNEL_ID_8145 = "PLqUuiw4Ti8ejAKENB6rv-Xlph311UQDOd" #More TNA Impact Wrestling
YOUTUBE_CHANNEL_ID_8146 = "PLxeNGOzgTkpSjFhTAJuTOsMBrSaDVvuqm" #Full TNA Wrestling Matches
YOUTUBE_CHANNEL_ID_8147 = "PLXOUT0qRzAKEYaDpZuXynYt4gF9CCsZrx" #Full Matches From Impact
YOUTUBE_CHANNEL_ID_8148 = "PL__aOPh91sYQaWhJtieAwve0mh16Igz4J" #More TNA Wrestling Matches
YOUTUBE_CHANNEL_ID_8149 = "PLTrEmIPuU4VGbFe535mVAko6tsHCvq8JL" #Impact Wrestling Matches
YOUTUBE_CHANNEL_ID_8150 = "PL7piPrM9rj2zV-DKsvpu3xOIpc1ncPJx-" #More Impact Wrestling
YOUTUBE_CHANNEL_ID_8151 = "PLZuFgnu2RP0FBgkv00hTcwiB_qEjsk_s0" #Impact Wrestling
YOUTUBE_CHANNEL_ID_8152 = "" #
YOUTUBE_CHANNEL_ID_8153 = "" #
YOUTUBE_CHANNEL_ID_8154 = "" #
YOUTUBE_CHANNEL_ID_8155 = "" #
YOUTUBE_CHANNEL_ID_8156 = "" #
YOUTUBE_CHANNEL_ID_8157 = "" #
YOUTUBE_CHANNEL_ID_8158 = "" #
YOUTUBE_CHANNEL_ID_8159 = "PLeEVBrTMHdSNwTZGkyD81rkKhucIkAWev" #Best Pro Wrestling Docs
YOUTUBE_CHANNEL_ID_8160 = "PLVra6xST2ql3wjvkLhA7YJurqJO1EqBmS" #Wrestling Documentary
YOUTUBE_CHANNEL_ID_8161 = "PLNTRH86YJ3X4muXoM_l1z0EpAnexp38U7" #Wrestling Documentaries
YOUTUBE_CHANNEL_ID_8162 = "PLJvhNArd_uPTj1IIde7DbxjjXN40K9PyX" #Pro Wrestling Documentaries
YOUTUBE_CHANNEL_ID_8163 = "PLl0SteGFBMK9nX9BIubjZOEGarPInZkmU" #More Wrestling Documentary
YOUTUBE_CHANNEL_ID_8164 = "PLmR1K1XZbpMfcjo8ryf_nu1E8IOHFocs7" #Wrestling Docs
YOUTUBE_CHANNEL_ID_8165 = "PLsaAzwaJdGhlYmgxuHswbXo2EZS-kRgRN" #WWE: Documentaries
YOUTUBE_CHANNEL_ID_8166 = "PLGUfyenDKCIU9YZ2EVLROM68MlSFoK2sd" #More Wrestling Docs
YOUTUBE_CHANNEL_ID_8167 = "PLy5S0xRTmftkSVJxqshLbVA4PYbXJluw9" #More Wrestling Documentaries
YOUTUBE_CHANNEL_ID_8168 = "PLxYtSzq_1YsuFa4C-onL50mOwXQWCnAfN" #More Pro Wrestling Docs
YOUTUBE_CHANNEL_ID_8169 = "PLkI1tsG5O-KBtZ_m7MWoTRxMwScefldtY" #More: Wrestling Docs
YOUTUBE_CHANNEL_ID_8170 = "" #
YOUTUBE_CHANNEL_ID_8171 = "" #
YOUTUBE_CHANNEL_ID_8178 = "PLeN0LMcySIpuiIyZBwWMg7y7CBqwDSkKy" #Best ECW Matches Of All Time
YOUTUBE_CHANNEL_ID_8179 = "PLV3-HKCI9AGxkIsjZ8Z8FR07O-mxv-pZ9" #ECW Wrestling Extreme Rules
YOUTUBE_CHANNEL_ID_8180 = "PLdZlX4Tg8-2LPU4Awp6h8BgqhMviP9ABP" #ECW Wrestling Full Matches
YOUTUBE_CHANNEL_ID_8181 = "PLPX0CLUGl6qVtL35sLiNkm5jxqnBXVeSF" #ECW! Hardcore Wrestling
YOUTUBE_CHANNEL_ID_8182 = "PLGxxjqJ_YOB4_nkI5xs8shUC8wuyRryEo" #ECW Wrestling History Volt
YOUTUBE_CHANNEL_ID_8183 = "PLV3-HKCI9AGxkIsjZ8Z8FR07O-mxv-pZ9" #ECW Extreme Rules Matches
YOUTUBE_CHANNEL_ID_8184 = "" #
YOUTUBE_CHANNEL_ID_8185 = "" #
YOUTUBE_CHANNEL_ID_8186 = "" #
YOUTUBE_CHANNEL_ID_8187 = "" #

YOUTUBE_CHANNEL_ID_8210 = "PLpxGXQagvVrI5BTwhAxdLLCwf_2exNw2k" #WCW Full Matches
YOUTUBE_CHANNEL_ID_8211 = "PLK7R7eKV04-9dkjm_Q7nmf91TveyXSCnf" #WCW Greatest Matches
YOUTUBE_CHANNEL_ID_8212 = "PL5ssTEscHhCHantVbRTxe77sEhLAlfDJp" #WCW: Great Matches
YOUTUBE_CHANNEL_ID_8213 = "PL87B07C1E5AF00E6B"                 #The Best Of WCW
YOUTUBE_CHANNEL_ID_8214 = "PLaEq9uXMJGFR_y2V3v0lmb-9EnGBtaq9G" #WCW PPV And Matches
YOUTUBE_CHANNEL_ID_8215 = "PLThEXiOE-6RLTpgMw-uzhr0UiPWK_JlGH" #More WCW Matches
YOUTUBE_CHANNEL_ID_8216 = "" #
YOUTUBE_CHANNEL_ID_8217 = "" #
YOUTUBE_CHANNEL_ID_8218 = "" #
YOUTUBE_CHANNEL_ID_8219 = "" #
YOUTUBE_CHANNEL_ID_8220 = "" #
YOUTUBE_CHANNEL_ID_8221 = "" #
YOUTUBE_CHANNEL_ID_8222 = "" #
YOUTUBE_CHANNEL_ID_8223 = "" #
YOUTUBE_CHANNEL_ID_8224 = "" #
YOUTUBE_CHANNEL_ID_8225 = "" #
YOUTUBE_CHANNEL_ID_8226 = "" #
YOUTUBE_CHANNEL_ID_8227 = "" #
YOUTUBE_CHANNEL_ID_8228 = "" #
YOUTUBE_CHANNEL_ID_8229 = "" #
YOUTUBE_CHANNEL_ID_8230 = "" #
YOUTUBE_CHANNEL_ID_8231 = "" #
YOUTUBE_CHANNEL_ID_8232 = "" #
YOUTUBE_CHANNEL_ID_8233 = "" #
YOUTUBE_CHANNEL_ID_8234 = "" #
YOUTUBE_CHANNEL_ID_8235 = "" #
YOUTUBE_CHANNEL_ID_8236 = "" #
YOUTUBE_CHANNEL_ID_8237 = "" #
YOUTUBE_CHANNEL_ID_8238 = "" #
YOUTUBE_CHANNEL_ID_8239 = "CZWNews"                             #Combat Zone Wrestling
YOUTUBE_CHANNEL_ID_8240 = "" #
YOUTUBE_CHANNEL_ID_8241 = "" #
YOUTUBE_CHANNEL_ID_8242 = "" #
YOUTUBE_CHANNEL_ID_8243 = "" #
YOUTUBE_CHANNEL_ID_8244 = "" #
YOUTUBE_CHANNEL_ID_8245 = "" #
YOUTUBE_CHANNEL_ID_8246 = "" #
YOUTUBE_CHANNEL_ID_8247 = "" #
YOUTUBE_CHANNEL_ID_8248 = "" #
YOUTUBE_CHANNEL_ID_8249 = "" #
YOUTUBE_CHANNEL_ID_8250 = "" #
YOUTUBE_CHANNEL_ID_8251 = "" #
YOUTUBE_CHANNEL_ID_8252 = "" #
YOUTUBE_CHANNEL_ID_8253 = "" #
YOUTUBE_CHANNEL_ID_8254 = "" #
YOUTUBE_CHANNEL_ID_8255 = "" #
YOUTUBE_CHANNEL_ID_8256 = "" #
YOUTUBE_CHANNEL_ID_8257 = "" #
YOUTUBE_CHANNEL_ID_8258 = "PLGHdAAsK8XE6uiRKkSBFmawzLwE6gTE7P" #Wrestlers: The Undertaker
YOUTUBE_CHANNEL_ID_8259 = "PLj-9PxvNNgliq0sFqFHwjErWAWjJdo7Kr" #Wrestlers: The Big Red Machine
YOUTUBE_CHANNEL_ID_8260 = "PLTrEmIPuU4VGaOtNRK3ww23dxQwaMgg9D" #Wrestlers: Stone Cold Steve Austin
YOUTUBE_CHANNEL_ID_8261 = "PL1-KdXHrzLtZm3B0n7W2kPkdhGQqhGPmF" #Wrestlers: Best Of Mick Foley
YOUTUBE_CHANNEL_ID_8262 = "PL_GBqjdd4KXqGJ03nkN7O6N9y3tQ_BqfA" #Wrestlers: Shaun Michaels Matches
YOUTUBE_CHANNEL_ID_8263 = "PLVDDXa6zQbnCwW5qfVMkZyR2oaCGLOekI" #Wrestlers: The Rock Matches And Video
YOUTUBE_CHANNEL_ID_8264 = "PLRsHo3gshLi0d1DmkOMKvhAX6p9lN5fa2" #Wrestlers: Triple H Matches
YOUTUBE_CHANNEL_ID_8265 = "PLULxp169LmWk9DWSTEx8eAjjlmCvdQ5aQ" #Wrestlers: Bret The Hitman Hart
YOUTUBE_CHANNEL_ID_8266 = "PLBWCFQsZmG3W0XwZhW6JUP3I4-v8kgKa5" #Wrestlers: Sting Matches And More
YOUTUBE_CHANNEL_ID_8267 = "PLdhebEs-cmOG89Z9Z0IkszP_kw8l2qmUl" #Wrestlers: The Ultimate Warrior
YOUTUBE_CHANNEL_ID_8268 = "PLwRWsCbjWQdtrQ_TTVkhZIZjzJroed7m5" #Wrestlers: Andre The Giant Matches
YOUTUBE_CHANNEL_ID_8269 = "PLR-NU0YqzppYK8-JKafwjwuOIYBuAdlR8" #Wrestlers: Hulk Hogan Matches
YOUTUBE_CHANNEL_ID_8270 = "PL2QBKOwUwpDYTeNo9OpFTKueZCg7dsHr6" #Wrestlers: Macho Man Randy Savage
YOUTUBE_CHANNEL_ID_8271 = "PLLlSXH0MjNBonA67ZClCWamSD0PeUuLRt" #Wrestlers: Rowdy Roddy Piper Matches
YOUTUBE_CHANNEL_ID_8272 = "PLcCbA51-Mlf97a60pQQ74hH7GvcPCQa4D" #Wrestlers: Ric Flair Matches And More
YOUTUBE_CHANNEL_ID_8273 = "PLGgp3IrZnXOvJEaAj9Lff1SJKgtBnkseu" #Wrestlers: Randy Orton Matches
YOUTUBE_CHANNEL_ID_8274 = "PLVDDXa6zQbnAfAes1w3tzq0fSJ0p7MqO4" #Wrestlers: Kurt Angle Matches
YOUTUBE_CHANNEL_ID_8275 = "PLA0A4E25578FE0AD7"                 #Wrestlers: Jake The Snake Roberts
YOUTUBE_CHANNEL_ID_8276 = "PLrlr3xcpr9PgpVvLmSPpbTE2_2LKvSULz" #Wrestlers: Owen Hart Matches
YOUTUBE_CHANNEL_ID_8277 = "PLcCbA51-Mlf9yzMnjXkCtUxyZRA955NWj" #Wrestlers: Dusty Rhodes Matches
YOUTUBE_CHANNEL_ID_8278 = "PL7I7pzJy0dkhFbZqUmNJUzlIMt4iKfupL" #Wrestlers: Bruno Sammartino Matches
YOUTUBE_CHANNEL_ID_8279 = "PL7I7pzJy0dkh_IppMfAjioTXXfeWIBvkl" #Wrestlers: Ernie The Big Cat Ladd
YOUTUBE_CHANNEL_ID_8280 = "PLXtM_kiOHdYIYAlHxBig4h-NlUpKsJFG2" #Wrestlers: Bruttus The Barber Beefcake
YOUTUBE_CHANNEL_ID_8281 = "PL_GLnfj37MzOVhJj_OKmVQYjS-iLvH2hP" #Wrestlers: Eddie Guerrero Matches
YOUTUBE_CHANNEL_ID_8282 = "PL7VU1TErAoef32Bu3X3zVqxhe9foNwrAU" #Wrestlers: Bob Backlund Matches
YOUTUBE_CHANNEL_ID_8283 = "PLHpnLBwS7sKZklorBvaWC95oRLuMdk8nf" #Wrestlers: Goldberg WWE-WCW Matches
YOUTUBE_CHANNEL_ID_8284 = "" #
YOUTUBE_CHANNEL_ID_8285 = "" #
YOUTUBE_CHANNEL_ID_8286 = "" #
YOUTUBE_CHANNEL_ID_8287 = "" #
YOUTUBE_CHANNEL_ID_8288 = "" #
YOUTUBE_CHANNEL_ID_8289 = "" #
YOUTUBE_CHANNEL_ID_8290 = "" #
YOUTUBE_CHANNEL_ID_8291 = "" #
YOUTUBE_CHANNEL_ID_8292 = "" #
YOUTUBE_CHANNEL_ID_8293 = "" #
YOUTUBE_CHANNEL_ID_8294 = "" #
YOUTUBE_CHANNEL_ID_8295 = "" #
YOUTUBE_CHANNEL_ID_8296 = "" #
YOUTUBE_CHANNEL_ID_8297 = "" #
YOUTUBE_CHANNEL_ID_8298 = "" #
YOUTUBE_CHANNEL_ID_8299 = "" #
YOUTUBE_CHANNEL_ID_8300 = "PLILTWWX_AIJTCAJrwbQMYaYJbSqowoNfc" #AEW Dynamite Highlights
YOUTUBE_CHANNEL_ID_8301 = "PLILTWWX_AIJStGnLbJEo9Myk-HdgWr7cL" #AEW Dark Episodes
YOUTUBE_CHANNEL_ID_8302 = "" #
YOUTUBE_CHANNEL_ID_8303 = "" #




YOUTUBE_CHANNEL_ID_8470 = "" #
YOUTUBE_CHANNEL_ID_8471 = "" #
YOUTUBE_CHANNEL_ID_8472 = "" #
YOUTUBE_CHANNEL_ID_8473 = "" #
YOUTUBE_CHANNEL_ID_8474 = "" #
YOUTUBE_CHANNEL_ID_8475 = "" #
YOUTUBE_CHANNEL_ID_8476 = "" #
YOUTUBE_CHANNEL_ID_8477 = "" #
YOUTUBE_CHANNEL_ID_8478 = "" #
YOUTUBE_CHANNEL_ID_8479 = "" #
YOUTUBE_CHANNEL_ID_8480 = "" #
YOUTUBE_CHANNEL_ID_8481 = "" #
YOUTUBE_CHANNEL_ID_8482 = "" #
YOUTUBE_CHANNEL_ID_8483 = "" #
YOUTUBE_CHANNEL_ID_8484 = "" #
YOUTUBE_CHANNEL_ID_8485 = "" #
YOUTUBE_CHANNEL_ID_8486 = "WrestleCade"              #Wrestlecade Channel
YOUTUBE_CHANNEL_ID_8487 = "VTWWRESTLINGROCKS"        #VTW Wrestling Channel
YOUTUBE_CHANNEL_ID_8488 = "UCO2O-PtF3pSmZefY97YvLDQ" #New Focus Wrestling Channel
YOUTUBE_CHANNEL_ID_8489 = "UKWwrestlingTV"           #UKW Wrestling TV Channel
YOUTUBE_CHANNEL_ID_8490 = "ICWOnline"                #Insane Championship Wrestling
YOUTUBE_CHANNEL_ID_8491 = "UCM66j6AFtnUhzJRovyB1qaw" #Empire Underground Wrestling
YOUTUBE_CHANNEL_ID_8492 = "UCHLJDHeMkOS1j6wjQMkNT6A" #Ignite Wrestling Channel
YOUTUBE_CHANNEL_ID_8493 = "PWAMedia"                 #PWA Canada Wrestling
YOUTUBE_CHANNEL_ID_8494 = "UCegZ3lASNXQ9dgCXKrRSRqg" #ECPW Adrenaline Wrestling
YOUTUBE_CHANNEL_ID_8495 = "UCIBZ6AE4TLbxXT84lO9pzBg" #Slam Wrestling Channel
YOUTUBE_CHANNEL_ID_8496 = "UCDBuRdEZfuhauqANa_i2_tg" #NGJPW Backyard Wrestling
YOUTUBE_CHANNEL_ID_8497 = "UCVb8PPxFpFnFGLdtGRUDKqQ" #NGW UK Wrestling Channel
YOUTUBE_CHANNEL_ID_8498 = "HighImpactOnlineTV"       #High Impact Wrestling 
YOUTUBE_CHANNEL_ID_8499 = "UCA-Ii7S_ejI9n7Aaz-W-HCw" #Cross Body Pro Academy
YOUTUBE_CHANNEL_ID_8500 = "UCfVpWzrE8B95_y3HupRyrkA" #AAW Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8501 = "UC4_HNKg_uDiGlVBnVbJTdYQ" #Womans Wrestling Revolution
YOUTUBE_CHANNEL_ID_8502 = "UCaN1vfY2wREOeV-oUB4KQ4g" #Pro Wrestling Guerrilla
YOUTUBE_CHANNEL_ID_8503 = "UCSafF4n61XE0JfyjS0TSv0Q" #Anarchy Championship Wrestling
YOUTUBE_CHANNEL_ID_8504 = "UCGab5jWe6gD8WyKWe9Q_TgA" #Attack Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8505 = "UCV2IP5RtH316GVHwuJB4l2Q" #WCW Womens Wrestling Classics
YOUTUBE_CHANNEL_ID_8506 = "UCFwWvXF6zia68-wy2ke7QeA" #Chaotic Wrestling Channel
YOUTUBE_CHANNEL_ID_8507 = "UCsSTZ3VyKsJeOXNjfz5bnuQ" #Innovate Wrestling Channel
YOUTUBE_CHANNEL_ID_8508 = "UCVZLUHBlQDfwbJunu050xDg" #New Wave Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8509 = "UCmimqM7Mo-FGbqsZULfsj6g" #CZW Wrestling Channel
YOUTUBE_CHANNEL_ID_8510 = "UCK7dW1mtFn9sx6ebFhCBdBw" #CZW Dojowars Channel
YOUTUBE_CHANNEL_ID_8511 = "UCOe-yFWWtWMC9YHoJAK0X1g" #Dragon Gate Pro Channel
YOUTUBE_CHANNEL_ID_8512 = "UCY4kveQR3srBEO6tp3xrHtQ" #Empire Wrestling Federation
YOUTUBE_CHANNEL_ID_8513 = "lpwainc"                  #All Women Wrestling Channel
YOUTUBE_CHANNEL_ID_8514 = "UCqcgTn7iAQs7gizmmxyVCYQ" #Freelance Wrestling Channel
YOUTUBE_CHANNEL_ID_8515 = "UCPRLQXM3ScRHllwExnbji8g" #House Of Bricks Pro Wrestling
YOUTUBE_CHANNEL_ID_8516 = "UCdqKACboxLhx0k5ZQFruG_A" #Future Stars Of Wrestling
YOUTUBE_CHANNEL_ID_8517 = "UCqXUtnXG62ReZZwxzIyu1yw" #Gold Rush Pro Wrestling
YOUTUBE_CHANNEL_ID_8518 = "UCBYGxShzjL_L7wbmzl1gfxQ" #World League Wrestling Channel
YOUTUBE_CHANNEL_ID_8519 = "UC9oHZXq6XVLvYZgc9SnzglQ" #House Of Hardcore Channel
YOUTUBE_CHANNEL_ID_8520 = "UCNS9QyhI7mlJr7Bs7e96H-A" #World Association Of Wrestling
YOUTUBE_CHANNEL_ID_8521 = "UCN6bAK93VslDZWVzjmXrLzw" #International Pro Wrestling
YOUTUBE_CHANNEL_ID_8522 = "UC3lOpKjW4_j4PGXWLNTt4iQ" #CMLL Wrestling Channel
YOUTUBE_CHANNEL_ID_8523 = "UCpOxiFW6ZxJ1-eD2q-WOBEg" #IWF Wrestling Channel
YOUTUBE_CHANNEL_ID_8524 = "UCTOMMSa2WpM1pOkXptsFJCg" #Premiere Wrestling Xperience
YOUTUBE_CHANNEL_ID_8525 = "UCHmdlxdFuumrHfLTp76TnWQ" #Keystone State Wrestling Alliance
YOUTUBE_CHANNEL_ID_8526 = "SHINEWrestling"           #Shine Womans Wrestling Channel
YOUTUBE_CHANNEL_ID_8527 = "UCCriLuKqcuYiEYEFR26nqig" #All Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8528 = "UCPHMctj7gnb5zA5iuzUshAA" #MCW Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8529 = "UCxPLqL8MxuAUveJZ1r3QRdQ" #National Wrestling League
YOUTUBE_CHANNEL_ID_8530 = "UCHXBm9pnQ89R1dYNf0MIAKA" #Preston City Wresling Channel
YOUTUBE_CHANNEL_ID_8531 = "UCb3vOGBxTJxIwFyBkdOiksA" #New European Championship Wrestling
YOUTUBE_CHANNEL_ID_8532 = "TitleMatchWrestling"      #Title Match Wrestling Channel
YOUTUBE_CHANNEL_ID_8533 = "UC3dvdVY1LHZuMP03GTvBeUg" #United Wrestling Coalition
YOUTUBE_CHANNEL_ID_8534 = "UCYOQrveFEmmRnFzIPlFnJFQ" #WWE Classic HD Wrestling Channel
YOUTUBE_CHANNEL_ID_8535 = "UCWt0mXTlQpQwJV-ZzHE6c2Q" #Paragon Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8536 = "UCq--5BijW932u7PN4WNfHRA" #Westside Xtreme Wrestling
YOUTUBE_CHANNEL_ID_8537 = "UCL-IRQy9_2vcorvGsDqpt0w" #Ultra Championship Wrestling Zero
YOUTUBE_CHANNEL_ID_8538 = "UCTz1galXrnjN40Y5kwQRO9A" #Womens Wrestling Video Channel
YOUTUBE_CHANNEL_ID_8539 = "UCVYYso8bd96TXBeFglh1XYw" #New England Championship Wrestling
YOUTUBE_CHANNEL_ID_8540 = "ProWrestlingEVE"          #EVE Womens Wrestling Channel
YOUTUBE_CHANNEL_ID_8541 = "UCZaS14idYb591IbxLqcyNQA" #Progress Wrestling Channel
YOUTUBE_CHANNEL_ID_8542 = "UCsI_f3U8cLIvzDNKsI0FXRw" #Jersey All Pro Wrestling
YOUTUBE_CHANNEL_ID_8543 = "UCTNT9N8pIx1Q4vgVwZHObkQ" #Rockstar Pro Wrestling
YOUTUBE_CHANNEL_ID_8544 = "UC4F0NNPiR-inhW8oMp0dujQ" #Rocky Mountain Pro Wrestling
YOUTUBE_CHANNEL_ID_8545 = "UC30Ia39JmGJASWQSyQOQYAQ" #Shimmer Wrestling Channel
YOUTUBE_CHANNEL_ID_8546 = "UCzE_STJfNMe3KKQLTrP3rYg" #Full Impact Pro Channel
YOUTUBE_CHANNEL_ID_8547 = "UC_3yt61rzKZgjhyrLi-lU8A" #Southern States Wrestling
YOUTUBE_CHANNEL_ID_8548 = "UCqjt59YsM4JlcnMjxwSbNSw" #IWA Mid South Wrestling
YOUTUBE_CHANNEL_ID_8549 = "UCLm7jUPKpOw-dz2LvGtV3rA" #Top Rope Promotions Channel
YOUTUBE_CHANNEL_ID_8550 = "BritishBombshells"        #British Bombshells Wrestling
YOUTUBE_CHANNEL_ID_8551 = "UCdwEl3-QFixMQW2IzWjdhpw" #Total Womens Wrestling Channel
YOUTUBE_CHANNEL_ID_8552 = "WrestlingDivaz"           #Wrestling Divaz Channel
YOUTUBE_CHANNEL_ID_8553 = "vipguide"                 #United Wrestling Network
YOUTUBE_CHANNEL_ID_8554 = "chrisidolrocks"           #WCF Wrestling Channel
YOUTUBE_CHANNEL_ID_8555 = "jstep009"                 #Vanguard Championship Wrestling
YOUTUBE_CHANNEL_ID_8556 = "doaprowrestling"          #DOA Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8557 = "UCSHCTJS2P4Hvu_reLKtiT6g" #NWA: National Wrestling Alliance
YOUTUBE_CHANNEL_ID_8558 = "ringofhonor"              #Ring Of Honor Wrestling Channel
YOUTUBE_CHANNEL_ID_8559 = "majorleaguewrestling"     #Major League Wrestling Channel
YOUTUBE_CHANNEL_ID_8560 = "WWEFanNation"             #WWE Official Channel
YOUTUBE_CHANNEL_ID_8561 = "UCFN4JkGP_bVhAdBsoV9xftA" #All Elite Wrestling Channel
YOUTUBE_CHANNEL_ID_8562 = "TNAwrestling"             #Impact Wrestling Channel
YOUTUBE_CHANNEL_ID_8563 = "UCFAA7NmLmwcL9bbX_gXEV0g" #Evolve Wrestling Channel
YOUTUBE_CHANNEL_ID_8564 = "UCzaW5OsUJKVrofaK0303Yqg" #Revolution Pro Wrestling
YOUTUBE_CHANNEL_ID_8565 = "UC1lgJkpCx_0SMzsvrTCdxPw" #New Japan Pro Wrestling
YOUTUBE_CHANNEL_ID_8566 = "GFWWrestling"             #Global Force Wrestling
YOUTUBE_CHANNEL_ID_8567 = "EmpireStateWrestling"     #Empire State Wrestling
YOUTUBE_CHANNEL_ID_8568 = "UC4FgPd4vwU69mqZuBYst0NQ" #Premier Pro Wrestling
YOUTUBE_CHANNEL_ID_8569 = "NWASmokyMtn"              #NWA Smokey Mountain
YOUTUBE_CHANNEL_ID_8570 = "TheBookerTROW"            #Reality Of Wrestling
YOUTUBE_CHANNEL_ID_8571 = "luchalibreaaatv"          #Lucha Libre AAA TV Channel
YOUTUBE_CHANNEL_ID_8572 = "UCy91SdPgEDZnCHHm5ag32yQ" #Beyond Wrestling Channel
YOUTUBE_CHANNEL_ID_8573 = "UCnoxa_lxzuctg5MvZPNvU4Q" #Lucha Britannia Channel
YOUTUBE_CHANNEL_ID_8574 = "UCxe8W_ByYbQHmsmCmd2Ov4w" #PWA Ohio Wrestling Channel
YOUTUBE_CHANNEL_ID_8575 = "UCHqemBGAZ5j5DVVdkj2KvvQ" #Over The Top Wrestling Channel
YOUTUBE_CHANNEL_ID_8576 = "UCCbMQBiZovHmssEUu_OZjrg" #Chikara Wrestling Channel
YOUTUBE_CHANNEL_ID_8577 = "UC7Oa9QXaOocvPF3STnl9vrw" #Capitol Wrestling Channel
YOUTUBE_CHANNEL_ID_8578 = "UCbP2Y0iw314ShQVfgklJF_A" #Dominating Backyard Wrestling
YOUTUBE_CHANNEL_ID_8579 = "discoverywrestling"       #Discovery Wrestling Channel
YOUTUBE_CHANNEL_ID_8580 = "UCw8fAQ659cF3pgNUeY5kJLw" #Primos Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8581 = "UC2nbUh4nD_ozXOmeLgMRicw" #Best Of The West Wrestling
YOUTUBE_CHANNEL_ID_8582 = "StLouisWrestling"         #Saint Louis Wrestling
YOUTUBE_CHANNEL_ID_8583 = "UCBZ2Hl4YPU0Dzxuj3a3qSQw" #Defy Wrestling Channel
YOUTUBE_CHANNEL_ID_8584 = "OfficialPPW"              #Pure Power Wrestling
YOUTUBE_CHANNEL_ID_8585 = "melbcitywrestling"        #Melbourne City Wrestling
YOUTUBE_CHANNEL_ID_8586 = "IHWE2009"                 #IHWE Professional Wrestling
YOUTUBE_CHANNEL_ID_8587 = "UC8ghcJUjZfy2M6Pqb7gQ0Dg" #UK Wrestling Media TV
YOUTUBE_CHANNEL_ID_8588 = "Houseofglory1"            #House Of Glory Wrestling
YOUTUBE_CHANNEL_ID_8589 = "EvoProWrestling1"         #Evolution Pro Wrestling
YOUTUBE_CHANNEL_ID_8590 = "THERISEONLINE"            #Rise Underground Pro
YOUTUBE_CHANNEL_ID_8591 = "SmashWrestling1"          #Smash Wrestling Channel
YOUTUBE_CHANNEL_ID_8592 = "pwaaustralia"             #Pro Wrestling Australia
YOUTUBE_CHANNEL_ID_8593 = "UC5AJlsjiUQSgeuWpjssfilw" #Appalachian Mountain Wrestling
YOUTUBE_CHANNEL_ID_8594 = "UCpWXclNuk4mk_HXut3DJb5Q" #PCW Ultra Channel
YOUTUBE_CHANNEL_ID_8595 = "UCtSDJw6lzjP1rzn3LI8OByA" #Pure Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8596 = "UCJGCEpUV9KYD0wD8nOU8CRQ" #Championship Wrestling Channel
YOUTUBE_CHANNEL_ID_8597 = "WrestlingGWF"             #German Wrestling Federation
YOUTUBE_CHANNEL_ID_8598 = "UCdzJRXdxJI8btJQg8MY9ZeQ" #Viral Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8599 = "FIGHTProWrestling"        #Fight Pro Wrestling Channel
YOUTUBE_CHANNEL_ID_8600 = "UCAL2gV3VA1q1IB3_t4u4XtQ" #Continental Championship Wrestling
YOUTUBE_CHANNEL_ID_8601 = "UCYRgvgzfoDKQK8XIsI-hvpQ" #Big B Pro Wrestling
YOUTUBE_CHANNEL_ID_8602 = "" #
YOUTUBE_CHANNEL_ID_8603 = "" #
YOUTUBE_CHANNEL_ID_8604 = "" #
YOUTUBE_CHANNEL_ID_8605 = "" #
YOUTUBE_CHANNEL_ID_8606 = "" #
YOUTUBE_CHANNEL_ID_8607 = "" #
YOUTUBE_CHANNEL_ID_8608 = "" #
YOUTUBE_CHANNEL_ID_8609 = "" #
YOUTUBE_CHANNEL_ID_8610 = "" #

YOUTUBE_CHANNEL_ID_8878 = "" #
YOUTUBE_CHANNEL_ID_8879 = "" #
YOUTUBE_CHANNEL_ID_8880 = "" #
YOUTUBE_CHANNEL_ID_8881 = "" #
YOUTUBE_CHANNEL_ID_8882 = "" #
YOUTUBE_CHANNEL_ID_8883 = "" #
YOUTUBE_CHANNEL_ID_8884 = "" #
YOUTUBE_CHANNEL_ID_8885 = "" #
YOUTUBE_CHANNEL_ID_8886 = "" #
YOUTUBE_CHANNEL_ID_8887 = "" #
YOUTUBE_CHANNEL_ID_8888 = "" #
YOUTUBE_CHANNEL_ID_8889 = "" #
YOUTUBE_CHANNEL_ID_8890 = "" #
YOUTUBE_CHANNEL_ID_8891 = "" #
YOUTUBE_CHANNEL_ID_8892 = "" #
YOUTUBE_CHANNEL_ID_8893 = "" #
YOUTUBE_CHANNEL_ID_8894 = "" #
YOUTUBE_CHANNEL_ID_8895 = "" #
YOUTUBE_CHANNEL_ID_8896 = "" #
YOUTUBE_CHANNEL_ID_8897 = "" #
YOUTUBE_CHANNEL_ID_8898 = "" #
YOUTUBE_CHANNEL_ID_8899 = "" #
YOUTUBE_CHANNEL_ID_8900 = "" #


#@route(mode='w_channels')
def W_channels():

	mode='w_channels'
	
	add_link_info('[B][COLORorange]== Wrestling Channels ==[/COLOR][/B]', mediapath+'wrestlers.png', fanart)


	Add_Dir(
		name="[COLOR white][B]WWE Official Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8560+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Elite Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8561+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ring Of Honor Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8558+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Impact Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8562+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NWA Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8557+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PCW Ultra Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8594+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Major League Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8559+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Japan Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8565+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Global Force Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8566+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Evolve Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8563+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reality Of Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8570+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Revolution Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8564+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Title Match Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8532+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]British Bombshells Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8550+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Women Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8513+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WCW Womens Wrestling Classics[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8505+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shine Womans Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8526+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womens Wrestling Video Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8538+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shimmer Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8545+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Womans Wrestling Revolution[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8501+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]EVE Womens Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8540+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Total Womans Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8551+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Divaz Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8552+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lucha Libre AAA Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8571+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lucha Britannia Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8573+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Consejo Mundial de Lucha Libre[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8522+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8527+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Championship Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8596+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Guerrilla[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8502+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Progress Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8541+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Over The Top Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8575+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]German Wrestling Federation[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8597+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Future Stars Of Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8516+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Classic HD Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8534+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestlecade Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8486+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]CZW Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8509+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]CZW Dojowars Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8510+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]House Of Hardcore Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8519+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Westside Xtreme Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8536+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dragon Gate Pro Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8511+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chikara Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8576+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Innovate Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8507+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]National Wrestling League[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8529+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Freelance Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8514+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Viral Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8598+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fight Pro Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8599+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Continental Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8600+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Big B Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8601+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paragon Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8535+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Premiere Wrestling Xperience[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8524+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]United Wrestling Coalition[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8533+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]International Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8521+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Premier Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8568+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Anarchy Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8503+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Attack Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8504+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Beyond Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8572+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Chaotic Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8506+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Top Rope Promotions Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8549+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ultra Championship Wrestling Zero[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8537+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Wave Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8508+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Impact Pro Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8546+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AAW Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8500+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cross Body Pro Wrestling Academy[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8499+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IWF Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8523+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World Association Of Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8520+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]MCW Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8528+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Focus Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8488+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rockstar Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8543+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]World League Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8518+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Slam Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8495+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NBJPW Backyard Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8496+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Insane Championship Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8490+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Empire Underground Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8491+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ECPW Adrenaline Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8494+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ignite Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8492+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]VTW Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8487+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]High Impact Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8498+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PWA Canada Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8493+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New European Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8531+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UKW Wrestling TV Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8489+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Preston City Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8530+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NGW UK Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8497+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]House Of Bricks Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8515+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Southern States Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8547+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Gold Rush Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8517+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]NWA Smokey Mountain[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8569+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rocky Mountain Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8544+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IWA Mid South Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8548+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Empire State Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8567+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Empire Wrestling Federation[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8512+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jersey All Pro Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8542+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Keystone State Wrestling Alliance[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8525+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New England Championship Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8539+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]United Wrestling Network[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8553+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WCF Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8554+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Vanguard Championship Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8555+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]DOA Pro Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8556+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Discovery Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8579+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Primos Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8580+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Capitol Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8577+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pure Pro Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8595+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dominating Backyard Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8578+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Wrestling Media TV[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8587+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Australia[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8592+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Melbourne City Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8585+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]House Of Glory Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8588+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IHWE Professional Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8586+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Evolution Pro Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8589+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pure Power Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8584+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Defy Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8583+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Smash Wrestling Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8591+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rise Underground Pro[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8590+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Of The West Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8581+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Saint Louis Wrestling[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_8582+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Appalachian Mountain Wrestling[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8593+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PWA Ohio Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8574+"/", mode=700, folder=True,
		icon=mediapath+"wchannels.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='wwe')
def WWE():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Matches, Moments, Segments[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8062+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE: Championship Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8063+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full WWE Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8064+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Full Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8065+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More WWE Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8066+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE And NXT Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8067+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Wrestling And More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8068+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Full WWE Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8069+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Raw, Smackdown, And More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8070+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Everything WWE And NXT[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8071+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Matches WWE Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8072+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE: More Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8073+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE: Matches, Divas, And More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8074+"/", mode=70, folder=True,
		icon=mediapath+"wwe.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)


#@route(mode='aew')
def AEW():

	Add_Dir(
		name="[COLOR white][B]All Elite Wrestling Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_8561+"/", mode=701, folder=True,
		icon=mediapath+"playlist.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Elite Wrestling Dark[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8301+"/", mode=701, folder=True,
		icon=mediapath+"playlist.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AEW Dynamite Hightlights[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8300+"/", mode=701, folder=True,
		icon=mediapath+"playlist.png", fanart=fanart)

#@route(mode='womens')
def Womens():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Women Of Honor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8128+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Indie Womens Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8043+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8045+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE And NXT Womens Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8048+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Best Womens Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8049+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More: Womens Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8051+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Independent Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8052+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More: Womens Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8053+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Women Of TNA Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8054+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]UK Womens Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8055+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Bra And Panties Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8056+"/", mode=74, folder=True,
		icon=mediapath+"women.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='roh')
def ROH():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Throwback Thursday[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8127+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)
	Add_Dir(
		name="[COLOR white][B]ROH Women Of Honor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8128+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Future Of Honor[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8129+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8130+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full ROH Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8131+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best ROH PPV Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8132+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8133+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ring Of Honor Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8134+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]R.O.H. Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8135+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]R.O.H Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8136+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ROH Old School Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8137+"/", mode=72, folder=True,
		icon=mediapath+"roh.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='impact')
def Impact():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]TNA Impact Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8142+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]TNA Impact Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8143+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TNA: More Impact Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8144+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More TNA Impact Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8145+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full TNA Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8146+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Matches From Impact[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8147+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More TNA Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8148+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Impact Wrestling Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8149+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Impact Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8150+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Impact Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8151+"/", mode=73, folder=True,
		icon=mediapath+"impact.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)
	
#@route(mode='tables')
def Tables():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]ECW Extreme Rules Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8183+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Hardcore: Wrestling Extreme[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8104+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]I Quit, No DQ, Cage Match[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8105+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Most Violent Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8106+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Extreme Rules Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8107+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WWE Hardcore Street Fights[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8108+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Popular Tables Ladders[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8109+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Steel Cage Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8110+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Of Cage Matches Ever[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8111+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]More Steel Cage Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8112+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]WWE: Steel Cage Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8113+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)
		
	Add_Dir( 
		name="[COLOR white][B]Ladder Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8114+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]WWE: TLC Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8115+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Tables Ladders Chairs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8116+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	Add_Dir( 
		name="[COLOR white][B]Popular TLC Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8117+"/", mode=80, folder=True,
		icon=mediapath+"steel.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='ecw')
def ECW():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Best ECW Matches Of All Time[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8178+"/", mode=76, folder=True,
		icon=mediapath+"ecw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ECW Wrestling Extreme Rules[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8179+"/", mode=76, folder=True,
		icon=mediapath+"ecw.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]ECW Wrestling Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8180+"/", mode=76, folder=True,
		icon=mediapath+"ecw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ECW! Hardcore Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8181+"/", mode=76, folder=True,
		icon=mediapath+"ecw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ECW Wrestling History Volt[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8182+"/", mode=76, folder=True,
		icon=mediapath+"ecw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ECW Extreme Rules Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8183+"/", mode=76, folder=True,
		icon=mediapath+"ecw.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='wcw')
def WCW():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]WCW Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8210+"/", mode=77, folder=True,
		icon=mediapath+"wcw.png", fanart=fanart)
	
	Add_Dir(
		name="[COLOR white][B]WCW Greatest Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8211+"/", mode=77, folder=True,
		icon=mediapath+"wcw.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]WCW: Great Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8212+"/", mode=77, folder=True,
		icon=mediapath+"wcw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Best Of WCW[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8213+"/", mode=77, folder=True,
		icon=mediapath+"wcw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]WCW PPV And Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8214+"/", mode=77, folder=True,
		icon=mediapath+"wcw.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More WCW Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8215+"/", mode=77, folder=True,
		icon=mediapath+"wcw.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)
	
#@route(mode='legends')
def Legends():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The Undertaker[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8258+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The Big Red Machine[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8259+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Stone Cold Steve Austin[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8260+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Of Mick Foley[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8261+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shaun Michaels Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8262+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]The Rock Matches And Video[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8263+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Triple H Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8264+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Bret The Hitman Hart[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8265+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Sting Matches And More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8266+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Ultimate Warrior[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8267+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Andre The Giant Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8268+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Hulk Hogan Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8269+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Macho Man Randy Savage[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8270+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rowdy Roddy Piper Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8271+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Ric Flair Matches And More[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8272+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Randy Orton Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8273+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Kurt Angle Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8274+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Jake The Snake Roberts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8275+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Owen Hart Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8276+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Dusty Rhodes Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8277+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Bruno Sammartino Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8278+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ernie The Big Cat Ladd[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8279+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bruttus The Barber Beefcake[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8280+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Eddie Guerrero Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8281+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bob Backlund Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8282+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Goldberg WWE-WCW Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8283+"/", mode=75, folder=True,
		icon=mediapath+"legends.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='wrestlers_docs')
def Wrestlers_Docs():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Best Pro Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8159+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8161+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pro Wrestling Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8162+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8164+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]WWE: Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8165+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]More Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8166+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Wrestling Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8167+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]More Pro Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8168+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More: Wrestling Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8169+"/", mode=78, folder=True,
		icon=mediapath+"wrestlersdocs.png", fanart=fanart)
		
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#@route(mode='indie')
def Indie():

	add_link_info('[B][COLORorange]=== Wrestlers ===[/COLOR][/B]', mediapath+'wrestlers.png', fanart)

	Add_Dir(
		name="[COLOR white][B]AIW Absolute Archives[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8002+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AIW Girls Night Out[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8003+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AIW Intergender Wrestling[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8004+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AIW Intense TV[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8005+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wrestling Society X[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8007+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AAW Web Shows[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8008+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AAW Match Of The Week[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8009+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AAW TV Episodes[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8010+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]APW Classics[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8012+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]APW Super Summer Series[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8013+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]APW Gym Wars S1[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8014+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]APW Gym Wars S2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8015+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]APW Gym Wars S3[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8016+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]APW Gym Wars S4[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8017+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AWF Mayday Madness[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8019+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AWF Crossfire[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8020+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AWF Showcase[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8021+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ESW Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8023+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]IWC Full Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8024+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]MCW Flashback Fridays[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8025+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]MFPW Network[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8026+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The MFPW[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8027+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PPW TV Championship Matches[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8029+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PPW Womens Championships[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8030+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PPW Tag Team Championships[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8031+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PPW Heavyweight Championships[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8032+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]PPW No Limits Championships[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_8033+"/", mode=79, folder=True,
		icon=mediapath+"indie.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'wrestlers.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)


